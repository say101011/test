<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/d6769627-9390-4b5a-ba57-ae1df876fbdf

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Run the app on an emulator or physical device
6. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Advertising privacy review (2026-10-01)

| Check | Result |
| --- | --- |
| UMP installed | Already present as 3.1.0; upgraded to 4.0.0. |
| GDPR only? | No. UMP supports European regulations and US states messages. No country-specific bypass or custom consent-string cache is used. |
| US states structure | The same UMP update/form/Privacy Options flow supports configured US-state messages and Google-managed GPP signals. Console publication is still required. |
| Ads before consent checks | Closed by default. Each Activity launch refreshes UMP, waits for required-form completion and UMP canRequestAds, then initializes Mobile Ads once per process and waits for its callback before permitting a banner request. |
| Privacy Options | Settings entry appears only when UMP reports REQUIRED. Disabled during an active form. Errors have a visible retry action. |

### Changes

- A single process-level coordinator publishes one consent state. Late callbacks from destroyed Activities cannot reopen the ad gate.
- The previous-session fast path was removed deliberately. Update/form failures pause ads, even if UMP retains a previously usable decision; the app remains usable and Settings offers a retry.
- Opening Privacy Options immediately pauses/destroys registered banners. Every consent operation increments an ad revision so rapid close/reopen cannot reuse an old banner even if Compose coalesces state updates.
- A final UMP permission and revision check runs immediately before the only loadAd call. Banners pause/resume with the Activity and are destroyed on disposal.
- A consent rejection does not necessarily mean no ads: UMP can permit limited/non-personalized advertising. UMP canRequestAds is the authority; the app never equates it with permission for personalized advertising.
- The notification permission prompt waits until the UMP form is dismissed.
- Restored Gradle wrapper scripts/JAR and removed the missing project-specific debug.keystore requirement. Release signing remains configurable through existing environment variables.

### Required AdMob console configuration

1. Register this Android app in your AdMob account. Set its real App ID in app/src/main/AndroidManifest.xml. AdConfig.ADMOB_APP_ID is informational and does not replace the manifest value.
2. In Privacy & messaging, create and PUBLISH a European regulations message for the appropriate app, including the required policy URL and choices.
3. Create and PUBLISH a US states regulations message for the same app. Configure the applicable states, opt-out choices and restricted-data-processing settings for your distribution. An SDK upgrade alone does not publish either message.
4. If mediation partners are added, configure their required privacy settings and signals separately. Do not assume every third-party adapter consumes UMP/GPP automatically.
5. The supplied manifest and banner currently use Google's TEST IDs; production account configuration has not been inspected. Use your own App ID to validate your published messages while retaining test banner requests. Replace production banner IDs and USE_TEST_ADS deliberately before release.
6. Validate fresh install, returning user, European region, regulated US state, other region, offline startup, decline/opt-out, Privacy Options changes and Activity recreation. UMP debug geographies EEA / REGULATED_US_STATE / OTHER and test device IDs belong in local debug builds only; no forced geography or reset was added to production code.

### Validation commands

Use Android Studio with the project's configured Java 25 toolchain and Android SDK 36.1. Set your own SDK path through Android Studio/local.properties.

~~~powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug --no-daemon --no-configuration-cache --max-workers=1
~~~

The new ConsentManagerTest uses fake UMP and Ads callbacks under Robolectric, without requesting live ads. Device/emulator validation, real regional UMP messages, AdMob console changes, and release APK/AAB generation are excluded from this change. Debug APK compilation is checked; see VERIFICATION.txt for this review. This is an implementation review, not a guarantee of legal compliance across jurisdictions. Audience/age treatment must match the actual product; no unsupported assertion that every user is over the age of consent is hard-coded.

Official references:
- https://developers.google.com/admob/android/privacy
- https://developers.google.com/admob/android/privacy/us-iab-support
- https://developers.google.com/admob/android/quick-start

The full source ZIP excludes generated build directories/caches, local SDK paths, private .env files and signing keys. It includes source, resources, tests, Gradle wrapper and this setup guide.

For the latest verification results, see VERIFICATION.txt. See PRIVACY_REVIEW_KO.txt for the 2026-10-01 review, additional regression tests and fixes. The fake-SDK consent tests do not request real ads.


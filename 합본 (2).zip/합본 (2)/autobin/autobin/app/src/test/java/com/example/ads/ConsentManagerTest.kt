package com.example.ads

import android.app.Activity
import android.app.Application
import com.google.android.ump.FormError
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class ConsentManagerTest {
    @Test fun finishingActivityCannotRequestOrRegisterAdsBeforeOnDestroy() {
        val h = Harness()
        h.ready()
        val revision = h.manager.state.value.adRevision
        h.activity.finish()
        assertFalse(h.manager.mayRequestAds(revision))
        var stopped = false
        h.manager.registerAdInvalidation(revision) { stopped = true }
        assertTrue(stopped)
    }

    @Test fun newActivityCanRecoverFromFinishingOwnerWithPendingUpdate() {
        val h = Harness()
        h.manager.gatherConsent(h.activity)
        val oldUpdated = h.sdk.updated
        h.activity.finish()
        val next = Robolectric.buildActivity(Activity::class.java).setup().get()
        h.manager.gatherConsent(next)
        assertEquals(2, h.sdk.updates)
        oldUpdated()
        assertEquals(0, h.sdk.forms)
        h.manager.onActivityDestroyed(h.activity)
        h.sdk.updated()
        h.sdk.canRequestAds = true
        h.sdk.dismissed(null)
        h.initialized()
        assertTrue(h.manager.state.value.canRequestAds)
    }

    private class FakeSdk : ConsentSdk {
        override var canRequestAds = false
        override var privacyRequired = false
        var updates = 0; var forms = 0; var options = 0
        lateinit var updated: () -> Unit
        lateinit var failed: (FormError) -> Unit
        lateinit var dismissed: (FormError?) -> Unit
        override fun update(activity: Activity, success: () -> Unit, failure: (FormError) -> Unit) {
            updates++; updated = success; failed = failure
        }
        override fun showRequired(activity: Activity, done: (FormError?) -> Unit) { forms++; dismissed = done }
        override fun showPrivacy(activity: Activity, done: (FormError?) -> Unit) { options++; dismissed = done }
    }
    private class Harness {
        val activity = Robolectric.buildActivity(Activity::class.java).setup().get()
        val sdk = FakeSdk()
        var initializations = 0
        lateinit var initialized: () -> Unit
        val manager = ConsentManager(sdk) { done -> initializations++; initialized = done }
        fun ready() {
            manager.gatherConsent(activity); sdk.updated()
            sdk.canRequestAds = true; sdk.privacyRequired = true; sdk.dismissed(null); initialized()
        }
    }
    @Test fun previousPermissionDoesNotSkipCurrentUpdateOrInitialization() {
        val h=Harness(); h.sdk.canRequestAds=true
        assertFalse(h.manager.state.value.canRequestAds)
        h.manager.gatherConsent(h.activity)
        assertEquals(0,h.initializations)
        h.sdk.updated(); assertFalse(h.manager.state.value.canRequestAds)
        h.sdk.dismissed(null); assertEquals(1,h.initializations)
        assertFalse(h.manager.state.value.canRequestAds)
        h.initialized(); assertTrue(h.manager.state.value.canRequestAds)
    }
    @Test fun refreshFailureBlocksAdsEvenWithPreviouslyAllowedConsent() {
        val h=Harness(); h.sdk.canRequestAds=true
        h.manager.gatherConsent(h.activity); h.sdk.failed(FormError(2,"offline"))
        assertFalse(h.manager.state.value.canRequestAds); assertEquals(0,h.initializations)
        assertEquals("offline",h.manager.state.value.error)
        h.manager.gatherConsent(h.activity); h.sdk.updated(); h.sdk.dismissed(null); h.initialized()
        assertTrue(h.manager.state.value.canRequestAds)
    }
    @Test fun requiredFormErrorAndUnresolvedConsentDoNotStartAds() {
        val h=Harness(); h.manager.gatherConsent(h.activity); h.sdk.updated()
        h.sdk.canRequestAds=true; h.sdk.dismissed(FormError(2,"form failed"))
        assertFalse(h.manager.state.value.canRequestAds); assertEquals(0,h.initializations)
        h.manager.gatherConsent(h.activity); h.sdk.updated(); h.sdk.canRequestAds=false; h.sdk.dismissed(null)
        assertFalse(h.manager.state.value.canRequestAds); assertEquals(0,h.initializations)
    }
    @Test fun openingOptionsImmediatelyStopsExistingBannerAndRotatesRevision() {
        val h=Harness(); h.ready(); val revision=h.manager.state.value.adRevision
        var stopped=0; h.manager.registerAdInvalidation(revision) { stopped++ }
        h.manager.showPrivacyOptionsForm(h.activity)
        assertEquals(1,stopped); assertFalse(h.manager.mayRequestAds(revision))
        h.sdk.dismissed(null)
        assertTrue(h.manager.state.value.canRequestAds)
        assertFalse(h.manager.mayRequestAds(revision))
        assertTrue(h.manager.mayRequestAds(h.manager.state.value.adRevision))
        assertEquals(1,h.initializations)
    }
    @Test fun optionChangeCanRevokePermission() {
        val h=Harness(); h.ready(); h.manager.showPrivacyOptionsForm(h.activity)
        h.sdk.canRequestAds=false; h.sdk.dismissed(null)
        assertFalse(h.manager.state.value.canRequestAds)
    }
    @Test fun delayedInitializationCannotEnableAdsOverAnOpenPrivacyForm() {
        val h=Harness(); h.manager.gatherConsent(h.activity); h.sdk.updated()
        h.sdk.canRequestAds=true; h.sdk.privacyRequired=true; h.sdk.dismissed(null)
        h.manager.showPrivacyOptionsForm(h.activity); h.initialized()
        assertFalse(h.manager.state.value.canRequestAds)
        h.sdk.dismissed(null); assertTrue(h.manager.state.value.canRequestAds)
    }
    @Test fun destroyedActivityCallbacksCannotRestorePermission() {
        val h=Harness(); h.manager.gatherConsent(h.activity); val old=h.sdk.updated
        h.manager.onActivityDestroyed(h.activity); old()
        assertEquals(0,h.sdk.forms); assertFalse(h.manager.state.value.canRequestAds)
        h.ready(); h.manager.onActivityDestroyed(h.activity); h.initialized()
        assertFalse(h.manager.state.value.canRequestAds)
    }
    @Test fun duplicateRequestsAndUnavailablePrivacyOptionsAreIgnored() {
        val h=Harness(); h.manager.showPrivacyOptionsForm(h.activity); assertEquals(0,h.sdk.options)
        h.manager.gatherConsent(h.activity); h.manager.gatherConsent(h.activity)
        assertEquals(1,h.sdk.updates)
        h.sdk.updated(); h.sdk.canRequestAds=true; h.sdk.privacyRequired=true; h.sdk.dismissed(null); h.initialized()
        h.manager.showPrivacyOptionsForm(h.activity); h.manager.showPrivacyOptionsForm(h.activity)
        assertEquals(1,h.sdk.options)
    }
    @Test fun noRegionalOptionRequirementKeepsEntryUnavailable() {
        val h=Harness(); h.manager.gatherConsent(h.activity); h.sdk.updated(); h.sdk.canRequestAds=true
        h.sdk.dismissed(null); h.initialized()
        assertTrue(h.manager.state.value.canRequestAds); assertFalse(h.manager.state.value.privacyOptionsRequired)
    }
    @Test fun finalLoadCheckRejectsStaleUmpPermission() {
        val h=Harness(); h.ready(); h.sdk.canRequestAds=false
        assertFalse(h.manager.mayRequestAds(h.manager.state.value.adRevision))
        var stopped=false; h.manager.registerAdInvalidation(h.manager.state.value.adRevision){stopped=true}
        assertTrue(stopped)
    }
}

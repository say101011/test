package com.example.data.storage

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import java.io.File
import java.io.IOException
import java.io.InputStream
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class FileManagerTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()

    @Test fun deletionRejectsSiblingDirectoryWithSamePrefix() {
        val sibling = File(context.filesDir.parentFile, context.filesDir.name + "-outside")
        sibling.mkdirs()
        val file = File(sibling, "keep.jpg").apply { writeText("keep") }
        try {
            assertFalse(FileManager(context).deleteFile(file.absolutePath))
            assertTrue(file.exists())
        } finally {
            file.delete()
            sibling.delete()
        }
    }

    @Test fun failedCopyDoesNotLeavePartialPhoto() {
        val directory = File(context.filesDir, "photos").apply { mkdirs() }
        val before = directory.listFiles()!!.map { it.name }.toSet()
        val uri = Uri.parse("content://test.photos/broken")
        shadowOf(context.contentResolver).registerInputStream(uri, object : InputStream() {
            private var reads = 0
            override fun read(): Int {
                if (reads++ < 8) return 65
                throw IOException("Interrupted photo read")
            }
        })
        assertNull(FileManager(context).savePhotoFromUri(uri))
        assertEquals(before, directory.listFiles()!!.map { it.name }.toSet())
    }

    @Test fun validCopyAndDeletionStillWork() {
        val uri = Uri.parse("content://test.photos/valid")
        val bytes = byteArrayOf(1, 2, 3, 4)
        shadowOf(context.contentResolver).registerInputStream(uri, bytes.inputStream())
        val manager = FileManager(context)
        val path = manager.savePhotoFromUri(uri)
        assertNotNull(path)
        assertArrayEquals(bytes, File(path!!).readBytes())
        assertTrue(manager.deleteFile(path))
        assertFalse(File(path).exists())
    }
}

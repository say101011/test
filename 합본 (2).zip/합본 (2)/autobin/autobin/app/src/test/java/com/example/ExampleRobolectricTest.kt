package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DeleteOption
import com.example.ui.util.TimeFormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AutoBin", appName)
    }

    @Test
    fun `test delete option calculation`() {
        val now = 1000000L
        val expiry10m = DeleteOption.TEN_MIN.calculateExpiryTime(now)
        assertEquals(now + 10 * 60 * 1000L, expiry10m)

        val expiryNever = DeleteOption.NEVER.calculateExpiryTime(now)
        assertNull(expiryNever)
    }

    @Test
    fun `test time formatting`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val now = System.currentTimeMillis()
        val formatted = TimeFormatUtils.formatRemainingTime(context, now + 3600 * 1000L, now)
        assertNotNull(formatted)
    }
}

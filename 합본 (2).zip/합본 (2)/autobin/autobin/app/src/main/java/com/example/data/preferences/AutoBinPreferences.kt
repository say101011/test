package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.DeleteOption
import com.example.data.model.TrashRetention
import com.example.data.model.WarningOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AutoBinPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("autobin_preferences", Context.MODE_PRIVATE)

    private val _defaultDeleteOption = MutableStateFlow(loadDefaultDeleteOption())
    val defaultDeleteOption: StateFlow<DeleteOption> = _defaultDeleteOption.asStateFlow()

    private val _defaultWarningOption = MutableStateFlow(loadDefaultWarningOption())
    val defaultWarningOption: StateFlow<WarningOption> = _defaultWarningOption.asStateFlow()

    private val _trashRetention = MutableStateFlow(loadTrashRetention())
    val trashRetention: StateFlow<TrashRetention> = _trashRetention.asStateFlow()

    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private fun loadDefaultDeleteOption(): DeleteOption {
        val name = prefs.getString(KEY_DEFAULT_DELETE, DeleteOption.ONE_DAY.name)
        return try {
            DeleteOption.valueOf(name ?: DeleteOption.ONE_DAY.name)
        } catch (_: Exception) {
            DeleteOption.ONE_DAY
        }
    }

    fun setDefaultDeleteOption(option: DeleteOption) {
        prefs.edit().putString(KEY_DEFAULT_DELETE, option.name).apply()
        _defaultDeleteOption.value = option
    }

    private fun loadDefaultWarningOption(): WarningOption {
        val name = prefs.getString(KEY_DEFAULT_WARNING, WarningOption.NONE.name)
        return try {
            WarningOption.valueOf(name ?: WarningOption.NONE.name)
        } catch (_: Exception) {
            WarningOption.NONE
        }
    }

    fun setDefaultWarningOption(option: WarningOption) {
        prefs.edit().putString(KEY_DEFAULT_WARNING, option.name).apply()
        _defaultWarningOption.value = option
    }

    private fun loadTrashRetention(): TrashRetention {
        val name = prefs.getString(KEY_TRASH_RETENTION, TrashRetention.SEVEN_DAYS.name)
        return try {
            TrashRetention.valueOf(name ?: TrashRetention.SEVEN_DAYS.name)
        } catch (_: Exception) {
            TrashRetention.SEVEN_DAYS
        }
    }

    fun setTrashRetention(retention: TrashRetention) {
        prefs.edit().putString(KEY_TRASH_RETENTION, retention.name).apply()
        _trashRetention.value = retention
    }

    private fun loadThemeMode(): String {
        return prefs.getString(KEY_THEME_MODE, "SYSTEM") ?: "SYSTEM"
    }

    fun setThemeMode(mode: String) {
        prefs.edit().putString(KEY_THEME_MODE, mode).apply()
        _themeMode.value = mode
    }

    companion object {
        private const val KEY_DEFAULT_DELETE = "pref_default_delete"
        private const val KEY_DEFAULT_WARNING = "pref_default_warning"
        private const val KEY_TRASH_RETENTION = "pref_trash_retention"
        private const val KEY_THEME_MODE = "pref_theme_mode"
    }
}

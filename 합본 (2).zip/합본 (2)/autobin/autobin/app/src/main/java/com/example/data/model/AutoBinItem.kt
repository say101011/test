package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ItemType {
    NOTE,
    PHOTO
}

enum class DeleteOption {
    TEN_MIN,
    THIRTY_MIN,
    ONE_HOUR,
    THREE_HOURS,
    TWELVE_HOURS,
    ONE_DAY,
    THREE_DAYS,
    SEVEN_DAYS,
    CUSTOM,
    NEVER;

    fun calculateExpiryTime(fromTime: Long): Long? {
        return when (this) {
            TEN_MIN -> fromTime + 10 * 60 * 1000L
            THIRTY_MIN -> fromTime + 30 * 60 * 1000L
            ONE_HOUR -> fromTime + 60 * 60 * 1000L
            THREE_HOURS -> fromTime + 3 * 60 * 60 * 1000L
            TWELVE_HOURS -> fromTime + 12 * 60 * 60 * 1000L
            ONE_DAY -> fromTime + 24 * 60 * 60 * 1000L
            THREE_DAYS -> fromTime + 3 * 24 * 60 * 60 * 1000L
            SEVEN_DAYS -> fromTime + 7 * 24 * 60 * 60 * 1000L
            CUSTOM -> null // Calculated externally
            NEVER -> null
        }
    }
}

enum class WarningOption {
    NONE,
    TEN_MIN_BEFORE,
    ONE_HOUR_BEFORE,
    ONE_DAY_BEFORE;

    fun getWarningLeadTimeMs(): Long {
        return when (this) {
            NONE -> 0L
            TEN_MIN_BEFORE -> 10 * 60 * 1000L
            ONE_HOUR_BEFORE -> 60 * 60 * 1000L
            ONE_DAY_BEFORE -> 24 * 60 * 60 * 1000L
        }
    }
}

enum class TrashRetention {
    IMMEDIATE,
    ONE_DAY,
    SEVEN_DAYS,
    THIRTY_DAYS;

    fun getRetentionMs(): Long {
        return when (this) {
            IMMEDIATE -> 0L
            ONE_DAY -> 24 * 60 * 60 * 1000L
            SEVEN_DAYS -> 7 * 24 * 60 * 60 * 1000L
            THIRTY_DAYS -> 30 * 24 * 60 * 60 * 1000L
        }
    }
}

enum class SortOption {
    RECENTLY_ADDED,
    OLDEST,
    DELETE_SOON,
    DELETE_LATER
}

@Entity(tableName = "autobin_items")
data class AutoBinItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: ItemType,
    val title: String = "",
    val content: String = "",
    val filePath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long? = null,
    val deleteOption: DeleteOption = DeleteOption.ONE_DAY,
    val warningOption: WarningOption = WarningOption.NONE,
    val warningNotified: Boolean = false,
    val isTrash: Boolean = false,
    val trashedAt: Long? = null
)

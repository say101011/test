package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HourglassEmpty
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CountdownSafeBg
import com.example.ui.theme.CountdownSafeText
import com.example.ui.theme.CountdownUrgentBg
import com.example.ui.theme.CountdownUrgentText
import com.example.ui.theme.CountdownWarnBg
import com.example.ui.theme.CountdownWarnText
import com.example.ui.util.TimeFormatUtils

@Composable
fun CountdownBadge(
    expiresAt: Long?,
    currentTime: Long,
    isTrash: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (isTrash) {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Trash",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    if (expiresAt == null) {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = TimeFormatUtils.formatRemainingTime(context, null, currentTime),
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val diffMs = expiresAt - currentTime
    val (bgColor: Color, textColor: Color) = when {
        diffMs <= 0 -> Pair(
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.onErrorContainer
        )
        diffMs < 30 * 60 * 1000L -> Pair(CountdownUrgentBg, CountdownUrgentText)
        diffMs < 3 * 60 * 60 * 1000L -> Pair(CountdownWarnBg, CountdownWarnText)
        else -> Pair(CountdownSafeBg, CountdownSafeText)
    }

    val label = TimeFormatUtils.formatRemainingTime(context, expiresAt, currentTime)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (diffMs < 30 * 60 * 1000L) Icons.Outlined.HourglassEmpty else Icons.Outlined.Schedule,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                color = textColor
            )
        }
    }
}

package com.example

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import com.example.data.db.AutoBinDatabase
import com.example.data.repository.AutoBinRepository
import com.example.worker.AutoBinCleanupWorker

class AutoBinApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // 1. Initialize Room Database
        AutoBinDatabase.getInstance(this)

        // 2. Schedule periodic WorkManager for auto-deletion & trash cleanup
        try {
            AutoBinCleanupWorker.schedule(this)
        } catch (e: Exception) {
            // Handled gracefully in test or headless environments
        }

        // 3. Create Notification Channel for expiry reminders
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        if (notificationManager != null) {
            AutoBinRepository.createNotificationChannel(notificationManager)
        }
    }
}

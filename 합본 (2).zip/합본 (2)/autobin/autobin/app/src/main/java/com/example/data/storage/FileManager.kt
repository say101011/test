package com.example.data.storage

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class FileManager(private val context: Context) {

    private val photosDir: File
        get() {
            val dir = File(context.filesDir, "photos")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    fun savePhotoFromUri(sourceUri: Uri): String? {
        var destFile: File? = null
        return try {
            val fileName = "autobin_photo_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val destination = File(photosDir, fileName)
            destFile = destination

            val source = context.contentResolver.openInputStream(sourceUri) ?: return null
            source.use { input: InputStream ->
                FileOutputStream(destination).use { output: FileOutputStream ->
                    input.copyTo(output)
                }
            }
            destination.absolutePath
        } catch (e: Exception) {
            // An interrupted copy must not retain untracked private photo data.
            runCatching { destFile?.delete() }
            e.printStackTrace()
            null
        }
    }

    fun createCameraDestination(): Pair<Uri, String>? {
        return try {
            val fileName = "autobin_cam_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val destFile = File(photosDir, fileName)
            if (!destFile.exists()) {
                destFile.createNewFile()
            }
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                destFile
            )
            Pair(contentUri, destFile.absolutePath)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteFile(filePath: String?): Boolean {
        if (filePath.isNullOrBlank()) return false
        return try {
            val file = File(filePath)
            // Safety check: ensure file is located within AutoBin's internal directory only
            val internalPrefix = context.filesDir.canonicalPath + File.separator
            if (file.canonicalPath.startsWith(internalPrefix) && !file.isDirectory) {
                if (file.exists()) {
                    file.delete()
                } else {
                    true
                }
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun calculatePhotosStorageBytes(): Long {
        return try {
            photosDir.listFiles()?.sumOf { it.length() } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    fun clearAllPhotos(): Boolean {
        return try {
            photosDir.listFiles()?.forEach { file ->
                try {
                    file.delete()
                } catch (_: Exception) {}
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}

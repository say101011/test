package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.AutoBinItem

@Database(
    entities = [AutoBinItem::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AutoBinDatabase : RoomDatabase() {
    abstract fun autoBinDao(): AutoBinDao

    companion object {
        @Volatile
        private var INSTANCE: AutoBinDatabase? = null

        fun getInstance(context: Context): AutoBinDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AutoBinDatabase::class.java,
                    "autobin_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val OceanBluePrimary = Color(0xFF0284C7)
val OceanBlueOnPrimary = Color(0xFFFFFFFF)
val OceanBluePrimaryContainer = Color(0xFFE0F2FE)
val OceanBlueOnPrimaryContainer = Color(0xFF0369A1)

val SlateSecondary = Color(0xFF475569)
val SlateOnSecondary = Color(0xFFFFFFFF)
val SlateSecondaryContainer = Color(0xFFF1F5F9)
val SlateOnSecondaryContainer = Color(0xFF1E293B)

val AmberTertiary = Color(0xFFD97706)
val AmberOnTertiary = Color(0xFFFFFFFF)
val AmberTertiaryContainer = Color(0xFFFEF3C7)
val AmberOnTertiaryContainer = Color(0xFF78350F)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)

// Dark Palette
val CyanDarkPrimary = Color(0xFF38BDF8)
val CyanDarkOnPrimary = Color(0xFF082F49)
val CyanDarkPrimaryContainer = Color(0xFF0C4A6E)
val CyanDarkOnPrimaryContainer = Color(0xFFBAE6FD)

val SlateDarkSecondary = Color(0xFF94A3B8)
val SlateDarkOnSecondary = Color(0xFF0F172A)
val SlateDarkSecondaryContainer = Color(0xFF1E293B)
val SlateDarkOnSecondaryContainer = Color(0xFFE2E8F0)

val AmberDarkTertiary = Color(0xFFFBBF24)
val AmberDarkOnTertiary = Color(0xFF451A03)
val AmberDarkTertiaryContainer = Color(0xFF78350F)
val AmberDarkOnTertiaryContainer = Color(0xFFFEF3C7)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOutline = Color(0xFF475569)

// Countdown Badges
val CountdownSafeBg = Color(0xFFE0F2FE)
val CountdownSafeText = Color(0xFF0369A1)
val CountdownWarnBg = Color(0xFFFEF3C7)
val CountdownWarnText = Color(0xFF92400E)
val CountdownUrgentBg = Color(0xFFFEE2E2)
val CountdownUrgentText = Color(0xFF991B1B)

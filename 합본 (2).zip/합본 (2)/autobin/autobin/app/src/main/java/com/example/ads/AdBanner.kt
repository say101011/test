package com.example.ads

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.google.android.gms.ads.*

@Composable
fun AdBanner(consentManager: ConsentManager, modifier: Modifier = Modifier) {
    val consent by consentManager.state.collectAsStateWithLifecycle()
    if (!consent.canRequestAds) return
    key(consent.adRevision) {
        val context = LocalContext.current
        val lifecycle = LocalLifecycleOwner.current.lifecycle
        val adView = remember(context) {
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = AdConfig.activeBannerAdUnitId
                adListener = object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        Log.d("AdBanner", "Ad failed to load: ${error.code}")
                    }
                }
            }
        }
        DisposableEffect(adView, lifecycle) {
            var closed = false
            var requested = false
            fun close() {
                if (!closed) { closed = true; adView.pause(); adView.destroy() }
            }
            fun resumeOrLoad() {
                if (closed) return
                if (!consentManager.mayRequestAds(consent.adRevision)) { close(); return }
                adView.resume()
                if (!requested) {
                    requested = true
                    // Final authoritative UMP check occurs immediately before this request.
                    adView.loadAd(AdRequest.Builder().build())
                }
            }
            val unregister = consentManager.registerAdInvalidation(consent.adRevision, ::close)
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_RESUME -> resumeOrLoad()
                    Lifecycle.Event.ON_PAUSE -> if (!closed) adView.pause()
                    Lifecycle.Event.ON_DESTROY -> close()
                    else -> Unit
                }
            }
            lifecycle.addObserver(observer)
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) resumeOrLoad()
            onDispose { lifecycle.removeObserver(observer); unregister(); close() }
        }
        Column(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(R.string.ad_label), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            AndroidView(factory = { adView }, modifier = Modifier.width(320.dp).height(50.dp))
        }
    }
}

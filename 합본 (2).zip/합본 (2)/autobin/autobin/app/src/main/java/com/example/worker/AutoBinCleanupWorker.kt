package com.example.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.db.AutoBinDatabase
import com.example.data.preferences.AutoBinPreferences
import com.example.data.repository.AutoBinRepository
import com.example.data.storage.FileManager
import java.util.concurrent.TimeUnit

class AutoBinCleanupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val db = AutoBinDatabase.getInstance(applicationContext)
            val fileManager = FileManager(applicationContext)
            val preferences = AutoBinPreferences(applicationContext)
            val repository = AutoBinRepository(
                applicationContext,
                db.autoBinDao(),
                fileManager,
                preferences
            )

            repository.performCleanup()
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "autobin_cleanup_periodic"

        fun schedule(context: Context) {
            val cleanupRequest = PeriodicWorkRequestBuilder<AutoBinCleanupWorker>(
                15, TimeUnit.MINUTES
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                cleanupRequest
            )
        }
    }
}

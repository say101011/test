package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AutoBinItem
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoBinDao {
    @Query("SELECT * FROM autobin_items WHERE isTrash = 0 ORDER BY createdAt DESC")
    fun getActiveItemsFlow(): Flow<List<AutoBinItem>>

    @Query("SELECT * FROM autobin_items WHERE isTrash = 1 ORDER BY trashedAt DESC")
    fun getTrashItemsFlow(): Flow<List<AutoBinItem>>

    @Query("SELECT * FROM autobin_items WHERE id = :id LIMIT 1")
    fun getItemByIdFlow(id: Long): Flow<AutoBinItem?>

    @Query("SELECT * FROM autobin_items WHERE id = :id LIMIT 1")
    suspend fun getItemByIdDirect(id: Long): AutoBinItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: AutoBinItem): Long

    @Update
    suspend fun updateItem(item: AutoBinItem)

    @Delete
    suspend fun deleteItem(item: AutoBinItem)

    @Query("DELETE FROM autobin_items WHERE id = :id")
    suspend fun deleteItemById(id: Long)

    @Query("UPDATE autobin_items SET isTrash = 1, trashedAt = :trashedAt WHERE id = :id")
    suspend fun moveToTrash(id: Long, trashedAt: Long)

    @Query("UPDATE autobin_items SET isTrash = 0, trashedAt = NULL WHERE id = :id")
    suspend fun restoreFromTrash(id: Long)

    @Query("SELECT * FROM autobin_items WHERE isTrash = 0 AND expiresAt IS NOT NULL AND expiresAt <= :currentTime")
    suspend fun getExpiredActiveItems(currentTime: Long): List<AutoBinItem>

    @Query("SELECT * FROM autobin_items WHERE isTrash = 1")
    suspend fun getAllTrashItems(): List<AutoBinItem>

    @Query("SELECT * FROM autobin_items WHERE isTrash = 0 AND expiresAt IS NOT NULL AND warningOption != 'NONE' AND warningNotified = 0")
    suspend fun getPendingWarningCandidates(): List<AutoBinItem>

    @Query("UPDATE autobin_items SET warningNotified = 1 WHERE id = :id")
    suspend fun markWarningNotified(id: Long)

    @Query("DELETE FROM autobin_items WHERE isTrash = 1")
    suspend fun clearAllTrash(): Int

    @Query("DELETE FROM autobin_items")
    suspend fun clearAllData(): Int

    @Query("SELECT * FROM autobin_items WHERE filePath IS NOT NULL")
    suspend fun getAllItemsWithFiles(): List<AutoBinItem>

    @Query("SELECT COUNT(*) FROM autobin_items WHERE isTrash = 0 AND type = 'NOTE'")
    fun getActiveNotesCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM autobin_items WHERE isTrash = 0 AND type = 'PHOTO'")
    fun getActivePhotosCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM autobin_items WHERE isTrash = 1")
    fun getTrashCountFlow(): Flow<Int>
}

package com.example.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DeleteOption
import com.example.data.model.WarningOption
import com.example.ui.util.TimeFormatUtils
import java.util.Calendar

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExpirationSelector(
    selectedOption: DeleteOption,
    onOptionSelected: (DeleteOption) -> Unit,
    customExpiryTime: Long?,
    onCustomExpirySelected: (Long) -> Unit,
    warningOption: WarningOption,
    onWarningOptionSelected: (WarningOption) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val calendar = remember { Calendar.getInstance() }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Outlined.Timer,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = stringResource(R.string.expire_option_label),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Expiration Choice Chips
        val options = listOf(
            Pair(DeleteOption.TEN_MIN, stringResource(R.string.expire_10_min)),
            Pair(DeleteOption.THIRTY_MIN, stringResource(R.string.expire_30_min)),
            Pair(DeleteOption.ONE_HOUR, stringResource(R.string.expire_1_hour)),
            Pair(DeleteOption.THREE_HOURS, stringResource(R.string.expire_3_hours)),
            Pair(DeleteOption.TWELVE_HOURS, stringResource(R.string.expire_12_hours)),
            Pair(DeleteOption.ONE_DAY, stringResource(R.string.expire_24_hours)),
            Pair(DeleteOption.THREE_DAYS, stringResource(R.string.expire_3_days)),
            Pair(DeleteOption.SEVEN_DAYS, stringResource(R.string.expire_7_days)),
            Pair(DeleteOption.CUSTOM, stringResource(R.string.expire_custom)),
            Pair(DeleteOption.NEVER, stringResource(R.string.expire_never))
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            options.forEach { (option, label) ->
                FilterChip(
                    selected = selectedOption == option,
                    onClick = { onOptionSelected(option) },
                    label = { Text(label, fontSize = 12.sp) }
                )
            }
        }

        // Custom Date & Time Picker trigger
        if (selectedOption == DeleteOption.CUSTOM) {
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    val currentYear = calendar.get(Calendar.YEAR)
                    val currentMonth = calendar.get(Calendar.MONTH)
                    val currentDay = calendar.get(Calendar.DAY_OF_MONTH)

                    val datePicker = DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            val timePicker = TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val targetCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, year)
                                        set(Calendar.MONTH, month)
                                        set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                        set(Calendar.HOUR_OF_DAY, hourOfDay)
                                        set(Calendar.MINUTE, minute)
                                        set(Calendar.SECOND, 0)
                                    }
                                    onCustomExpirySelected(targetCal.timeInMillis)
                                },
                                calendar.get(Calendar.HOUR_OF_DAY),
                                calendar.get(Calendar.MINUTE),
                                false
                            )
                            timePicker.show()
                        },
                        currentYear,
                        currentMonth,
                        currentDay
                    )
                    datePicker.datePicker.minDate = System.currentTimeMillis()
                    datePicker.show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Outlined.CalendarMonth,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (customExpiryTime != null) {
                        TimeFormatUtils.formatDateTime(context, customExpiryTime)
                    } else {
                        stringResource(R.string.select_date)
                    }
                )
            }
        }

        // Warning Options (only relevant if item has an expiration time)
        if (selectedOption != DeleteOption.NEVER) {
            Spacer(modifier = Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.warning_option_label),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            val warningOptions = listOf(
                Pair(WarningOption.NONE, stringResource(R.string.warning_none)),
                Pair(WarningOption.TEN_MIN_BEFORE, stringResource(R.string.warning_10_min)),
                Pair(WarningOption.ONE_HOUR_BEFORE, stringResource(R.string.warning_1_hour)),
                Pair(WarningOption.ONE_DAY_BEFORE, stringResource(R.string.warning_1_day))
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                warningOptions.forEach { (wOption, label) ->
                    FilterChip(
                        selected = warningOption == wOption,
                        onClick = { onWarningOptionSelected(wOption) },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
        }
    }
}

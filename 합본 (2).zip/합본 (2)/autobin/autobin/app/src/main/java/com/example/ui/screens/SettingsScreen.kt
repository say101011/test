package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.BrightnessMedium
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Policy
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.DeleteOption
import com.example.data.model.TrashRetention
import com.example.data.model.WarningOption
import com.example.ui.MainViewModel
import com.example.ui.util.TimeFormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val consent by viewModel.consentManager.state.collectAsStateWithLifecycle()

    val defaultDeleteOption by viewModel.preferences.defaultDeleteOption.collectAsStateWithLifecycle()
    val defaultWarningOption by viewModel.preferences.defaultWarningOption.collectAsStateWithLifecycle()
    val trashRetention by viewModel.preferences.trashRetention.collectAsStateWithLifecycle()
    val themeMode by viewModel.preferences.themeMode.collectAsStateWithLifecycle()

    val notesCount by viewModel.notesCount.collectAsStateWithLifecycle()
    val photosCount by viewModel.photosCount.collectAsStateWithLifecycle()
    val trashCount by viewModel.trashCount.collectAsStateWithLifecycle()
    val photosBytes by viewModel.photosStorageBytes.collectAsStateWithLifecycle()

    val showPrivacyPolicy by viewModel.showPrivacyPolicy.collectAsStateWithLifecycle()
    val showLocalDataInfo by viewModel.showLocalDataInfo.collectAsStateWithLifecycle()
    val showConfirmDeleteAll by viewModel.showConfirmDeleteAll.collectAsStateWithLifecycle()
    val showConfirmEmptyTrash by viewModel.showConfirmEmptyTrash.collectAsStateWithLifecycle()

    var showLicensesDialog by remember { mutableStateOf(false) }

    // Dropdown states
    var expiryMenuOpen by remember { mutableStateOf(false) }
    var warningMenuOpen by remember { mutableStateOf(false) }
    var trashMenuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Section 1: General
            SectionHeader(title = stringResource(R.string.settings_section_general))

            // Default expiry
            SettingsRow(
                icon = Icons.Outlined.Timer,
                title = stringResource(R.string.setting_default_expiry),
                subtitle = getDeleteOptionLabel(defaultDeleteOption),
                onClick = { expiryMenuOpen = true }
            ) {
                DropdownMenu(
                    expanded = expiryMenuOpen,
                    onDismissRequest = { expiryMenuOpen = false }
                ) {
                    val options = listOf(
                        DeleteOption.TEN_MIN,
                        DeleteOption.THIRTY_MIN,
                        DeleteOption.ONE_HOUR,
                        DeleteOption.THREE_HOURS,
                        DeleteOption.TWELVE_HOURS,
                        DeleteOption.ONE_DAY,
                        DeleteOption.THREE_DAYS,
                        DeleteOption.SEVEN_DAYS,
                        DeleteOption.NEVER
                    )
                    options.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(getDeleteOptionLabel(opt)) },
                            onClick = {
                                viewModel.preferences.setDefaultDeleteOption(opt)
                                expiryMenuOpen = false
                            }
                        )
                    }
                }
            }

            // Default Warning
            SettingsRow(
                icon = Icons.Outlined.Notifications,
                title = stringResource(R.string.setting_default_warning),
                subtitle = getWarningOptionLabel(defaultWarningOption),
                onClick = { warningMenuOpen = true }
            ) {
                DropdownMenu(
                    expanded = warningMenuOpen,
                    onDismissRequest = { warningMenuOpen = false }
                ) {
                    val options = listOf(
                        WarningOption.NONE,
                        WarningOption.TEN_MIN_BEFORE,
                        WarningOption.ONE_HOUR_BEFORE,
                        WarningOption.ONE_DAY_BEFORE
                    )
                    options.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(getWarningOptionLabel(opt)) },
                            onClick = {
                                viewModel.preferences.setDefaultWarningOption(opt)
                                warningMenuOpen = false
                            }
                        )
                    }
                }
            }

            // Trash Retention
            SettingsRow(
                icon = Icons.Outlined.DeleteSweep,
                title = stringResource(R.string.trash_retention_label),
                subtitle = getTrashRetentionLabel(trashRetention),
                onClick = { trashMenuOpen = true }
            ) {
                DropdownMenu(
                    expanded = trashMenuOpen,
                    onDismissRequest = { trashMenuOpen = false }
                ) {
                    val options = listOf(
                        TrashRetention.IMMEDIATE,
                        TrashRetention.ONE_DAY,
                        TrashRetention.SEVEN_DAYS,
                        TrashRetention.THIRTY_DAYS
                    )
                    options.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(getTrashRetentionLabel(opt)) },
                            onClick = {
                                viewModel.preferences.setTrashRetention(opt)
                                trashMenuOpen = false
                            }
                        )
                    }
                }
            }

            // Theme
            SettingsRow(
                icon = Icons.Outlined.BrightnessMedium,
                title = stringResource(R.string.setting_theme),
                subtitle = when (themeMode) {
                    "LIGHT" -> stringResource(R.string.theme_light)
                    "DARK" -> stringResource(R.string.theme_dark)
                    else -> stringResource(R.string.theme_system)
                },
                onClick = { themeMenuOpen = true }
            ) {
                DropdownMenu(
                    expanded = themeMenuOpen,
                    onDismissRequest = { themeMenuOpen = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.theme_system)) },
                        onClick = {
                            viewModel.preferences.setThemeMode("SYSTEM")
                            themeMenuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.theme_light)) },
                        onClick = {
                            viewModel.preferences.setThemeMode("LIGHT")
                            themeMenuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.theme_dark)) },
                        onClick = {
                            viewModel.preferences.setThemeMode("DARK")
                            themeMenuOpen = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Privacy
            SectionHeader(title = stringResource(R.string.settings_section_privacy))

            // Privacy Policy
            SettingsRow(
                icon = Icons.Outlined.Policy,
                title = stringResource(R.string.setting_privacy_policy),
                subtitle = stringResource(R.string.setting_privacy_policy_desc),
                onClick = { viewModel.setShowPrivacyPolicy(true) }
            )

            // Local Data Info
            SettingsRow(
                icon = Icons.Outlined.Security,
                title = stringResource(R.string.setting_local_data_info),
                subtitle = stringResource(R.string.setting_local_data_info_desc),
                onClick = { viewModel.setShowLocalDataInfo(true) }
            )

            // UMP publishes this requirement for both European and US-state messages.
            if (consent.privacyOptionsRequired) {
                SettingsRow(
                    icon = Icons.Outlined.Info,
                    title = stringResource(R.string.setting_privacy_options),
                    subtitle = stringResource(R.string.setting_privacy_options_desc),
                    enabled = !consent.busy && activity != null,
                    onClick = { activity?.let { viewModel.consentManager.showPrivacyOptionsForm(it) } }
                )
            }
            if (consent.busy) Text(stringResource(R.string.consent_checking))
            if (consent.error != null || (consent.checked && !consent.canRequestAds)) {
                Text(stringResource(if (consent.error != null) R.string.consent_error else R.string.consent_ads_paused))
                TextButton(enabled = !consent.busy && activity != null, onClick = {
                    activity?.let { viewModel.consentManager.gatherConsent(it) }
                }) { Text(stringResource(R.string.consent_retry)) }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: Storage
            SectionHeader(title = stringResource(R.string.settings_section_storage))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.storage_usage_title),
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• " + stringResource(R.string.storage_notes_count, notesCount),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "• " + stringResource(
                            R.string.storage_photos_count,
                            photosCount,
                            TimeFormatUtils.formatStorageSize(photosBytes)
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "• " + stringResource(
                            R.string.storage_trash_count,
                            trashCount,
                            if (trashCount > 0) "managed" else "empty"
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Clear trash
            SettingsRow(
                icon = Icons.Outlined.DeleteSweep,
                title = stringResource(R.string.setting_clear_trash),
                subtitle = "Permanently remove all items in trash",
                onClick = { viewModel.setShowConfirmEmptyTrash(true) }
            )

            // Delete all AutoBin data
            SettingsRow(
                icon = Icons.Outlined.DeleteForever,
                title = stringResource(R.string.setting_delete_all),
                subtitle = "Wipes all AutoBin notes, photos, and trash",
                titleColor = MaterialTheme.colorScheme.error,
                onClick = { viewModel.setShowConfirmDeleteAll(true) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 4: About
            SectionHeader(title = stringResource(R.string.settings_section_about))

            SettingsRow(
                icon = Icons.Outlined.Info,
                title = stringResource(R.string.app_name),
                subtitle = stringResource(R.string.about_version, stringResource(R.string.app_version)) +
                        " • " + stringResource(R.string.app_slogan),
                onClick = { }
            )

            SettingsRow(
                icon = Icons.Outlined.Description,
                title = stringResource(R.string.about_open_source),
                subtitle = "Apache 2.0, MIT, Android Open Source Project",
                onClick = { showLicensesDialog = true }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Privacy Policy Dialog
    if (showPrivacyPolicy) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowPrivacyPolicy(false) },
            title = {
                Text(
                    stringResource(R.string.privacy_dialog_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = stringResource(R.string.privacy_dialog_body),
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowPrivacyPolicy(false) }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }

    // Local Data Info Dialog
    if (showLocalDataInfo) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowLocalDataInfo(false) },
            title = {
                Text(
                    stringResource(R.string.local_data_dialog_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = stringResource(R.string.local_data_dialog_body),
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowLocalDataInfo(false) }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }

    // Licenses Dialog
    if (showLicensesDialog) {
        AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            title = { Text(stringResource(R.string.about_open_source), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "AutoBin is built using open-source libraries:\n\n" +
                                "• Android Jetpack (Compose, Room, WorkManager, Navigation) - Apache 2.0\n" +
                                "• Kotlin & Kotlin Coroutines - Apache 2.0\n" +
                                "• Coil (Image Loading) - Apache 2.0\n" +
                                "• Google Mobile Ads SDK & User Messaging Platform (UMP)\n\n" +
                                "Thank you to the open-source community for making this app possible.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showLicensesDialog = false }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }

    // Delete All AutoBin Data Confirmation Dialog
    if (showConfirmDeleteAll) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowConfirmDeleteAll(false) },
            title = { Text(stringResource(R.string.confirm_delete_all_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.confirm_delete_all_message)) },
            confirmButton = {
                Button(
                    onClick = { viewModel.deleteAllData() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.testTag("confirm_delete_all_button")
                ) {
                    Text(stringResource(R.string.action_permanent_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowConfirmDeleteAll(false) }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    // Empty Trash Dialog
    if (showConfirmEmptyTrash) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowConfirmEmptyTrash(false) },
            title = { Text(stringResource(R.string.confirm_empty_trash_title)) },
            text = { Text(stringResource(R.string.confirm_empty_trash_message)) },
            confirmButton = {
                Button(
                    onClick = { viewModel.emptyTrash() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(stringResource(R.string.action_empty_trash))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowConfirmEmptyTrash(false) }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        ),
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String? = null,
    titleColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
    enabled: Boolean = true,
    extraContent: @Composable () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (titleColor == MaterialTheme.colorScheme.error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                    color = titleColor
                )
                if (!subtitle.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
            extraContent()
        }
    }
    HorizontalDivider(
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
        thickness = 0.5.dp
    )
}

@Composable
private fun getDeleteOptionLabel(option: DeleteOption): String {
    return when (option) {
        DeleteOption.TEN_MIN -> stringResource(R.string.expire_10_min)
        DeleteOption.THIRTY_MIN -> stringResource(R.string.expire_30_min)
        DeleteOption.ONE_HOUR -> stringResource(R.string.expire_1_hour)
        DeleteOption.THREE_HOURS -> stringResource(R.string.expire_3_hours)
        DeleteOption.TWELVE_HOURS -> stringResource(R.string.expire_12_hours)
        DeleteOption.ONE_DAY -> stringResource(R.string.expire_24_hours)
        DeleteOption.THREE_DAYS -> stringResource(R.string.expire_3_days)
        DeleteOption.SEVEN_DAYS -> stringResource(R.string.expire_7_days)
        DeleteOption.CUSTOM -> stringResource(R.string.expire_custom)
        DeleteOption.NEVER -> stringResource(R.string.expire_never)
    }
}

@Composable
private fun getWarningOptionLabel(option: WarningOption): String {
    return when (option) {
        WarningOption.NONE -> stringResource(R.string.warning_none)
        WarningOption.TEN_MIN_BEFORE -> stringResource(R.string.warning_10_min)
        WarningOption.ONE_HOUR_BEFORE -> stringResource(R.string.warning_1_hour)
        WarningOption.ONE_DAY_BEFORE -> stringResource(R.string.warning_1_day)
    }
}

@Composable
private fun getTrashRetentionLabel(retention: TrashRetention): String {
    return when (retention) {
        TrashRetention.IMMEDIATE -> stringResource(R.string.trash_retention_immediate)
        TrashRetention.ONE_DAY -> stringResource(R.string.trash_retention_1_day)
        TrashRetention.SEVEN_DAYS -> stringResource(R.string.trash_retention_7_days)
        TrashRetention.THIRTY_DAYS -> stringResource(R.string.trash_retention_30_days)
    }
}

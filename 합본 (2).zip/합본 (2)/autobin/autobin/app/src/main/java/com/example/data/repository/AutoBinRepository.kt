package com.example.data.repository

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.db.AutoBinDao
import com.example.data.model.AutoBinItem
import com.example.data.model.DeleteOption
import com.example.data.model.ItemType
import com.example.data.model.TrashRetention
import com.example.data.model.WarningOption
import com.example.data.preferences.AutoBinPreferences
import com.example.data.storage.FileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AutoBinRepository(
    private val context: Context,
    private val dao: AutoBinDao,
    private val fileManager: FileManager,
    private val preferences: AutoBinPreferences
) {
    val activeItems: Flow<List<AutoBinItem>> = dao.getActiveItemsFlow()
    val trashItems: Flow<List<AutoBinItem>> = dao.getTrashItemsFlow()

    val notesCount: Flow<Int> = dao.getActiveNotesCountFlow()
    val photosCount: Flow<Int> = dao.getActivePhotosCountFlow()
    val trashCount: Flow<Int> = dao.getTrashCountFlow()

    suspend fun addNote(
        title: String,
        content: String,
        deleteOption: DeleteOption,
        customExpiryTime: Long? = null,
        warningOption: WarningOption = WarningOption.NONE
    ): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val expiresAt = if (deleteOption == DeleteOption.CUSTOM) {
            customExpiryTime
        } else {
            deleteOption.calculateExpiryTime(now)
        }

        val item = AutoBinItem(
            type = ItemType.NOTE,
            title = title.trim(),
            content = content.trim(),
            filePath = null,
            createdAt = now,
            expiresAt = expiresAt,
            deleteOption = deleteOption,
            warningOption = warningOption,
            isTrash = false
        )
        dao.insertItem(item)
    }

    suspend fun addPhoto(
        title: String,
        filePath: String,
        deleteOption: DeleteOption,
        customExpiryTime: Long? = null,
        warningOption: WarningOption = WarningOption.NONE
    ): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val expiresAt = if (deleteOption == DeleteOption.CUSTOM) {
            customExpiryTime
        } else {
            deleteOption.calculateExpiryTime(now)
        }

        val item = AutoBinItem(
            type = ItemType.PHOTO,
            title = title.trim(),
            content = "",
            filePath = filePath,
            createdAt = now,
            expiresAt = expiresAt,
            deleteOption = deleteOption,
            warningOption = warningOption,
            isTrash = false
        )
        dao.insertItem(item)
    }

    suspend fun moveToTrash(id: Long) = withContext(Dispatchers.IO) {
        val retention = preferences.trashRetention.value
        if (retention == TrashRetention.IMMEDIATE) {
            permanentlyDeleteItem(id)
        } else {
            dao.moveToTrash(id, System.currentTimeMillis())
        }
    }

    suspend fun restoreFromTrash(id: Long) = withContext(Dispatchers.IO) {
        dao.restoreFromTrash(id)
    }

    suspend fun permanentlyDeleteItem(id: Long) = withContext(Dispatchers.IO) {
        val item = dao.getItemByIdDirect(id)
        if (item != null) {
            if (item.filePath != null) {
                fileManager.deleteFile(item.filePath)
            }
            dao.deleteItemById(id)
        }
    }

    suspend fun clearTrash() = withContext(Dispatchers.IO) {
        val trashList = dao.getAllTrashItems()
        for (item in trashList) {
            if (item.filePath != null) {
                fileManager.deleteFile(item.filePath)
            }
        }
        dao.clearAllTrash()
    }

    suspend fun deleteAllData() = withContext(Dispatchers.IO) {
        fileManager.clearAllPhotos()
        dao.clearAllData()
    }

    fun getPhotosStorageBytes(): Long {
        return fileManager.calculatePhotosStorageBytes()
    }

    suspend fun performCleanup() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val retention = preferences.trashRetention.value
        val retentionMs = retention.getRetentionMs()

        // 1. Process expired active items
        val expiredActive = dao.getExpiredActiveItems(now)
        for (item in expiredActive) {
            if (retention == TrashRetention.IMMEDIATE) {
                if (item.filePath != null) {
                    fileManager.deleteFile(item.filePath)
                }
                dao.deleteItemById(item.id)
            } else {
                dao.moveToTrash(item.id, now)
            }
        }

        // 2. Process expired trash items
        if (retention != TrashRetention.IMMEDIATE) {
            val allTrash = dao.getAllTrashItems()
            for (item in allTrash) {
                val trashedAt = item.trashedAt ?: item.createdAt
                if (now - trashedAt >= retentionMs) {
                    if (item.filePath != null) {
                        fileManager.deleteFile(item.filePath)
                    }
                    dao.deleteItemById(item.id)
                }
            }
        }

        // 3. Process warning notifications
        checkAndSendWarnings(now)
    }

    private suspend fun checkAndSendWarnings(now: Long) {
        val candidates = dao.getPendingWarningCandidates()
        for (item in candidates) {
            val expiresAt = item.expiresAt ?: continue
            val leadTime = item.warningOption.getWarningLeadTimeMs()
            if (leadTime > 0) {
                val notifyThreshold = expiresAt - leadTime
                if (now >= notifyThreshold && now < expiresAt) {
                    sendExpiryNotification(item)
                    dao.markWarningNotified(item.id)
                }
            }
        }
    }

    private fun sendExpiryNotification(item: AutoBinItem) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            if (permission != PackageManager.PERMISSION_GRANTED) {
                return
            }
        }

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

        createNotificationChannel(notificationManager)

        val itemLabel = if (item.title.isNotBlank()) {
            item.title
        } else if (item.type == ItemType.PHOTO) {
            context.getString(R.string.tab_photos)
        } else {
            item.content.take(20)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(context.getString(R.string.notification_warning_title))
            .setContentText(context.getString(R.string.notification_warning_body, itemLabel))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(item.id.toInt(), notification)
    }

    companion object {
        const val CHANNEL_ID = "autobin_expiry_channel"

        fun createNotificationChannel(notificationManager: NotificationManager) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "AutoBin Expiry Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Alerts for items nearing scheduled deletion"
                }
                notificationManager.createNotificationChannel(channel)
            }
        }
    }
}

package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.DeleteOption
import com.example.data.model.ItemType
import com.example.data.model.WarningOption

class Converters {
    @TypeConverter
    fun fromItemType(value: ItemType?): String = value?.name ?: ItemType.NOTE.name

    @TypeConverter
    fun toItemType(value: String?): ItemType {
        return try {
            value?.let { ItemType.valueOf(it) } ?: ItemType.NOTE
        } catch (_: Exception) {
            ItemType.NOTE
        }
    }

    @TypeConverter
    fun fromDeleteOption(value: DeleteOption?): String = value?.name ?: DeleteOption.ONE_DAY.name

    @TypeConverter
    fun toDeleteOption(value: String?): DeleteOption {
        return try {
            value?.let { DeleteOption.valueOf(it) } ?: DeleteOption.ONE_DAY
        } catch (_: Exception) {
            DeleteOption.ONE_DAY
        }
    }

    @TypeConverter
    fun fromWarningOption(value: WarningOption?): String = value?.name ?: WarningOption.NONE.name

    @TypeConverter
    fun toWarningOption(value: String?): WarningOption {
        return try {
            value?.let { WarningOption.valueOf(it) } ?: WarningOption.NONE
        } catch (_: Exception) {
            WarningOption.NONE
        }
    }
}

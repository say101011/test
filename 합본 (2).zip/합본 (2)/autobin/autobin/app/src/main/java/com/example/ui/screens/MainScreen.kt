package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ads.AdBanner
import com.example.data.model.AutoBinItem
import com.example.data.model.ItemType
import com.example.data.model.SortOption
import com.example.ui.MainViewModel
import com.example.ui.components.AutoBinFab
import com.example.ui.components.ItemCard
import com.example.ui.components.NoteViewerDialog
import com.example.ui.components.PhotoViewerDialog
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit,
    onAddPhotoClick: () -> Unit,
    onTakePhotoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val displayedItems by viewModel.displayedItems.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val currentTimeTick by viewModel.currentTimeTick.collectAsStateWithLifecycle()

    val notesCount by viewModel.notesCount.collectAsStateWithLifecycle()
    val photosCount by viewModel.photosCount.collectAsStateWithLifecycle()
    val trashCount by viewModel.trashCount.collectAsStateWithLifecycle()

    var isSearchExpanded by remember { mutableStateOf(false) }
    var isSortMenuExpanded by remember { mutableStateOf(false) }

    // Dialog state for selected item viewing
    var viewingNoteItem by remember { mutableStateOf<AutoBinItem?>(null) }
    var viewingPhotoItem by remember { mutableStateOf<AutoBinItem?>(null) }

    // Dialog state for delete confirmation
    var itemForDeleteConfirm by remember { mutableStateOf<AutoBinItem?>(null) }
    val showConfirmEmptyTrash by viewModel.showConfirmEmptyTrash.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = stringResource(R.string.app_slogan),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    },
                    actions = {
                        // Search button
                        IconButton(
                            onClick = {
                                isSearchExpanded = !isSearchExpanded
                                if (!isSearchExpanded) viewModel.setSearchQuery("")
                            },
                            modifier = Modifier.testTag("action_search")
                        ) {
                            Icon(
                                imageVector = if (isSearchExpanded) Icons.Outlined.Close else Icons.Outlined.Search,
                                contentDescription = stringResource(R.string.action_search)
                            )
                        }

                        // Sort button & menu
                        Box {
                            IconButton(
                                onClick = { isSortMenuExpanded = true },
                                modifier = Modifier.testTag("action_sort")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Sort,
                                    contentDescription = stringResource(R.string.action_sort)
                                )
                            }
                            DropdownMenu(
                                expanded = isSortMenuExpanded,
                                onDismissRequest = { isSortMenuExpanded = false }
                            ) {
                                val sortOptions = listOf(
                                    Pair(SortOption.RECENTLY_ADDED, stringResource(R.string.sort_recently_added)),
                                    Pair(SortOption.OLDEST, stringResource(R.string.sort_oldest)),
                                    Pair(SortOption.DELETE_SOON, stringResource(R.string.sort_delete_soon)),
                                    Pair(SortOption.DELETE_LATER, stringResource(R.string.sort_delete_later))
                                )
                                sortOptions.forEach { (option, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            viewModel.setSortOption(option)
                                            isSortMenuExpanded = false
                                        },
                                        leadingIcon = if (sortOption == option) {
                                            {
                                                Icon(
                                                    imageVector = Icons.Outlined.Check,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        } else null
                                    )
                                }
                            }
                        }

                        // Settings button
                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier.testTag("action_settings")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Settings,
                                contentDescription = stringResource(R.string.action_settings)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                // Search field bar when active
                AnimatedVisibility(
                    visible = isSearchExpanded,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text(stringResource(R.string.search_placeholder)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_text_field"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                // Tabs: All, Notes, Photos, Trash
                val tabs = listOf(
                    Pair(stringResource(R.string.tab_all), null),
                    Pair(stringResource(R.string.tab_notes), notesCount),
                    Pair(stringResource(R.string.tab_photos), photosCount),
                    Pair(stringResource(R.string.tab_trash), trashCount)
                )

                PrimaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    tabs.forEachIndexed { index, (title, count) ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { viewModel.setSelectedTab(index) },
                            text = {
                                if (count != null && count > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge {
                                                Text(count.toString())
                                            }
                                        }
                                    ) {
                                        Text(title)
                                    }
                                } else {
                                    Text(title)
                                }
                            }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (selectedTab != 3) {
                AutoBinFab(
                    onNewNoteClick = { viewModel.setShowNewNoteSheet(true) },
                    onAddPhotoClick = onAddPhotoClick,
                    onTakePhotoClick = onTakePhotoClick
                )
            }
        },
        bottomBar = {
            // Google AdMob Banner safely integrated at bottom with label
            AdBanner(
                consentManager = viewModel.consentManager
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Trash Banner (if Trash tab is selected)
            if (selectedTab == 3 && displayedItems.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.tab_trash),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = stringResource(R.string.status_in_trash),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        Button(
                            onClick = { viewModel.setShowConfirmEmptyTrash(true) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteForever,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.action_empty_trash),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }

            // Items list or Empty state
            if (displayedItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = when (selectedTab) {
                                1 -> Icons.Outlined.Description
                                2 -> Icons.Outlined.Image
                                3 -> Icons.Outlined.DeleteOutline
                                else -> Icons.Outlined.Inbox
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) {
                                stringResource(R.string.no_search_results)
                            } else if (selectedTab == 3) {
                                stringResource(R.string.no_items_title)
                            } else {
                                stringResource(R.string.no_items_title)
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (selectedTab == 3) {
                                stringResource(R.string.trash_empty_desc)
                            } else {
                                stringResource(R.string.no_items_desc)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Battery optimization disclaimer notice (subtle)
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AccessTime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.deletion_disclaimer),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }
                    }

                    items(
                        items = displayedItems,
                        key = { it.id }
                    ) { item ->
                        ItemCard(
                            item = item,
                            currentTime = currentTimeTick,
                            onClick = {
                                if (item.type == ItemType.PHOTO) {
                                    viewingPhotoItem = item
                                } else {
                                    viewingNoteItem = item
                                }
                            },
                            onDeleteClick = {
                                itemForDeleteConfirm = item
                            },
                            onRestoreClick = {
                                viewModel.restoreFromTrash(item.id)
                            },
                            onPermanentDeleteClick = {
                                viewModel.permanentlyDeleteItem(item.id)
                            },
                            onShareClick = {
                                shareItem(context, item)
                            }
                        )
                    }
                }
            }
        }
    }

    // Note Viewer Dialog
    viewingNoteItem?.let { item ->
        NoteViewerDialog(
            item = item,
            currentTime = currentTimeTick,
            onDismiss = { viewingNoteItem = null },
            onShare = { shareItem(context, item) },
            onDelete = {
                viewingNoteItem = null
                viewModel.moveToTrash(item.id)
            },
            onRestore = {
                viewingNoteItem = null
                viewModel.restoreFromTrash(item.id)
            }
        )
    }

    // Photo Viewer Dialog
    viewingPhotoItem?.let { item ->
        PhotoViewerDialog(
            item = item,
            currentTime = currentTimeTick,
            onDismiss = { viewingPhotoItem = null },
            onShare = { shareItem(context, item) },
            onDelete = {
                viewingPhotoItem = null
                viewModel.moveToTrash(item.id)
            },
            onRestore = {
                viewingPhotoItem = null
                viewModel.restoreFromTrash(item.id)
            }
        )
    }

    // Delete Confirmation Dialog
    itemForDeleteConfirm?.let { item ->
        AlertDialog(
            onDismissRequest = { itemForDeleteConfirm = null },
            title = { Text(stringResource(R.string.confirm_delete_title)) },
            text = { Text(stringResource(R.string.confirm_delete_message)) },
            confirmButton = {
                Button(
                    onClick = {
                        val id = item.id
                        itemForDeleteConfirm = null
                        viewModel.moveToTrash(id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { itemForDeleteConfirm = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    // Empty Trash Confirmation Dialog
    if (showConfirmEmptyTrash) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowConfirmEmptyTrash(false) },
            title = { Text(stringResource(R.string.confirm_empty_trash_title)) },
            text = { Text(stringResource(R.string.confirm_empty_trash_message)) },
            confirmButton = {
                Button(
                    onClick = { viewModel.emptyTrash() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(stringResource(R.string.action_empty_trash))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowConfirmEmptyTrash(false) }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

private fun shareItem(context: android.content.Context, item: AutoBinItem) {
    try {
        val intent = Intent(Intent.ACTION_SEND)
        if (item.type == ItemType.PHOTO && !item.filePath.isNullOrBlank()) {
            val file = File(item.filePath)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            intent.type = "image/jpeg"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (item.title.isNotBlank()) {
                intent.putExtra(Intent.EXTRA_TEXT, item.title)
            }
        } else {
            intent.type = "text/plain"
            val textToShare = if (item.title.isNotBlank()) "${item.title}\n\n${item.content}" else item.content
            intent.putExtra(Intent.EXTRA_TEXT, textToShare)
        }
        context.startActivity(Intent.createChooser(intent, null))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

package com.example.ui.util

import android.content.Context
import android.text.format.DateFormat
import com.example.R
import java.util.Date

object TimeFormatUtils {

    fun formatRemainingTime(
        context: Context,
        expiresAt: Long?,
        currentTime: Long
    ): String {
        if (expiresAt == null) {
            return context.getString(R.string.status_never_expires)
        }

        val diffMs = expiresAt - currentTime
        if (diffMs <= 0) {
            return context.getString(R.string.status_expired)
        }

        val diffSeconds = diffMs / 1000
        val days = diffSeconds / (24 * 3600)
        val hours = (diffSeconds % (24 * 3600)) / 3600
        val minutes = (diffSeconds % 3600) / 60

        val timeString = when {
            days > 0 -> "${days}d ${hours}h"
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "< 1m"
        }

        return context.getString(R.string.remaining_time_format, timeString)
    }

    fun formatScheduledDelete(
        context: Context,
        expiresAt: Long?
    ): String {
        if (expiresAt == null) {
            return context.getString(R.string.status_never_expires)
        }
        val date = Date(expiresAt)
        val dateFormat = DateFormat.getMediumDateFormat(context)
        val timeFormat = DateFormat.getTimeFormat(context)
        val formatted = "${dateFormat.format(date)} ${timeFormat.format(date)}"
        return context.getString(R.string.deletes_at_format, formatted)
    }

    fun formatDateTime(
        context: Context,
        timestamp: Long
    ): String {
        val date = Date(timestamp)
        val dateFormat = DateFormat.getDateFormat(context)
        val timeFormat = DateFormat.getTimeFormat(context)
        return "${dateFormat.format(date)} ${timeFormat.format(date)}"
    }

    fun formatStorageSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.1f MB", mb)
    }
}

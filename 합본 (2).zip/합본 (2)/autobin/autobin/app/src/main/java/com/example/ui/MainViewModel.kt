package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.ConsentManager
import com.example.data.db.AutoBinDatabase
import com.example.data.model.AutoBinItem
import com.example.data.model.DeleteOption
import com.example.data.model.ItemType
import com.example.data.model.SortOption
import com.example.data.model.TrashRetention
import com.example.data.model.WarningOption
import com.example.data.preferences.AutoBinPreferences
import com.example.data.repository.AutoBinRepository
import com.example.data.storage.FileManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AutoBinDatabase.getInstance(application)
    private val fileManager = FileManager(application)
    val preferences = AutoBinPreferences(application)
    val repository = AutoBinRepository(application, db.autoBinDao(), fileManager, preferences)
    val consentManager = ConsentManager.getInstance(application)

    // Current selected tab index: 0 = All, 1 = Notes, 2 = Photos, 3 = Trash
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Sort option
    private val _sortOption = MutableStateFlow(SortOption.RECENTLY_ADDED)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    // Real-time clock tick for countdown displays
    private val _currentTimeTick = MutableStateFlow(System.currentTimeMillis())
    val currentTimeTick: StateFlow<Long> = _currentTimeTick.asStateFlow()

    // Dialog & Sheet States
    private val _showNewNoteSheet = MutableStateFlow(false)
    val showNewNoteSheet: StateFlow<Boolean> = _showNewNoteSheet.asStateFlow()

    private val _pendingPhotoPath = MutableStateFlow<String?>(null)
    val pendingPhotoPath: StateFlow<String?> = _pendingPhotoPath.asStateFlow()

    private val _selectedPhotoItem = MutableStateFlow<AutoBinItem?>(null)
    val selectedPhotoItem: StateFlow<AutoBinItem?> = _selectedPhotoItem.asStateFlow()

    private val _itemToDelete = MutableStateFlow<AutoBinItem?>(null)
    val itemToDelete: StateFlow<AutoBinItem?> = _itemToDelete.asStateFlow()

    private val _showConfirmEmptyTrash = MutableStateFlow(false)
    val showConfirmEmptyTrash: StateFlow<Boolean> = _showConfirmEmptyTrash.asStateFlow()

    private val _showConfirmDeleteAll = MutableStateFlow(false)
    val showConfirmDeleteAll: StateFlow<Boolean> = _showConfirmDeleteAll.asStateFlow()

    private val _showPrivacyPolicy = MutableStateFlow(false)
    val showPrivacyPolicy: StateFlow<Boolean> = _showPrivacyPolicy.asStateFlow()

    private val _showLocalDataInfo = MutableStateFlow(false)
    val showLocalDataInfo: StateFlow<Boolean> = _showLocalDataInfo.asStateFlow()

    // Storage info
    val notesCount = repository.notesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val photosCount = repository.photosCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val trashCount = repository.trashCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _photosStorageBytes = MutableStateFlow(0L)
    val photosStorageBytes: StateFlow<Long> = _photosStorageBytes.asStateFlow()

    init {
        // Run cleanup and refresh storage on start
        refreshStorageInfo()
        viewModelScope.launch {
            repository.performCleanup()
        }

        // Ticker to refresh time counters every 5 seconds
        viewModelScope.launch {
            while (isActive) {
                delay(5000)
                _currentTimeTick.value = System.currentTimeMillis()
            }
        }
    }

    // Filtered and sorted active items
    val displayedItems: StateFlow<List<AutoBinItem>> = combine(
        repository.activeItems,
        repository.trashItems,
        _selectedTab,
        _searchQuery,
        _sortOption
    ) { activeList, trashList, tab, query, sort ->
        val sourceList = if (tab == 3) trashList else activeList

        val tabFiltered = when (tab) {
            1 -> sourceList.filter { it.type == ItemType.NOTE }
            2 -> sourceList.filter { it.type == ItemType.PHOTO }
            else -> sourceList
        }

        val searchFiltered = if (query.isBlank()) {
            tabFiltered
        } else {
            val q = query.trim().lowercase()
            tabFiltered.filter {
                it.title.lowercase().contains(q) || it.content.lowercase().contains(q)
            }
        }

        when (sort) {
            SortOption.RECENTLY_ADDED -> searchFiltered.sortedByDescending { it.createdAt }
            SortOption.OLDEST -> searchFiltered.sortedBy { it.createdAt }
            SortOption.DELETE_SOON -> searchFiltered.sortedWith(
                compareBy(
                    { it.expiresAt == null }, // nulls (never expire) go last
                    { it.expiresAt ?: Long.MAX_VALUE }
                )
            )
            SortOption.DELETE_LATER -> searchFiltered.sortedWith(
                compareBy(
                    { it.expiresAt == null },
                    { -(it.expiresAt ?: 0L) }
                )
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSelectedTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    fun setShowNewNoteSheet(show: Boolean) {
        _showNewNoteSheet.value = show
    }

    fun setPendingPhotoPath(path: String?) {
        _pendingPhotoPath.value = path
    }

    fun setSelectedPhotoItem(item: AutoBinItem?) {
        _selectedPhotoItem.value = item
    }

    fun setItemToDelete(item: AutoBinItem?) {
        _itemToDelete.value = item
    }

    fun setShowConfirmEmptyTrash(show: Boolean) {
        _showConfirmEmptyTrash.value = show
    }

    fun setShowConfirmDeleteAll(show: Boolean) {
        _showConfirmDeleteAll.value = show
    }

    fun setShowPrivacyPolicy(show: Boolean) {
        _showPrivacyPolicy.value = show
    }

    fun setShowLocalDataInfo(show: Boolean) {
        _showLocalDataInfo.value = show
    }

    fun addNote(
        title: String,
        content: String,
        deleteOption: DeleteOption,
        customExpiryTime: Long?,
        warningOption: WarningOption
    ) {
        viewModelScope.launch {
            repository.addNote(title, content, deleteOption, customExpiryTime, warningOption)
            _showNewNoteSheet.value = false
            refreshStorageInfo()
        }
    }

    fun addPhoto(
        title: String,
        filePath: String,
        deleteOption: DeleteOption,
        customExpiryTime: Long?,
        warningOption: WarningOption
    ) {
        viewModelScope.launch {
            repository.addPhoto(title, filePath, deleteOption, customExpiryTime, warningOption)
            _pendingPhotoPath.value = null
            refreshStorageInfo()
        }
    }

    fun copyPhotoFromPicker(uri: Uri): String? {
        val savedPath = fileManager.savePhotoFromUri(uri)
        if (savedPath != null) {
            _pendingPhotoPath.value = savedPath
            refreshStorageInfo()
        }
        return savedPath
    }

    fun createCameraDestination(): Pair<Uri, String>? {
        return fileManager.createCameraDestination()
    }

    fun onCameraCaptureComplete(filePath: String) {
        _pendingPhotoPath.value = filePath
        refreshStorageInfo()
    }

    fun moveToTrash(id: Long) {
        viewModelScope.launch {
            repository.moveToTrash(id)
            refreshStorageInfo()
        }
    }

    fun restoreFromTrash(id: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(id)
            refreshStorageInfo()
        }
    }

    fun permanentlyDeleteItem(id: Long) {
        viewModelScope.launch {
            repository.permanentlyDeleteItem(id)
            _selectedPhotoItem.value = null
            refreshStorageInfo()
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.clearTrash()
            _showConfirmEmptyTrash.value = false
            refreshStorageInfo()
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            repository.deleteAllData()
            _showConfirmDeleteAll.value = false
            refreshStorageInfo()
        }
    }

    fun refreshStorageInfo() {
        _photosStorageBytes.value = repository.getPhotosStorageBytes()
    }

    fun performCleanup() {
        viewModelScope.launch {
            repository.performCleanup()
            refreshStorageInfo()
        }
    }
}

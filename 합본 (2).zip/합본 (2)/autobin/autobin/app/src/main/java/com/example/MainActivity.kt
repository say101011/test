package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.AddPhotoDialog
import com.example.ui.components.NewNoteDialog
import com.example.ui.screens.MainScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AutoBinTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onDestroy() {
        viewModel.consentManager.onActivityDestroyed(this)
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewModel.consentManager.gatherConsent(this)

        setContent {
            val themeMode by viewModel.preferences.themeMode.collectAsStateWithLifecycle()
            val isDarkTheme = when (themeMode) {
                "LIGHT" -> false
                "DARK" -> true
                else -> isSystemInDarkTheme()
            }

            AutoBinTheme(darkTheme = isDarkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var currentScreen by remember { mutableStateOf("main") }

                    // Camera temp URI tracking
                    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
                    var pendingCameraPath by remember { mutableStateOf<String?>(null) }

                    // TakePicture Contract
                    val takePictureLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.TakePicture()
                    ) { success ->
                        if (success && pendingCameraPath != null) {
                            viewModel.onCameraCaptureComplete(pendingCameraPath!!)
                        }
                    }

                    // Camera Permission Contract
                    val cameraPermissionLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.RequestPermission()
                    ) { isGranted ->
                        if (isGranted) {
                            val pair = viewModel.createCameraDestination()
                            if (pair != null) {
                                pendingCameraUri = pair.first
                                pendingCameraPath = pair.second
                                takePictureLauncher.launch(pair.first)
                            }
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                getString(R.string.permission_camera_message),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    // Notification Permission (Android 13+)
                    val notificationPermissionLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.RequestPermission()
                    ) { _ -> }

                    // Photo Picker Contract (Zero-permission Android Photo Picker)
                    val photoPickerLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.PickVisualMedia()
                    ) { uri ->
                        if (uri != null) {
                            viewModel.copyPhotoFromPicker(uri)
                        }
                    }

                    // Avoid placing a system permission prompt over the UMP form.
                    val consent by viewModel.consentManager.state.collectAsStateWithLifecycle()
                    var notificationPromptChecked by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
                    LaunchedEffect(consent.checked, consent.busy) {
                        if (!consent.checked || consent.busy || notificationPromptChecked) return@LaunchedEffect
                        notificationPromptChecked = true

                        // Check notification permission if needed on Android 13+
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val status = ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.POST_NOTIFICATIONS
                            )
                            if (status != PackageManager.PERMISSION_GRANTED) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                    }

                    // Navigation handling
                    if (currentScreen == "settings") {
                        BackHandler {
                            currentScreen = "main"
                        }
                        SettingsScreen(
                            viewModel = viewModel,
                            onNavigateBack = { currentScreen = "main" }
                        )
                    } else {
                        MainScreen(
                            viewModel = viewModel,
                            onNavigateToSettings = { currentScreen = "settings" },
                            onAddPhotoClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onTakePhotoClick = {
                                val hasPermission = ContextCompat.checkSelfPermission(
                                    this@MainActivity,
                                    Manifest.permission.CAMERA
                                ) == PackageManager.PERMISSION_GRANTED

                                if (hasPermission) {
                                    val pair = viewModel.createCameraDestination()
                                    if (pair != null) {
                                        pendingCameraUri = pair.first
                                        pendingCameraPath = pair.second
                                        takePictureLauncher.launch(pair.first)
                                    }
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            }
                        )
                    }

                    // Dialogs
                    val showNewNoteSheet by viewModel.showNewNoteSheet.collectAsStateWithLifecycle()
                    val pendingPhotoPath by viewModel.pendingPhotoPath.collectAsStateWithLifecycle()
                    val defaultDeleteOption by viewModel.preferences.defaultDeleteOption.collectAsStateWithLifecycle()
                    val defaultWarningOption by viewModel.preferences.defaultWarningOption.collectAsStateWithLifecycle()

                    if (showNewNoteSheet) {
                        NewNoteDialog(
                            defaultDeleteOption = defaultDeleteOption,
                            defaultWarningOption = defaultWarningOption,
                            onDismiss = { viewModel.setShowNewNoteSheet(false) },
                            onSave = { title, content, deleteOption, customExpiry, warningOption ->
                                viewModel.addNote(title, content, deleteOption, customExpiry, warningOption)
                            }
                        )
                    }

                    pendingPhotoPath?.let { path ->
                        AddPhotoDialog(
                            filePath = path,
                            defaultDeleteOption = defaultDeleteOption,
                            defaultWarningOption = defaultWarningOption,
                            onDismiss = { viewModel.setPendingPhotoPath(null) },
                            onSave = { title, deleteOption, customExpiry, warningOption ->
                                viewModel.addPhoto(title, path, deleteOption, customExpiry, warningOption)
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Automatically check and prune expired items whenever app returns to foreground
        viewModel.performCleanup()
    }
}

package com.example.ads

object AdConfig {
    /**
     * Google Mobile Ads Test App ID & Ad Unit IDs.
     * Replace with production IDs when releasing to Google Play.
     */
    const val ADMOB_APP_ID: String = "ca-app-pub-3940256099942544~3347511713"

    // Official Google Test Banner Ad Unit ID
    const val TEST_BANNER_AD_UNIT_ID: String = "ca-app-pub-3940256099942544/6300978111"

    // Production Banner Ad Unit ID (Configure before production deployment)
    const val PROD_BANNER_AD_UNIT_ID: String = "ca-app-pub-3940256099942544/6300978111"

    const val USE_TEST_ADS: Boolean = true

    val activeBannerAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_BANNER_AD_UNIT_ID else PROD_BANNER_AD_UNIT_ID
}

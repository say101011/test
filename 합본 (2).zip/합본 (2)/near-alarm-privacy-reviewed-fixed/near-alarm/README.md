<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Near Alarm

See [PRIVACY_INTEGRATION.md](PRIVACY_INTEGRATION.md) for the UMP audit, advertising privacy flow, required AdMob console settings, and validation commands and current review files.

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/860490ac-c5e2-4019-8b0c-4bd24d0a3081

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. The reviewed location alarm, map and ad flows do not call Gemini. No Gemini API key is required for these functions. Configure secrets only if adding features that use them.
5. Use your own release signing configuration when preparing a production release. Debug builds use the standard debug key when no project debug keystore is present.
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

# Near Alarm privacy integration

This source includes UMP 4.0.0 and a region-neutral consent flow for European and US-state messages. Ad requests wait for the current UMP update, required form, canRequestAds and Mobile Ads initialization. Settings exposes Privacy Options when UMP requires it.

See REVIEW_KO.txt for the current audit and fixes, VERIFICATION.txt for actual validation, and PUBLISH_KO.txt for publishing privacy-site/index.html. No remote publication was completed.

Use your real AdMob App ID and banner ID and publish European and US-state messages separately. The included IDs remain Google test IDs. Regional messages, age treatment and mediation configuration require account-level review.

The public privacy URL configured in the app is https://say101011.github.io/Near-Alarm/ and must be published and verified before release. The policy distinguishes device records from Google location services, OSM tiles, submitted Nominatim queries and advertising.

Open this project in Android Studio and configure the Android SDK path. Test with:

    gradlew.bat :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --no-daemon --no-configuration-cache --max-workers=1

Release signing requires the developer's own configuration. Machine-specific settings, secrets, signing keys, build outputs and caches are excluded from the source ZIP. Actual device and server-side regional consent testing remains necessary.

References:
- https://developers.google.com/admob/android/privacy
- https://developers.google.com/admob/android/privacy/us-iab-support
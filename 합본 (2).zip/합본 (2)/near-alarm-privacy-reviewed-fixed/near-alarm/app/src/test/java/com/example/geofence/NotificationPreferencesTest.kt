package com.example.geofence
import android.Manifest
import android.app.Application
import android.app.NotificationManager
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AlertType
import com.example.data.model.LocationAlarm
import com.example.data.model.TriggerType
import com.example.data.pref.AppSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class NotificationPreferencesTest {
    @Test fun disabledSoundAndVibrationAreAppliedToNotificationChannel() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        val settings = AppSettings(app)
        settings.setSoundEnabled(false); settings.setVibrationEnabled(false)
        val alarm = LocationAlarm(1, "Test", 37.5, 127.0, 300, alertType = AlertType.ALARM_SOUND)
        NotificationHelper.showProximityNotification(app, alarm, TriggerType.ENTER)
        val manager = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = manager.getNotificationChannel("near_ALARM_SOUND_false_false")
        assertNotNull(channel); assertNull(channel.sound); assertFalse(channel.shouldVibrate())
        settings.setSoundEnabled(true); settings.setVibrationEnabled(true)
        NotificationHelper.showProximityNotification(app, alarm, TriggerType.ENTER)
        val enabled = manager.getNotificationChannel("near_ALARM_SOUND_true_true")
        assertNotNull(enabled.sound); assertTrue(enabled.shouldVibrate())
    }
    @Test fun missingNotificationPermissionDoesNotPostAnAlert() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(app).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
        NotificationHelper.showProximityNotification(app,
            LocationAlarm(1, "Test", 37.5, 127.0, 300), TriggerType.ENTER)
        val manager = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        assertEquals(0, shadowOf(manager).size())
    }
}

package com.example.geofence
import org.junit.Assert.*
import org.junit.Test
class SerialOperationQueueTest {
    @Test fun removalWaitsUntilOlderRegistrationFinishes() {
        val queue = SerialOperationQueue()
        val events = mutableListOf<String>()
        lateinit var finish: () -> Unit
        queue.submit { done -> events.add("register"); finish = done }
        queue.submit { done -> events.add("remove"); done() }
        assertEquals(listOf("register"), events)
        finish()
        assertEquals(listOf("register", "remove"), events)
        queue.submit { done -> events.add("new"); done() }
        assertEquals(3, events.size)
    }
}

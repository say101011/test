package com.example.data.search
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class PlaceSearcherTest {
    private class Api(val action: suspend (String) -> List<NominatimItem>) : NominatimApi {
        override suspend fun search(query: String, format: String, addressDetails: Int, limit: Int) = action(query)
    }
    @Test fun concurrentRequestsAreSpacedAndRepeatedQueriesUseCache() = runTest {
        val times = mutableListOf<Long>()
        val searcher = PlaceSearcher(Api { times.add(testScheduler.currentTime); emptyList() }) { testScheduler.currentTime }
        val one = async { searcher.search("Seoul") }
        val two = async { searcher.search("Busan") }
        one.await(); two.await()
        searcher.search(" SEOUL ")
        assertEquals(listOf(0L, 1000L), times)
    }
    @Test fun cancellationIsNotConvertedToAnEmptySuccessfulSearch() = runTest {
        val searcher = PlaceSearcher(Api { throw CancellationException("cancelled") }) { 0L }
        try { searcher.search("Seoul"); fail("Cancellation should propagate") }
        catch (_: CancellationException) { }
    }
    @Test fun invalidCoordinatesCannotBecomeAlarmTargets() = runTest {
        val searcher = PlaceSearcher(Api { listOf(
            NominatimItem("bad", "NaN", "0", null),
            NominatimItem("bad", "91", "0", null),
            NominatimItem("valid", "37.5", "127", null)) }) { 0L }
        assertEquals(listOf("valid"), searcher.search("Seoul").getOrThrow().map { it.displayName })
    }
}

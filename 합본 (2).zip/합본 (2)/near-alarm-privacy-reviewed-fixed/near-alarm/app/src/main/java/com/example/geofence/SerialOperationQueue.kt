package com.example.geofence

/** Keeps asynchronous remove/add pairs from interleaving within this process. */
internal class SerialOperationQueue {
    private val pending = ArrayDeque<((() -> Unit) -> Unit)>()
    private var running = false
    @Synchronized fun submit(operation: (() -> Unit) -> Unit) {
        pending.addLast(operation)
        if (!running) next()
    }
    @Synchronized private fun next() {
        val operation = pending.removeFirstOrNull()
        running = operation != null
        val completed = java.util.concurrent.atomic.AtomicBoolean(false)
        operation?.invoke { if (completed.compareAndSet(false, true)) next() }
    }
}

package com.example.ads

import android.app.Activity
import android.content.Context
import androidx.annotation.MainThread
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

internal interface ConsentSdk {
    val canRequestAds: Boolean
    val privacyRequired: Boolean
    fun update(activity: Activity, success: () -> Unit, failure: (FormError) -> Unit)
    fun showRequired(activity: Activity, done: (FormError?) -> Unit)
    fun showPrivacy(activity: Activity, done: (FormError?) -> Unit)
}

private class GoogleConsentSdk(context: Context) : ConsentSdk {
    private val info = UserMessagingPlatform.getConsentInformation(context.applicationContext)
    override val canRequestAds get() = info.canRequestAds()
    override val privacyRequired get() = info.privacyOptionsRequirementStatus ==
        ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
    override fun update(activity: Activity, success: () -> Unit, failure: (FormError) -> Unit) {
        // No region hard-coding: AdMob's published European and US-state messages drive UMP.
        info.requestConsentInfoUpdate(activity, ConsentRequestParameters.Builder().build(),
            { success() }, { failure(it) })
    }
    override fun showRequired(activity: Activity, done: (FormError?) -> Unit) =
        UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { done(it) }
    override fun showPrivacy(activity: Activity, done: (FormError?) -> Unit) =
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { done(it) }
}

data class ConsentState(
    val canRequestAds: Boolean = false,
    val privacyOptionsRequired: Boolean = false,
    val busy: Boolean = false,
    val checked: Boolean = false,
    val error: String? = null,
    val adRevision: Long = 0
)

/** Main-thread coordinator. Errors fail closed until the user retries successfully. */
@MainThread
class ConsentManager internal constructor(
    private val sdk: ConsentSdk,
    private val initializeAds: ((() -> Unit) -> Unit)
) {
    private val mutableState = MutableStateFlow(ConsentState())
    val state = mutableState.asStateFlow()
    private var generation = 0L
    private var owner: WeakReference<Activity>? = null
    private var adsInitializing = false
    private var adsReady = false
    private val adInvalidations = mutableSetOf<() -> Unit>()

    fun gatherConsent(activity: Activity, onConsentComplete: (FormError?) -> Unit = {}) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (state.value.busy && hasUsableOwner()) return
        val token = begin(activity)
        sdk.update(activity, {
            if (valid(token, activity)) {
                mutableState.value = state.value.copy(privacyOptionsRequired = sdk.privacyRequired)
                sdk.showRequired(activity) { error -> finish(token, activity, error, onConsentComplete) }
            }
        }, { error -> finish(token, activity, error, onConsentComplete) })
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: (FormError?) -> Unit = {}) {
        if (state.value.busy || !state.value.privacyOptionsRequired || activity.isFinishing || activity.isDestroyed) return
        val token = begin(activity)
        sdk.showPrivacy(activity) { error -> finish(token, activity, error, onDismissed) }
    }

    private fun begin(activity: Activity): Long {
        owner = WeakReference(activity)
        generation++
        mutableState.value = state.value.copy(canRequestAds = false, busy = true,
            error = null, adRevision = state.value.adRevision + 1)
        invalidateAds()
        return generation
    }

    private fun valid(token: Long, activity: Activity) = token == generation &&
        owner?.get() === activity && !activity.isFinishing && !activity.isDestroyed && state.value.busy

    private fun finish(token: Long, activity: Activity, error: FormError?, done: (FormError?) -> Unit) {
        if (!valid(token, activity)) return
        mutableState.value = state.value.copy(busy = false, checked = true,
            privacyOptionsRequired = sdk.privacyRequired, error = error?.message)
        if (error == null && sdk.canRequestAds) {
            if (adsReady) publishPermission()
            else if (!adsInitializing) {
                adsInitializing = true
                initializeAds {
                    adsReady = true
                    adsInitializing = false
                    // A newer form may be open; an old initialization must not reopen the gate.
                    publishPermission()
                }
            }
        }
        done(error)
    }

    private fun publishPermission() {
        val current = state.value
        mutableState.value = current.copy(canRequestAds = adsReady && current.checked &&
            !current.busy && current.error == null && sdk.canRequestAds &&
            owner?.get()?.let { !it.isDestroyed && !it.isFinishing } == true)
    }

    fun mayRequestAds(revision: Long): Boolean = state.value.let {
        it.canRequestAds && !it.busy && it.adRevision == revision &&
            hasUsableOwner() && sdk.canRequestAds
    }

    private fun hasUsableOwner(): Boolean =
        owner?.get()?.let { !it.isDestroyed && !it.isFinishing } == true

    /** Stops existing refreshes synchronously when a new form starts, before recomposition. */
    fun registerAdInvalidation(revision: Long, stop: () -> Unit): () -> Unit {
        if (!mayRequestAds(revision)) { stop(); return {} }
        adInvalidations.add(stop)
        return { adInvalidations.remove(stop) }
    }

    private fun invalidateAds() {
        val listeners = adInvalidations.toList()
        adInvalidations.clear()
        listeners.forEach { it() }
    }

    fun onActivityDestroyed(activity: Activity) {
        if (owner?.get() !== activity) return
        generation++
        owner = null
        mutableState.value = state.value.copy(canRequestAds = false, busy = false, checked = false,
            adRevision = state.value.adRevision + 1)
        invalidateAds()
    }

    companion object {
        @Volatile private var instance: ConsentManager? = null
        fun getInstance(context: Context): ConsentManager = instance ?: synchronized(this) {
            val applicationContext = context.applicationContext
            instance ?: ConsentManager(GoogleConsentSdk(applicationContext)) { done ->
                MobileAds.initialize(applicationContext) {
                    if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) done()
                    else android.os.Handler(android.os.Looper.getMainLooper()).post { done() }
                }
            }.also { instance = it }
        }
    }
}

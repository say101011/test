# LocalView

Android용 로컬 문서 뷰어입니다. 문서 파싱은 기기에서 실행하며 광고 및 동의 관리에는 Google AdMob/UMP를 사용합니다.

## 빌드

Android Studio에서 이 폴더를 열고 JDK 17 이상, Android SDK 37을 준비합니다. Android Studio의 SDK 설정 또는 local.properties에 sdk.dir을 지정합니다.

```powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
```

디버그 서명은 Android 기본 디버그 키를 사용합니다. 문서 뷰어 실행에 Gemini API 키는 필요하지 않습니다. 릴리스 서명은 KEYSTORE_PATH, STORE_PASSWORD, KEY_PASSWORD 환경변수와 upload 별칭을 사용합니다.

## 개인정보처리방침

- 운영자: momo world
- 문의: say101011@gmail.com
- 공개 URL: https://say101011.github.io/docviewer/
- 설정의 개인정보처리방침 버튼은 공개 URL을 브라우저로 엽니다.
- 오프라인 사본 보기 버튼은 앱에 포함된 페이지를 표시합니다.
- 웹 게시용 파일: privacy/index.html
- 앱 내장 사본: app/src/main/assets/privacy/index.html
- URL 설정: app/src/main/res/values/privacy_config.xml

GitHub Pages의 docviewer 저장소에서 실제 Pages 배포 소스 폴더의 index.html로 privacy/index.html을 게시합니다. 이 코드 수정 작업은 원격 저장소에 업로드하거나 사이트를 배포하지 않습니다. 정책 수정 시 웹 파일과 앱 내장 사본을 함께 갱신해야 합니다.

## 광고

현재 공식 테스트 광고 ID를 사용합니다. UMP의 canRequestAds()가 허용한 경우에만 배너를 구성합니다. 필요할 때 설정에 광고 개인정보 설정 버튼이 표시됩니다. 상용 배포 시 실제 광고 ID, AdMob 개인정보 메시지 설정, 앱의 배포 대상 및 정책 내용을 검토합니다.

## 수정 내역

- 누락된 Gradle Wrapper 실행 파일 복원, 존재하지 않는 프로젝트 전용 debug.keystore 의존 제거
- UMP 의존성 명시, 광고 동의 상태에 따른 요청 차단 및 동의 변경 진입점 추가
- 광고 View 해제 시 destroy 호출
- AppCompatActivity와 AppCompat 테마로 언어 설정 연동, 재생성 시 시작 Intent 중복 처리 방지
- 시스템 파일 선택기의 지속 읽기 권한 확보 시도 및 MIME 조회 예외 처리
- 탭 삭제 시 선택 문서/분할 문서 유지, 분할 문서 선택 시 두 영역 교환
- 문서별 Compose 상태 분리로 다른 PDF의 이전 화면 상태 재사용 방지
- 개인정보처리방침 공개 URL 버튼, 내장 정책 페이지, 다국어 버튼 리소스
- 탭 동작 및 정책 구성 회귀 테스트

실제 광고 게재/지역별 동의 화면과 실기기 문서 동작은 별도의 기기 검증이 필요합니다.

## English interface

The global edition uses English for app menus and messages, regardless of device language or language preferences saved by an earlier version. The language picker has been removed. Document contents and Korean sample documents retain their original language. Both policy HTML copies are in English. Android system dialogs and Google consent forms may follow their own language settings.

## Stability and document handling improvements

- Document imports are streamed to private temporary storage and limited to 64 MiB, even when a file provider does not report a size. Import snapshots are removed after parsing. At most two parsers run concurrently.
- Text, Markdown, legacy Office/HWP byte reads and individual embedded images are limited to 8 MiB. ZIP readers limit expanded data to 24 MiB and entries to 2,048 per pass. HWP inflation is bounded per section. Excessive inputs show an English error instead of continuing unbounded allocation.
- CSV supports quoted delimiters, multiline fields, doubled quotes, BOM removal, blank rows, trailing empty cells, and a 100,000-cell limit. Currency values in the sample CSV are quoted correctly.
- PDF rendering uses a 16 MiB LRU cache per visible viewer and a maximum bitmap edge of 1,600 pixels. PDFs over 2,000 pages are rejected. PDFBox extracts page text locally with a 300-page / 4-million-character indexing limit. Scanned or unextractable pages show a search limitation notice; Scan page provides optional bundled on-device OCR.
- Closing a tab cancels its load. Changing encoding, delimiter or rotation cancels the previous request and only the newest request can update the tab. Blocking parsers receive interruption signals and check cancellation between processing steps; platform/native calls may finish their current step before stopping.
- Settings > Clear Document Cache is available after all tabs are closed. It waits for cancelled loads to finish and deletes only app-owned document cache and sample directories, leaving original files and recent history intact. Cached sample history entries may need the sample to be recreated.
- Settings text is larger and scrollable, and the history switch has an accessibility label. Small-screen/large-text settings tests cover the cache button.
- Search match counting no longer allocates a substring for every character position.

Validation uses unit tests, Robolectric and Android lint without assembling an APK. Physical-device memory profiling and real provider cancellation behavior still require device testing.

## Document accuracy and reading history

- Binary DOC uses the CFB WordDocument and table streams with the actual piece table. HWP5 reads FileHeader and ordered BodyText sections, decompressing flagged sections and interpreting paragraph records. Both provide body-text previews, not original page layout.
- XLS reads BIFF8 records, shared strings including continuation records, row/column coordinates and cached formula results. XLSX follows workbook relationships instead of assuming worksheet filenames. Common built-in date/percentage formats are displayed; common custom numeric formats and merged ranges are supported. XLSX chart caches can be inspected as data and simple bar/column/line previews. Advanced formatting, original chart styling and formula recalculation remain unsupported.
- Spreadsheet previews show clipping and unsupported-value notices. Tap a cell to inspect its complete displayed value.
- Recent entries are unique by URI. Database migration preserves the newest duplicate; last PDF page and zoom are restored and clamped. Individual removal only deletes history. Select File Again replaces an inaccessible URI after a successful load.
- PDF matching-page navigation uses PDFBox text extraction. Physical-device validation was excluded. OCR engine recognition quality has not been validated on a physical device.

Regression fixtures: Apache POI test-data (Apache-2.0) and neolord0/hwplib sample_hwp (Apache-2.0); source links and licenses are under app/src/test/resources/accuracy. PDFBox-Android is licensed under Apache-2.0: https://github.com/TomRoush/PdfBox-Android.

## Reading accuracy and OCR update

- DOCX resolves image and header/footer relationships, preserves inline bold/italic ranges, tabs and paragraph breaks inside tables. Images appear at their document reference instead of being appended arbitrarily. Original print layout and floating placement remain simplified; binary DOC remains body-text only.
- HWP5 reconstructs basic table grids using record levels and list-header cell coordinates. HWPX reads sections numerically and preserves cell addresses and separate paragraphs. Merged/nested HWP table layout and image rendering remain limited.
- XLS/XLSX show merged ranges, common custom numeric formats (currency, decimal places, percentages, zero padding and negative sections) and elapsed-hour formats. BIFF cached text-formula results are supported. XLSX chart relationships expose cached category/series/value data (up to 1,000 points per sheet); no chart recalculation or original chart rendering.
- PDF search stores normalized glyph positions (bounded to 200,000 boxes) and paints matches over native page images. Rotation is accounted for; complex glyph layouts may only be approximate.
- Scan page runs bundled ML Kit OCR only on the selected PDF page, with Latin, Korean, Chinese, Japanese and Devanagari options. Cancellation discards results; the native task keeps ownership of its input until completion to avoid recycling a bitmap in use. Results stay in memory and are discarded when the tab closes. Whole-document automatic OCR is not implemented.
- Bundled OCR increases eventual app size (not measured because APK/AAB generation was excluded). Input images and recognized text stay on device; ML Kit performance/usage metrics may be sent to Google, as disclosed in both policy copies.
- Removed unused resources, adopted plural-aware match counts, modern Compose divider/icons and KTX APIs, and centralized explicit dependency versions. Dependency update warnings are reviewed separately; no blanket lint suppression or baseline was added.

Implementation references: https://developers.google.com/ml-kit/vision/text-recognition/v2/android ; https://developers.google.com/ml-kit/terms ; https://github.com/TomRoush/PdfBox-Android ; https://github.com/neolord0/hwplib (HWP record definitions).

Legacy launcher WebP resources were damaged (binary data had been transcoded as text and decoded images were corrupt). Pre-Android-26 fallback launchers now reuse the existing vector background/foreground through layer-list resources; Android 26+ adaptive icons are retained.

## Dependency and chart-preview maintenance

- Compile/target SDK 37; AGP 9.4.1, Gradle 9.7.1 (official distribution SHA-256 pinned), Kotlin Compose 2.4.20. Updated the AndroidX/Compose, Room, Ads, coroutine and test libraries together and removed unused catalog entries/Firebase BOM.
- Upgraded the PDFBox cryptographic dependency to Bouncy Castle 1.86, including its transitive provider/utilities. No blanket lint suppression or baseline was introduced.
- Small XLSX cached charts now have column, horizontal-bar and line previews, with category labels, series legends and exact-value tables. Missing points stay missing and negative values are drawn relative to zero. Up to 24 categories and 8 series are graphed; unsupported, stacked, combination, logarithmic, oversized or conflicting-category charts retain the data table. Original workbook chart styling and recalculation are not reproduced.
- Migrated Compose UI tests to the current v2 test rule and explicitly enabled native access for the host JVM tests that use Robolectric/Conscrypt.
- PDF page tracking now observes scroll state through snapshotFlow. Spreadsheet merged overlays read pixel offsets during placement and recompose only when the visible row range changes. Pan offsets use primitive float state.
- Android 17 target behavior review found no app-owned RemoteViews, private MessageQueue reflection, local-network discovery, background launches or dynamic native-file loading. Device/vendor and third-party SDK runtime behavior remains unverified because device testing was excluded.

Update references: https://developer.android.com/build/releases/agp-9-4-0-release-notes ; https://developer.android.com/about/versions/17/behavior-changes-17 ; https://developers.google.com/admob/android/migration ; https://www.bouncycastle.org/download/bouncy-castle-java/ .

Remaining dependency warning: Bouncy Castle 1.86 includes an EST trust-all server-certificate helper detected by Android lint. No app source references EST, JcaJceUtils or a custom TrustManager; this observation does not constitute a whole-program reachability proof. The library warning is retained visibly. Removing the entire PKIX dependency can break PDFBox certificate/encryption code, and rewriting or trimming upstream cryptographic classes is outside this maintenance change.

Memory/input bounds remain intentional safeguards. Complex original Office/HWP pagination, floating elements, advanced charts and formula recalculation still need a fuller rendering engine. OCR is explicitly per page; recognition quality and the updated SDKs' physical-device behavior have not been validated on a device.

package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.DocumentContent
import com.example.model.DocumentType
import com.example.model.UnsupportedDocumentContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.CancellationException
import java.io.File
import java.io.FileOutputStream

object DocumentParserManager {
  private val parseSlots = Semaphore(2)

  suspend fun parseDocument(
    context: Context,
    uri: Uri,
    fileName: String,
    forcedType: DocumentType? = null,
    preferredEncoding: String? = null,
    csvDelimiter: Char = ',',
    imageRotation: Int = 0
  ): Pair<DocumentType, DocumentContent> = parseSlots.withPermit { runInterruptible(Dispatchers.IO) {
    val imports = File(context.cacheDir, "document_imports").apply { mkdirs() }
    val snapshot = File.createTempFile("document_", ".tmp", imports)
    try {
      context.contentResolver.openInputStream(uri)?.use { input ->
        snapshot.outputStream().use { output -> DocumentIo.copyLimited(input, output) }
      } ?: throw java.io.FileNotFoundException("Unable to read this document. Please select it again.")
      val localUri = Uri.fromFile(snapshot)
    val ext = fileName.substringAfterLast(".", "")
    val detectedType = forcedType ?: FormatDetector.detect(context, localUri, ext)

    val content = try {
      when (detectedType) {
        DocumentType.PDF -> {
          PdfDocumentParser.parse(context, localUri, fileName)
        }
        DocumentType.EXCEL -> {
          val isLegacy = snapshot.inputStream().use { it.read() == 0xD0 }
          ExcelDocumentParser.parse(context, localUri, isLegacy)
        }
        DocumentType.CSV -> {
          TextCsvDocumentParser.parse(context, localUri, isCsv = true, preferredEncoding = preferredEncoding, csvDelimiter = csvDelimiter)
        }
        DocumentType.WORD -> {
          val isLegacy = snapshot.inputStream().use { it.read() == 0xD0 }
          WordDocumentParser.parse(context, localUri, isLegacy)
        }
        DocumentType.HWP -> {
          HwpDocumentParser.parse(context, localUri)
        }
        DocumentType.HWPX -> {
          HwpxDocumentParser.parse(context, localUri)
        }
        DocumentType.MARKDOWN -> {
          MarkdownDocumentParser.parse(context, localUri)
        }
        DocumentType.TEXT -> {
          TextCsvDocumentParser.parse(context, localUri, isCsv = false, preferredEncoding = preferredEncoding)
        }
        DocumentType.IMAGE -> {
          ImageDocumentParser.parse(context, localUri, imageRotation)
        }
        DocumentType.UNKNOWN -> {
          UnsupportedDocumentContent("This file format is not supported for local viewing.")
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      com.example.model.CorruptedDocumentContent(e.localizedMessage ?: "Unknown parse error")
    }

    DocumentIo.checkCancelled()
    Pair(detectedType, content)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Pair(DocumentType.fromExtension(fileName), com.example.model.CorruptedDocumentContent(e.message ?: "Unable to open document.", e is java.io.FileNotFoundException || e is SecurityException))
    } finally {
      snapshot.delete()
    }
  } }

  /**
   * Generates local test files in app's internal cache for immediate testing without external downloads.
   */
  fun createSampleFile(context: Context, sampleType: String): Pair<Uri, String> {
    val cacheDir = File(context.cacheDir, "sample_docs")
    if (!cacheDir.exists()) cacheDir.mkdirs()

    return when (sampleType) {
      "pdf" -> {
        val file = File(cacheDir, "Sample_Report.pdf")
        if (!file.exists() || file.length() == 0L) {
          createBasicSamplePdf(file)
        }
        Pair(Uri.fromFile(file), file.name)
      }
      "xlsx" -> {
        val file = File(cacheDir, "Financial_Report.xlsx")
        // Refresh older sample files that did not contain workbook relationships.
        createSampleXlsx(file)
        Pair(Uri.fromFile(file), file.name)
      }
      "docx" -> {
        val file = File(cacheDir, "Project_Proposal.docx")
        if (!file.exists() || file.length() == 0L) {
          createSampleDocx(file)
        }
        Pair(Uri.fromFile(file), file.name)
      }
      "hwpx" -> {
        val file = File(cacheDir, "Government_Notice.hwpx")
        if (!file.exists() || file.length() == 0L) {
          createSampleHwpx(file)
        }
        Pair(Uri.fromFile(file), file.name)
      }
      "csv" -> {
        val file = File(cacheDir, "Global_Sales_2026.csv")
        file.writeText(
          "Region,Product,Q1_Revenue,Q2_Revenue,Growth_Rate,Status\n" +
          "Asia Pacific,Cloud Storage,\"$1,250,000\",\"$1,480,000\",+18.4%,Active\n" +
          "North America,Enterprise License,\"$3,820,000\",\"$4,100,000\",+7.3%,Active\n" +
          "Europe,Data Analytics,\"$2,190,000\",\"$2,350,000\",+7.3%,Active\n" +
          "Latin America,Mobile Security,\"$840,000\",\"$990,000\",+17.8%,Review\n" +
          "Middle East,Hardware Gateway,\"$650,000\",\"$690,000\",+6.1%,Pending\n",
          Charsets.UTF_8
        )
        Pair(Uri.fromFile(file), file.name)
      }
      "md" -> {
        val file = File(cacheDir, "Architecture_Guide.md")
        file.writeText(
          "# LocalView Technical Specification\n\n" +
          "> **Privacy Guarantee:** 100% On-device processing. No external cloud conversion.\n\n" +
          "## Supported Format Categories\n" +
          "- [x] Korean Hangul (.hwp, .hwpx)\n" +
          "- [x] Office Spreadsheets (.xlsx, .xls, .csv)\n" +
          "- [x] Office Word Documents (.docx, .doc)\n" +
          "- [x] Portable Document Format (.pdf)\n" +
          "- [x] Markdown & Plain Text (.md, .txt)\n" +
          "- [x] Raster Images (.jpg, .png, .webp, .gif)\n\n" +
          "### Performance Benchmarks\n" +
          "| Document Type | Parser Engine | Memory Overhead | Offline Support |\n" +
          "|---|---|---|---|\n" +
          "| PDF | Native PdfRenderer | Hardware Tiled | 100% Offline |\n" +
          "| XLSX | Streaming XmlPullParser | < 15MB Virtualized | 100% Offline |\n" +
          "| HWPX | OWPML DOM Extractor | Lightweight | 100% Offline |\n\n" +
          "```kotlin\n" +
          "// Zero-network local document processing\n" +
          "val content = DocumentParserManager.parseDocument(context, fileUri, fileName)\n" +
          "```\n",
          Charsets.UTF_8
        )
        Pair(Uri.fromFile(file), file.name)
      }
      else -> {
        val file = File(cacheDir, "Korean_Notice_CP949.txt")
        file.writeText(
          "LocalView 로컬 통합 문서 뷰어 안내서\n\n" +
          "1. 본 앱은 일체의 서버 통신 없이 사용자 기기 내부에서 문서를 처리합니다.\n" +
          "2. 비행기 탑승 모드(오프라인)에서도 저장된 모든 문서를 안전하게 열람할 수 있습니다.\n" +
          "3. 한글(HWP, HWPX), 엑셀, 워드, PDF, 텍스트, 이미지를 통합 탭으로 간편하게 전환해보세요.\n",
          java.nio.charset.Charset.forName("CP949")
        )
        Pair(Uri.fromFile(file), file.name)
      }
    }
  }

  private fun createBasicSamplePdf(targetFile: File) {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    try {
      val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
      val page = pdfDocument.startPage(pageInfo)
      val canvas = page.canvas

      val paintTitle = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(30, 64, 175)
        textSize = 24f
        isFakeBoldText = true
      }
      val paintBody = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(51, 65, 85)
        textSize = 14f
      }
      val paintBadge = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(219, 234, 254)
      }

      canvas.drawRoundRect(40f, 40f, 555f, 90f, 8f, 8f, paintBadge)
      canvas.drawText("LocalView Privacy-First Document Report", 50f, 72f, paintTitle)

      canvas.drawText("Confidential Internal Audit - 100% On-Device Verified", 50f, 130f, paintBody)
      canvas.drawText("1. Document Parsing: Fully isolated inside sandboxed local memory.", 50f, 160f, paintBody)
      canvas.drawText("2. Zero Data Leakage: File content, filenames, and text never touch network.", 50f, 190f, paintBody)
      canvas.drawText("3. Unified Multi-Tab Navigation: Switch seamlessly between PDF, Excel & Word.", 50f, 220f, paintBody)

      // Draw sample chart graphic
      val paintBar = android.graphics.Paint().apply { color = android.graphics.Color.rgb(37, 99, 235) }
      canvas.drawRect(50f, 280f, 120f, 380f, paintBar)
      canvas.drawRect(140f, 240f, 210f, 380f, paintBar)
      canvas.drawRect(230f, 200f, 300f, 380f, paintBar)
      canvas.drawRect(320f, 170f, 390f, 380f, paintBar)

      canvas.drawText("Q1", 75f, 400f, paintBody)
      canvas.drawText("Q2", 165f, 400f, paintBody)
      canvas.drawText("Q3", 255f, 400f, paintBody)
      canvas.drawText("Q4", 345f, 400f, paintBody)

      pdfDocument.finishPage(page)
      FileOutputStream(targetFile).use { out ->
        pdfDocument.writeTo(out)
      }
    } finally {
      pdfDocument.close()
    }
  }

  private fun createSampleXlsx(targetFile: File) {
    // Generate valid ZIP structure containing minimal XLSX components
    java.util.zip.ZipOutputStream(FileOutputStream(targetFile)).use { zos ->
      // [Content_Types].xml
      zos.putNextEntry(java.util.zip.ZipEntry("[Content_Types].xml"))
      val ct = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>""".toByteArray()
      zos.write(ct)
      zos.closeEntry()

      // _rels/.rels
      zos.putNextEntry(java.util.zip.ZipEntry("_rels/.rels"))
      val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".toByteArray()
      zos.write(rels)
      zos.closeEntry()

      // xl/workbook.xml
      zos.putNextEntry(java.util.zip.ZipEntry("xl/workbook.xml"))
      val wb = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Quarterly Revenue" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".toByteArray()
      zos.write(wb)
      zos.closeEntry()

      zos.putNextEntry(java.util.zip.ZipEntry("xl/_rels/workbook.xml.rels"))
      zos.write("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""".toByteArray())
      zos.closeEntry()

      // xl/sharedStrings.xml
      zos.putNextEntry(java.util.zip.ZipEntry("xl/sharedStrings.xml"))
      val ss = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="7" uniqueCount="7">
  <si><t>Department</t></si>
  <si><t>Budget</t></si>
  <si><t>Actual Spend</t></si>
  <si><t>Engineering</t></si>
  <si><t>Marketing</t></si>
  <si><t>Design</t></si>
  <si><t>Operations</t></si>
</sst>""".toByteArray()
      zos.write(ss)
      zos.closeEntry()

      // xl/worksheets/sheet1.xml
      zos.putNextEntry(java.util.zip.ZipEntry("xl/worksheets/sheet1.xml"))
      val ws = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>
    <row r="1">
      <c r="A1" t="s"><v>0</v></c>
      <c r="B1" t="s"><v>1</v></c>
      <c r="C1" t="s"><v>2</v></c>
    </row>
    <row r="2">
      <c r="A2" t="s"><v>3</v></c>
      <c r="B2"><v>1250000</v></c>
      <c r="C2"><v>1180000</v></c>
    </row>
    <row r="3">
      <c r="A3" t="s"><v>4</v></c>
      <c r="B3"><v>450000</v></c>
      <c r="C3"><v>420000</v></c>
    </row>
    <row r="4">
      <c r="A4" t="s"><v>5</v></c>
      <c r="B4"><v>320000</v></c>
      <c r="C4"><v>310000</v></c>
    </row>
    <row r="5">
      <c r="A5" t="s"><v>6</v></c>
      <c r="B5"><v>280000</v></c>
      <c r="C5"><v>260000</v></c>
    </row>
  </sheetData>
</worksheet>""".toByteArray()
      zos.write(ws)
      zos.closeEntry()
    }
  }

  private fun createSampleDocx(targetFile: File) {
    java.util.zip.ZipOutputStream(FileOutputStream(targetFile)).use { zos ->
      zos.putNextEntry(java.util.zip.ZipEntry("[Content_Types].xml"))
      val ct = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>""".toByteArray()
      zos.write(ct)
      zos.closeEntry()

      zos.putNextEntry(java.util.zip.ZipEntry("word/document.xml"))
      val doc = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p>
      <w:pPr><w:pStyle w:val="Heading1"/></w:pPr>
      <w:r><w:b/><w:t>Project Architecture &amp; Delivery Proposal</w:t></w:r>
    </w:p>
    <w:p>
      <w:r><w:t>This proposal outlines the engineering requirements for an on-device document viewer supporting global formats without external cloud dependency.</w:t></w:r>
    </w:p>
    <w:tbl>
      <w:tr>
        <w:tc><w:p><w:r><w:b/><w:t>Phase</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:b/><w:t>Deliverable</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:b/><w:t>Target Date</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:p><w:r><w:t>Phase 1</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:t>Local Parsers &amp; Core Renderers</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:t>Completed</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:p><w:r><w:t>Phase 2</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:t>Split-Screen &amp; Gesture Zoom</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:t>Completed</w:t></w:r></w:p></w:tc>
      </w:tr>
    </w:tbl>
    <w:p>
      <w:r><w:t>All tests completed successfully under airplane mode conditions.</w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".toByteArray()
      zos.write(doc)
      zos.closeEntry()
    }
  }

  private fun createSampleHwpx(targetFile: File) {
    java.util.zip.ZipOutputStream(FileOutputStream(targetFile)).use { zos ->
      zos.putNextEntry(java.util.zip.ZipEntry("Contents/section0.xml"))
      val section = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<hs:sec xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hs="http://www.hancom.co.kr/hwpml/2011/section">
  <hp:p>
    <hp:run><hp:t>제1조 (목적) 본 문서는 LocalView 로컬 문서 뷰어의 한글(HWPX) 표준 파싱 규격을 정의함을 목적으로 합니다.</hp:t></hp:run>
  </hp:p>
  <hp:p>
    <hp:run><hp:t>1. 본 시스템은 KS X 6101 OWPML 표준 규격을 준수합니다.</hp:t></hp:run>
  </hp:p>
  <hp:p>
    <hp:run><hp:t>2. 기기 내부에서 직접 XML 압축 해제 및 DOM 파싱을 진행하여 개인정보 유출을 원천 방지합니다.</hp:t></hp:run>
  </hp:p>
  <hp:tbl>
    <hp:tr>
      <hp:tc><hp:p><hp:run><hp:t>구분</hp:t></hp:run></hp:p></hp:tc>
      <hp:tc><hp:p><hp:run><hp:t>세부 항목</hp:t></hp:run></hp:p></hp:tc>
      <hp:tc><hp:p><hp:run><hp:t>검증 결과</hp:t></hp:run></hp:p></hp:tc>
    </hp:tr>
    <hp:tr>
      <hp:tc><hp:p><hp:run><hp:t>네트워크</hp:t></hp:run></hp:p></hp:tc>
      <hp:tc><hp:p><hp:run><hp:t>문서 데이터 외부 전송 차단</hp:t></hp:run></hp:p></hp:tc>
      <hp:tc><hp:p><hp:run><hp:t>적합 (0 바이트)</hp:t></hp:run></hp:p></hp:tc>
    </hp:tr>
  </hp:tbl>
</hs:sec>""".toByteArray()
      zos.write(section)
      zos.closeEntry()
    }
  }
}

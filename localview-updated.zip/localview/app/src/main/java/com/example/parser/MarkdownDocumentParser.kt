package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.CorruptedDocumentContent
import com.example.model.DocumentContent
import com.example.model.MarkdownBlock
import com.example.model.MarkdownDocumentContent

object MarkdownDocumentParser {

  fun parse(context: Context, uri: Uri): DocumentContent {
    return try {
      val rawText = context.contentResolver.openInputStream(uri)?.use { stream ->
        String(DocumentIo.readLimited(stream), Charsets.UTF_8).removePrefix("\uFEFF")
      } ?: return CorruptedDocumentContent("Unable to read Markdown content")

      val blocks = parseMarkdownText(rawText)
      MarkdownDocumentContent(rawText = rawText, blocks = blocks)
    } catch (e: Exception) {
      CorruptedDocumentContent("Failed to parse Markdown: ${e.localizedMessage}")
    }
  }

  fun parseMarkdownText(rawText: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = rawText.lines()
    var i = 0

    while (i < lines.size) {
      val line = lines[i]
      val trimmed = line.trim()

      if (trimmed.isEmpty()) {
        i++
        continue
      }

      // Code Block
      if (trimmed.startsWith("```")) {
        val lang = trimmed.removePrefix("```").trim()
        val codeLines = mutableListOf<String>()
        i++
        while (i < lines.size && !lines[i].trim().startsWith("```")) {
          codeLines.add(lines[i])
          i++
        }
        if (i < lines.size) i++ // Skip closing ```
        blocks.add(MarkdownBlock.CodeBlock(lang, codeLines.joinToString("\n")))
        continue
      }

      // Headings
      if (trimmed.startsWith("#")) {
        val level = trimmed.takeWhile { it == '#' }.length.coerceIn(1, 6)
        val text = trimmed.drop(level).trim()
        blocks.add(MarkdownBlock.Heading(level, sanitizeText(text)))
        i++
        continue
      }

      // Blockquote
      if (trimmed.startsWith(">")) {
        val text = trimmed.removePrefix(">").trim()
        blocks.add(MarkdownBlock.BlockQuote(sanitizeText(text)))
        i++
        continue
      }

      // Checklist item
      if (trimmed.startsWith("- [ ] ") || trimmed.startsWith("- [x] ") || trimmed.startsWith("- [X] ")) {
        val isChecked = trimmed.startsWith("- [x] ") || trimmed.startsWith("- [X] ")
        val text = trimmed.substring(6).trim()
        blocks.add(MarkdownBlock.ChecklistItem(sanitizeText(text), isChecked))
        i++
        continue
      }

      // Unordered list
      if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("+ ")) {
        val text = trimmed.drop(2).trim()
        blocks.add(MarkdownBlock.ListItem(sanitizeText(text), level = 0, isOrdered = false))
        i++
        continue
      }

      // Ordered list
      val orderedMatch = Regex("^(\\d+)\\.\\s+(.*)").find(trimmed)
      if (orderedMatch != null) {
        val num = orderedMatch.groupValues[1].toIntOrNull() ?: 1
        val text = orderedMatch.groupValues[2].trim()
        blocks.add(MarkdownBlock.ListItem(sanitizeText(text), level = 0, isOrdered = true, index = num))
        i++
        continue
      }

      // Table
      if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
        val tableLines = mutableListOf<String>()
        while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
          tableLines.add(lines[i].trim())
          i++
        }
        if (tableLines.size >= 2) {
          val headerRow = parseTableRow(tableLines[0])
          val dataRows = mutableListOf<List<String>>()
          for (rowIdx in 1 until tableLines.size) {
            val r = tableLines[rowIdx]
            if (r.contains("---")) continue // Skip delimiter line
            dataRows.add(parseTableRow(r))
          }
          blocks.add(MarkdownBlock.Table(headerRow, dataRows))
        }
        continue
      }

      // Standard Paragraph
      blocks.add(MarkdownBlock.Paragraph(sanitizeText(trimmed)))
      i++
    }

    return blocks
  }

  private fun parseTableRow(rowStr: String): List<String> {
    return rowStr.removePrefix("|").removeSuffix("|")
      .split("|")
      .map { sanitizeText(it.trim()) }
  }

  /**
   * Strips harmful HTML scripts or malicious tags for local safe rendering.
   */
  private fun sanitizeText(input: String): String {
    return input
      .replace(Regex("<script.*?>.*?</script>", RegexOption.IGNORE_CASE), "")
      .replace(Regex("<iframe.*?>.*?</iframe>", RegexOption.IGNORE_CASE), "")
  }
}

package com.example.ui.viewer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.model.ChartKind
import com.example.model.ChartPreview
import kotlin.math.abs
import java.util.Locale

@Composable
internal fun ChartPreviewView(preview: ChartPreview) {
  val colors=listOf(Color(0xFF2563EB),Color(0xFFEA580C),Color(0xFF16A34A),Color(0xFF9333EA),Color(0xFFDB2777),Color(0xFF0891B2),Color(0xFF854D0E),Color(0xFF64748B))
  val ink=MaterialTheme.colorScheme.onSurface
  val numbers=preview.series.flatMap { it.values }.filterNotNull()
  // Normalize first so opposite extreme finite values cannot overflow the range.
  val magnitude=(numbers.maxOfOrNull { abs(it) } ?: 1.0).takeIf { it>0 } ?: 1.0
  val low=minOf(0.0,(numbers.minOrNull() ?: 0.0)/magnitude)
  val high=maxOf(0.0,(numbers.maxOrNull() ?: 0.0)/magnitude).let { if(it==low)low+1 else it }
  fun fraction(value:Double)=((value/magnitude-low)/(high-low)).toFloat()
  Text("Simplified cached ${preview.kind.name.lowercase(Locale.ROOT)} chart")
  Text("Range: ${String.format(Locale.ROOT,"%.4g",low*magnitude)} to ${String.format(Locale.ROOT,"%.4g",high*magnitude)}")
  Row(Modifier.horizontalScroll(rememberScrollState())) {
    Canvas(Modifier.width(maxOf(280,preview.categories.size*34).dp).height(240.dp).testTag("chart_preview")
      .semantics { contentDescription="${preview.kind.name.lowercase(Locale.ROOT)} chart. Exact values are listed below." }) {
      val left=24.dp.toPx();val top=12.dp.toPx();val right=size.width-12.dp.toPx();val bottom=size.height-28.dp.toPx()
      val width=right-left;val height=bottom-top
      val horizontal=preview.kind==ChartKind.BAR
      val zero=fraction(0.0)
      val baseline=if(horizontal)left+width*zero else bottom-height*zero
      if(horizontal)drawLine(ink,Offset(baseline,top),Offset(baseline,bottom))
      else drawLine(ink,Offset(left,baseline),Offset(right,baseline))
      val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {color=ink.toArgb();textSize=10.dp.toPx();textAlign=android.graphics.Paint.Align.CENTER}
      val slot=(if(horizontal)height else width)/preview.categories.size
      preview.categories.indices.forEach { c ->
        if(horizontal)drawContext.canvas.nativeCanvas.drawText("${c+1}",left-12.dp.toPx(),top+slot*(c+0.5f)+4.dp.toPx(),paint)
        else drawContext.canvas.nativeCanvas.drawText("${c+1}",left+slot*(c+0.5f),bottom+16.dp.toPx(),paint)
      }
      preview.series.forEachIndexed { s,series ->
        var previous:Offset?=null
        series.values.forEachIndexed point@ { c,value ->
          if(value==null) {previous=null;return@point}
          val color=colors[s%colors.size]
          val f=fraction(value)
          if(preview.kind==ChartKind.LINE) {
            val point=Offset(left+slot*(c+0.5f),bottom-height*f)
            previous?.let {drawLine(color,it,point,2.dp.toPx())}
            drawCircle(color,3.dp.toPx(),point);previous=point
          } else {
            val thickness=slot*0.8f/preview.series.size
            val position=slot*c+slot*0.1f+thickness*s
            if(horizontal) {
              val end=left+width*f
              drawRect(color,Offset(minOf(baseline,end),top+position),Size(abs(end-baseline),thickness*0.9f))
            } else {
              val end=bottom-height*f
              drawRect(color,Offset(left+position,minOf(baseline,end)),Size(thickness*0.9f,abs(end-baseline)))
            }
          }
        }
      }
    }
  }
  preview.series.forEachIndexed { i,series -> Text("${i+1}. ${series.name}",color=colors[i%colors.size]) }
  Text(preview.categories.mapIndexed { i,label->"${i+1}: $label" }.joinToString(" · "))
}

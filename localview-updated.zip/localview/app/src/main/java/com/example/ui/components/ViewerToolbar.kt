package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.automirrored.filled.WrapText
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DocumentTab
import com.example.model.DocumentType
import com.example.model.PdfDocumentContent
import com.example.model.SpreadsheetDocumentContent
import com.example.parser.TextCsvDocumentParser

@Composable
fun ViewerToolbar(
  tab: DocumentTab,
  onZoomIn: () -> Unit,
  onZoomOut: () -> Unit,
  onSetZoom: (Float) -> Unit,
  onPageChange: (Int) -> Unit,
  onSheetChange: (Int) -> Unit,
  onToggleMarkdownRendered: (Boolean) -> Unit,
  onEncodingChange: (String) -> Unit,
  onDelimiterChange: (Char) -> Unit,
  onToggleWordWrap: () -> Unit,
  onRotateImage: () -> Unit,
  onSearchQueryChange: (String) -> Unit
) {
  var isSearchExpanded by remember { mutableStateOf(false) }
  var isZoomMenuOpen by remember { mutableStateOf(false) }
  var isEncodingMenuOpen by remember { mutableStateOf(false) }
  var isDelimiterMenuOpen by remember { mutableStateOf(false) }
  var isSheetMenuOpen by remember { mutableStateOf(false) }
  var showPageJumpDialog by remember { mutableStateOf(false) }
  var showSimplifiedInfoDialog by remember { mutableStateOf(false) }

  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    modifier = Modifier.fillMaxWidth()
  ) {
    if (isSearchExpanded) {
      // In-document Search Bar
      androidx.compose.foundation.layout.Column {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = tab.searchQuery,
          onValueChange = onSearchQueryChange,
          placeholder = { Text(stringResource(R.string.search_hint), fontSize = 13.sp) },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("document_search_input"),
          trailingIcon = {
            if (tab.searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchQueryChange("") }) {
                Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
              }
            }
          }
        )

        Spacer(modifier = Modifier.width(8.dp))

        if (tab.searchQuery.isNotEmpty()) {
          Text(
            text = if (tab.searchMatchCount > 0)
              pluralStringResource(R.plurals.search_matches, tab.searchMatchCount, tab.searchMatchCount)
            else stringResource(R.string.no_matches),
            fontSize = 12.sp,
            color = if (tab.searchMatchCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(horizontal = 4.dp)
          )
        }

        IconButton(
          onClick = {
            isSearchExpanded = false
            onSearchQueryChange("")
          },
          modifier = Modifier.testTag("close_search_button")
        ) {
          Icon(Icons.Default.Close, contentDescription = "Close search")
        }
      }
      val pdf = tab.content as? PdfDocumentContent
      if (pdf != null && tab.searchQuery.isNotBlank()) {
        val pages = pdf.pageTextList.mapIndexedNotNull { i, text -> i.takeIf { text.contains(tab.searchQuery, ignoreCase = true) } }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
          TextButton(enabled = pages.isNotEmpty(), onClick = { onPageChange(pages.lastOrNull { it < tab.currentPage } ?: pages.last()) }) { Text("Previous page") }
          TextButton(enabled = pages.isNotEmpty(), onClick = { onPageChange(pages.firstOrNull { it > tab.currentPage } ?: pages.first()) }) { Text("Next page") }
          Text("Matches on "+pages.size+" pages", fontSize = 12.sp)
        }
      }
      }
    } else {
      // Standard Document Tools Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        // Zoom controls
        IconButton(
          onClick = onZoomOut,
          modifier = Modifier
            .size(36.dp)
            .testTag("zoom_out_button")
        ) {
          Icon(
            imageVector = Icons.Default.ZoomOut,
            contentDescription = stringResource(R.string.zoom_out),
            modifier = Modifier.size(20.dp)
          )
        }

        Box {
          OutlinedButton(
            onClick = { isZoomMenuOpen = true },
            modifier = Modifier
              .height(34.dp)
              .testTag("zoom_presets_button")
          ) {
            Text(
              text = "${(tab.zoomLevel * 100).toInt()}%",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          }

          DropdownMenu(
            expanded = isZoomMenuOpen,
            onDismissRequest = { isZoomMenuOpen = false }
          ) {
            listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f).forEach { zoom ->
              DropdownMenuItem(
                text = { Text("${(zoom * 100).toInt()}%") },
                onClick = {
                  onSetZoom(zoom)
                  isZoomMenuOpen = false
                }
              )
            }
          }
        }

        IconButton(
          onClick = onZoomIn,
          modifier = Modifier
            .size(36.dp)
            .testTag("zoom_in_button")
        ) {
          Icon(
            imageVector = Icons.Default.ZoomIn,
            contentDescription = stringResource(R.string.zoom_in),
            modifier = Modifier.size(20.dp)
          )
        }

        IconButton(
          onClick = { onSetZoom(1.0f) },
          modifier = Modifier
            .size(36.dp)
            .testTag("fit_page_button")
        ) {
          Icon(
            imageVector = Icons.Default.FitScreen,
            contentDescription = stringResource(R.string.fit_page),
            modifier = Modifier.size(20.dp)
          )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // PDF Page jump & counter
        if (tab.type == DocumentType.PDF && tab.content is PdfDocumentContent) {
          val pdfContent = tab.content
          OutlinedButton(
            onClick = { showPageJumpDialog = true },
            modifier = Modifier
              .height(34.dp)
              .testTag("pdf_page_jump_button")
          ) {
            Text(
              text = stringResource(R.string.page_indicator, tab.currentPage + 1, pdfContent.pageCount),
              fontSize = 12.sp
            )
          }
        }

        // Excel Sheets picker
        if ((tab.type == DocumentType.EXCEL || tab.type == DocumentType.CSV) && tab.content is SpreadsheetDocumentContent) {
          val sheetContent = tab.content
          if (sheetContent.sheets.size > 1) {
            Box {
              OutlinedButton(
                onClick = { isSheetMenuOpen = true },
                modifier = Modifier
                  .height(34.dp)
                  .testTag("excel_sheets_button")
              ) {
                Text(
                  text = sheetContent.sheets.getOrNull(tab.activeSheetIndex)?.name ?: stringResource(R.string.sheets),
                  fontSize = 12.sp
                )
              }

              DropdownMenu(
                expanded = isSheetMenuOpen,
                onDismissRequest = { isSheetMenuOpen = false }
              ) {
                sheetContent.sheets.forEachIndexed { sIdx, sheet ->
                  DropdownMenuItem(
                    text = { Text(sheet.name) },
                    onClick = {
                      onSheetChange(sIdx)
                      isSheetMenuOpen = false
                    }
                  )
                }
              }
            }
          }
        }

        // Word / HWP Simplified info badge
        if (tab.type in listOf(DocumentType.WORD, DocumentType.HWP, DocumentType.HWPX)) {
          TextButton(
            onClick = { showSimplifiedInfoDialog = true },
            modifier = Modifier
              .height(34.dp)
              .testTag("simplified_view_info_badge")
          ) {
            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(stringResource(R.string.simplified_view_badge), fontSize = 12.sp)
          }
        }

        // Markdown Rendered vs Raw toggle
        if (tab.type == DocumentType.MARKDOWN) {
          OutlinedButton(
            onClick = { onToggleMarkdownRendered(!tab.isMarkdownRendered) },
            modifier = Modifier
              .height(34.dp)
              .testTag("markdown_toggle_mode_button")
          ) {
            Icon(
              imageVector = if (tab.isMarkdownRendered) Icons.Default.Code else Icons.Default.Visibility,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (tab.isMarkdownRendered) stringResource(R.string.raw_markdown) else stringResource(R.string.rendered_markdown),
              fontSize = 12.sp
            )
          }
        }

        // TXT / CSV Encoding selector
        if (tab.type in listOf(DocumentType.TEXT, DocumentType.CSV)) {
          Box {
            OutlinedButton(
              onClick = { isEncodingMenuOpen = true },
              modifier = Modifier
                .height(34.dp)
                .testTag("text_encoding_button")
            ) {
              Text("${tab.textEncoding}", fontSize = 12.sp)
            }

            DropdownMenu(
              expanded = isEncodingMenuOpen,
              onDismissRequest = { isEncodingMenuOpen = false }
            ) {
              TextCsvDocumentParser.SUPPORTED_ENCODINGS.forEach { enc ->
                DropdownMenuItem(
                  text = { Text(enc) },
                  onClick = {
                    onEncodingChange(enc)
                    isEncodingMenuOpen = false
                  }
                )
              }
            }
          }

          // Word wrap toggle
          if (tab.type == DocumentType.TEXT) {
            IconButton(
              onClick = onToggleWordWrap,
              modifier = Modifier
                .size(36.dp)
                .testTag("word_wrap_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.WrapText,
                contentDescription = stringResource(R.string.word_wrap),
                tint = if (tab.isWordWrap) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }

        // CSV delimiter picker
        if (tab.type == DocumentType.CSV) {
          Box {
            OutlinedButton(
              onClick = { isDelimiterMenuOpen = true },
              modifier = Modifier
                .height(34.dp)
                .testTag("csv_delimiter_button")
            ) {
              val delimName = when (tab.csvDelimiter) {
                ',' -> "Comma (,)"
                '\t' -> "Tab"
                ';' -> "Semicolon (;)"
                '|' -> "Pipe (|)"
                else -> "${tab.csvDelimiter}"
              }
              Text(delimName, fontSize = 12.sp)
            }

            DropdownMenu(
              expanded = isDelimiterMenuOpen,
              onDismissRequest = { isDelimiterMenuOpen = false }
            ) {
              mapOf(',' to "Comma (,)", '\t' to "Tab (\\t)", ';' to "Semicolon (;)", '|' to "Pipe (|)").forEach { (char, label) ->
                DropdownMenuItem(
                  text = { Text(label) },
                  onClick = {
                    onDelimiterChange(char)
                    isDelimiterMenuOpen = false
                  }
                )
              }
            }
          }
        }

        // Image rotation
        if (tab.type == DocumentType.IMAGE) {
          IconButton(
            onClick = onRotateImage,
            modifier = Modifier
              .size(36.dp)
              .testTag("image_rotate_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.RotateRight,
              contentDescription = stringResource(R.string.rotate),
              modifier = Modifier.size(20.dp)
            )
          }
        }

        // Search button
        IconButton(
          onClick = { isSearchExpanded = true },
          modifier = Modifier
            .size(36.dp)
            .testTag("document_search_button")
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = stringResource(R.string.search_hint),
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }

  // PDF Page Jump Dialog
  if (showPageJumpDialog && tab.content is PdfDocumentContent) {
    val pdf = tab.content
    var inputPage by remember { mutableStateOf("${tab.currentPage + 1}") }
    AlertDialog(
      onDismissRequest = { showPageJumpDialog = false },
      title = { Text(stringResource(R.string.page_jump)) },
      text = {
        OutlinedTextField(
          value = inputPage,
          onValueChange = { inputPage = it },
          label = { Text(stringResource(R.string.page_jump_hint, pdf.pageCount)) },
          singleLine = true
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val p = (inputPage.toIntOrNull() ?: 1) - 1
            if (p in 0 until pdf.pageCount) {
              onPageChange(p)
            }
            showPageJumpDialog = false
          }
        ) {
          Text(stringResource(R.string.confirm))
        }
      },
      dismissButton = {
        TextButton(onClick = { showPageJumpDialog = false }) {
          Text(stringResource(R.string.cancel))
        }
      }
    )
  }

  // Simplified view information modal
  if (showSimplifiedInfoDialog) {
    AlertDialog(
      onDismissRequest = { showSimplifiedInfoDialog = false },
      title = { Text(stringResource(R.string.simplified_view_badge)) },
      text = {
        Text(stringResource(R.string.simplified_view_desc))
      },
      confirmButton = {
        Button(onClick = { showSimplifiedInfoDialog = false }) {
          Text(stringResource(R.string.confirm))
        }
      }
    )
  }
}

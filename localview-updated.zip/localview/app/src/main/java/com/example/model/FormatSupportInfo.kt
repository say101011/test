package com.example.model

data class FormatCapability(
  val formatName: String,
  val extensions: String,
  val supportLevel: SupportLevel,
  val capabilities: List<String>,
  val limitations: List<String>,
  val licenseOrEngine: String
)

object FormatSupportMatrix {
  val items: List<FormatCapability> = listOf(
    FormatCapability(
      formatName = "PDF",
      extensions = ".pdf",
      supportLevel = SupportLevel.FULL,
      capabilities = listOf(
        "Native Android PdfRenderer page rendering",
        "Page number strip & direct page jump",
        "Pinch-to-zoom and zoom controls",
        "Page-aware search, positioned highlights and on-demand page OCR"
      ),
      limitations = listOf(
        "Automatic text extraction: up to 300 pages / 4 million characters; positioned highlights: up to 200,000 characters. Scan page runs local OCR for Latin, Korean, Chinese, Japanese or Devanagari; accuracy varies",
        "Form filling and digital signatures not supported locally"
      ),
      licenseOrEngine = "Android PdfRenderer; PDFBox-Android (Apache 2.0); Google ML Kit bundled OCR"
    ),
    FormatCapability(
      formatName = "Excel Spreadsheet",
      extensions = ".xlsx, .xls",
      supportLevel = SupportLevel.STRUCTURED,
      capabilities = listOf(
        "Multi-sheet switching",
        "Row and column headers (A, B... 1, 2...)",
        "Cached formula values, common custom number formats and merged cells",
        "Horizontal and vertical scrolling with virtualization"
      ),
      limitations = listOf(
        "VBA macros & live external data links are disabled for security",
        "No formula recalculation; missing cached results are marked. XLSX charts expose saved data; original chart graphics and advanced formatting are not reproduced. Preview limits: 64 sheets, 1,000 rows and 100 columns per sheet, 100,000 cells total"
      ),
      licenseOrEngine = "Built-in OOXML relationship parser and BIFF8 record reader"
    ),
    FormatCapability(
      formatName = "CSV Spreadsheet",
      extensions = ".csv",
      supportLevel = SupportLevel.FULL,
      capabilities = listOf(
        "Interactive tabular grid view",
        "Custom delimiters (comma, semicolon, tab, pipe)",
        "Multi-encoding support (UTF-8, UTF-16, CP949/EUC-KR)",
        "Instant text search and row filtering"
      ),
      limitations = listOf(
        "No cell formulas or styling (plain delimiter format)"
      ),
      licenseOrEngine = "Local RFC-4180 compliant streaming parser"
    ),
    FormatCapability(
      formatName = "Word Document",
      extensions = ".docx, .doc",
      supportLevel = SupportLevel.STRUCTURED,
      capabilities = listOf(
        "DOCX: basic paragraphs, headings, bold and italic",
        "DOCX: basic tables with rows and columns",
        "DOCX: referenced images in reading order; headers/footers shown once",
        "DOC: body text in piece-table order"
      ),
      limitations = listOf(
        "DOC: text only, table cells separated by tabs; no images, headers, notes or original styling. DOCX print layout and floating shapes are simplified"
      ),
      licenseOrEngine = "Built-in OpenXML DOM & OLE piece table parser"
    ),
    FormatCapability(
      formatName = "Hangul Word Processor (OWPML)",
      extensions = ".hwpx",
      supportLevel = SupportLevel.STRUCTURED,
      capabilities = listOf(
        "Korean KS X 6101 OWPML standard XML parsing",
        "Paragraphs in numeric section order",
        "Basic table grids with explicit cell coordinates",
        "Korean typography fallback support"
      ),
      limitations = listOf(
        "Merged layout, images, headers and print formatting are simplified; macros are excluded"
      ),
      licenseOrEngine = "OWPML Open Specification ZIP/XML Parser"
    ),
    FormatCapability(
      formatName = "Hangul Binary (HWP 5.0)",
      extensions = ".hwp",
      supportLevel = SupportLevel.SIMPLIFIED,
      capabilities = listOf(
        "OLE compound file decompression (Deflate Inflater)",
        "HWPTAG_PARA_TEXT extraction (UTF-16LE)",
        "Body sections read in numeric order",
        "Paragraphs and basic table grids with cell coordinates"
      ),
      limitations = listOf(
        "Merged/nested tables, images, headers, notes, margins and floating layout remain simplified",
        "Encrypted and distribution-protected HWP files are unsupported"
      ),
      licenseOrEngine = "HWP 5.0 Open Specification Native Decompressor"
    ),
    FormatCapability(
      formatName = "Markdown",
      extensions = ".md, .markdown",
      supportLevel = SupportLevel.FULL,
      capabilities = listOf(
        "Headings, bold, italic, blockquotes, code blocks",
        "Tables and task checkboxes",
        "Rendered view vs Raw source view toggle",
        "Strictly blocks remote image network requests for privacy"
      ),
      limitations = listOf(
        "Raw HTML scripts inside markdown are sanitized/stripped for security"
      ),
      licenseOrEngine = "Jetpack Compose Native Markdown Engine"
    ),
    FormatCapability(
      formatName = "Plain Text",
      extensions = ".txt, .log, .json, .xml",
      supportLevel = SupportLevel.FULL,
      capabilities = listOf(
        "Multi-encoding selector (UTF-8, UTF-16, CP949 / EUC-KR, Windows-1252)",
        "Word wrap toggle & font size adjustment",
        "In-document search and match navigation"
      ),
      limitations = listOf(
        "Text preview is limited to 8 MiB; larger files show an error"
      ),
      licenseOrEngine = "Standard Kotlin Charset Streams"
    ),
    FormatCapability(
      formatName = "Images",
      extensions = ".jpg, .jpeg, .png, .webp, .gif, .bmp",
      supportLevel = SupportLevel.FULL,
      capabilities = listOf(
        "High resolution decoding with safe sub-sampling (OOM safe)",
        "Pinch zoom, double-tap zoom, pan",
        "90-degree lossless rotation",
        "Fit to screen and 100% actual pixel mode"
      ),
      limitations = listOf(
        "Vector SVG formats without bitmap rasterization are viewed as XML text"
      ),
      licenseOrEngine = "Android BitmapFactory & Coil"
    )
  )
}

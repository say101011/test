package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "recent_documents", indices = [Index(value = ["uriString"], unique = true)])
data class RecentDocumentEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val uriString: String,
  val displayName: String,
  val mimeType: String,
  val extension: String,
  val fileSize: Long,
  val lastOpenedTimestamp: Long,
  val lastPage: Int = 0,
  val lastZoom: Float = 1.0f
)

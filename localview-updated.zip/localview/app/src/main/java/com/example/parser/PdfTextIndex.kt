package com.example.parser

import android.content.Context
import com.example.model.*
import kotlin.math.*
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File

object PdfTextIndex {
  data class Result(val pages: List<String>, val notice: String?, val geometry: List<PdfPageText> = emptyList())
  fun read(context: Context, file: File, pageCount: Int): Result {
    val pages = MutableList(pageCount) { "" }
    var indexed = 0; var failures = 0; var characters = 0
    var boxBudget = 200_000
    val geometry = MutableList(pageCount) { PdfPageText("", emptyList()) }
    try {
      PDFBoxResourceLoader.init(context.applicationContext)
      val scratch = File(context.cacheDir, "pdf_cache").apply { mkdirs() }
      PDDocument.load(file, MemoryUsageSetting.setupMixed(8L * 1024 * 1024, 128L * 1024 * 1024).setTempDir(scratch)).use { pdf ->
        if(!pdf.currentAccessPermission.canExtractContent()) return Result(pages, "This PDF does not permit text extraction. Search is unavailable.")
        for(index in 0 until minOf(pageCount, 300)) {
          DocumentIo.checkCancelled()
          try {
            val page = pdf.getPage(index)
            val collected = StringBuilder()
            val boxes = mutableListOf<PdfTextBox>()
            val stripper = object : PDFTextStripper() {
              override fun writeString(value: String, positions: MutableList<TextPosition>) {
                val base = collected.length
                collected.append(value)
                var cursor = 0
                for(position in positions) {
                  val glyph = position.unicode ?: continue
                  val at = value.indexOf(glyph, cursor)
                  if(at < 0 || glyph.isEmpty()) continue
                  cursor = at + glyph.length
                  if(boxBudget > 0) {
                    boxes.add(glyphBox(position, base + at, base + cursor, page.cropBox.width, page.cropBox.height, page.rotation))
                    boxBudget--
                  }
                }
              }
              override fun writeWordSeparator() { collected.append(' ') }
              override fun writeLineSeparator() { collected.append('\n') }
              override fun writeParagraphEnd() { if(collected.isNotEmpty() && collected.last() != '\n') collected.append('\n') }

              var glyphs = 0
              override fun processTextPosition(text: TextPosition) {
                DocumentIo.checkCancelled()
                require(++glyphs <= 100_000) { "Page text exceeds the extraction limit." }
                super.processTextPosition(text)
              }
            }.apply { startPage=index+1; endPage=index+1; sortByPosition=true }
            stripper.getText(pdf)
            val text = collected.toString()
            if(characters + text.length > 4_000_000) break
            pages[index] = text
            geometry[index] = PdfPageText(text, boxes)
            characters += text.length
          } catch(e: java.util.concurrent.CancellationException) { throw e }
          catch(_: Exception) { failures++ }
          indexed++
        }
      }
    } catch(e: java.util.concurrent.CancellationException) { throw e }
    catch(_: Exception) { return Result(pages, "PDF text extraction could not be completed. Search may be incomplete; visual pages remain available.") }
    val empty = pages.take(indexed).count { it.isBlank() }
    val notices = mutableListOf<String>()
    if(indexed < pageCount) notices.add("Search covers only the first $indexed of $pageCount pages due to extraction limits.")
    if(failures > 0) notices.add("Text extraction failed on $failures pages.")
    if(empty > 0) notices.add("$empty processed pages have no extractable text. Scanned text or unsupported font encodings require OCR, available from Scan page.")
    if(boxBudget == 0) notices.add("Search highlighting is limited to the first 200,000 positioned characters.")
    return Result(pages, notices.joinToString(" ").ifEmpty { null }, geometry)
  }
  private fun glyphBox(p: TextPosition, start: Int, end: Int, width: Float, height: Float, rotation: Int): PdfTextBox {
    val m = p.textMatrix
    val angle = atan2(m.shearY, m.scaleX)
    val dx = cos(angle) * p.widthDirAdj; val dy = sin(angle) * p.widthDirAdj
    val hx = -sin(angle) * p.heightDir * 1.25f; val hy = cos(angle) * p.heightDir * 1.25f
    val x = m.translateX; val y = m.translateY
    val rot = ((rotation % 360) + 360) % 360
    val w = if(rot == 90 || rot == 270) height else width
    val h = if(rot == 90 || rot == 270) width else height
    val points = listOf(x to y, x + dx to y + dy, x + hx to y + hy, x + dx + hx to y + dy + hy).map { (a,b) ->
      when(rot) { 90 -> b to a; 180 -> width-a to b; 270 -> height-b to width-a; else -> a to height-b }
    }
    return PdfTextBox(start,end,(points.minOf { it.first }/w).coerceIn(0f,1f),(points.minOf { it.second }/h).coerceIn(0f,1f),
      (points.maxOf { it.first }/w).coerceIn(0f,1f),(points.maxOf { it.second }/h).coerceIn(0f,1f))
  }
}

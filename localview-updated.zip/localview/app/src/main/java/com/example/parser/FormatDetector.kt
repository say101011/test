package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.DocumentType
import java.io.InputStream

object FormatDetector {

  fun detect(context: Context, uri: Uri, fallbackExtension: String?): DocumentType {
    var detectedByContent: DocumentType? = null
    try {
      context.contentResolver.openInputStream(uri)?.use { stream ->
        val header = ByteArray(512)
        val readBytes = stream.read(header)
        if (readBytes >= 4) {
          detectedByContent = detectByMagicBytes(header, readBytes)
        }
      }
    } catch (_: Exception) {
      // Stream reading error, will fallback
    }

    if (detectedByContent != null && detectedByContent != DocumentType.UNKNOWN) {
      // If it's a zip container, refine between DOCX, XLSX, HWPX
      if (detectedByContent == DocumentType.WORD ||
          detectedByContent == DocumentType.EXCEL ||
          detectedByContent == DocumentType.HWPX) {
        val refined = inspectZipStructure(context, uri)
        if (refined != null) return refined
      } else if (detectedByContent == DocumentType.HWP ||
                 detectedByContent == DocumentType.WORD ||
                 detectedByContent == DocumentType.EXCEL) {
        val refined = inspectOleStructure(context, uri)
        if (refined != null) return refined
      }
      return if (detectedByContent == DocumentType.HWP) DocumentType.fromExtension(fallbackExtension ?: "") else detectedByContent
    }

    // Fallback to extension
    if (!fallbackExtension.isNullOrBlank()) {
      val byExt = DocumentType.fromExtension(fallbackExtension)
      if (byExt != DocumentType.UNKNOWN) return byExt
    }

    // MIME type check
    try {
      val mime = context.contentResolver.getType(uri)
      if (!mime.isNullOrBlank()) {
        when {
          mime.contains("pdf") -> return DocumentType.PDF
          mime.contains("sheet") || mime.contains("excel") -> return DocumentType.EXCEL
          mime.contains("word") -> return DocumentType.WORD
          mime.contains("csv") -> return DocumentType.CSV
          mime.contains("markdown") -> return DocumentType.MARKDOWN
          mime.startsWith("text/") -> return DocumentType.TEXT
          mime.startsWith("image/") -> return DocumentType.IMAGE
        }
      }
    } catch (_: Exception) {}

    return DocumentType.UNKNOWN
  }

  private fun detectByMagicBytes(header: ByteArray, length: Int): DocumentType {
    // PDF: %PDF- (0x25, 0x50, 0x44, 0x46)
    if (header[0] == 0x25.toByte() && header[1] == 0x50.toByte() &&
        header[2] == 0x44.toByte() && header[3] == 0x46.toByte()) {
      return DocumentType.PDF
    }

    // PNG: 89 50 4E 47
    if (header[0] == 0x89.toByte() && header[1] == 0x50.toByte() &&
        header[2] == 0x4E.toByte() && header[3] == 0x47.toByte()) {
      return DocumentType.IMAGE
    }

    // JPEG: FF D8 FF
    if (header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte()) {
      return DocumentType.IMAGE
    }

    // GIF: GIF87a or GIF89a
    if (header[0] == 'G'.code.toByte() && header[1] == 'I'.code.toByte() && header[2] == 'F'.code.toByte()) {
      return DocumentType.IMAGE
    }

    // BMP: BM
    if (header[0] == 'B'.code.toByte() && header[1] == 'M'.code.toByte()) {
      return DocumentType.IMAGE
    }

    // WEBP: RIFF....WEBP
    if (length >= 12 &&
        header[0] == 'R'.code.toByte() && header[1] == 'I'.code.toByte() &&
        header[2] == 'F'.code.toByte() && header[3] == 'F'.code.toByte() &&
        header[8] == 'W'.code.toByte() && header[9] == 'E'.code.toByte() &&
        header[10] == 'B'.code.toByte() && header[11] == 'P'.code.toByte()) {
      return DocumentType.IMAGE
    }

    // ZIP (DOCX, XLSX, HWPX): PK\x03\x04
    if (header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
        header[2] == 0x03.toByte() && header[3] == 0x04.toByte()) {
      return DocumentType.WORD // Needs refinement
    }

    // OLE Compound Document (HWP 5.0, DOC, XLS): D0 CF 11 E0 A1 B1 1A E1
    if (header[0] == 0xD0.toByte() && header[1] == 0xCF.toByte() &&
        header[2] == 0x11.toByte() && header[3] == 0xE0.toByte()) {
      return DocumentType.HWP // Needs refinement
    }

    return DocumentType.UNKNOWN
  }

  private fun inspectZipStructure(context: Context, uri: Uri): DocumentType? {
    try {
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BoundedZipInputStream(stream).use { zis ->
          var entry = zis.nextEntry
          var count = 0
          while (entry != null && count < 25) {
            val name = entry.name.lowercase()
            if (name.startsWith("word/") || name.contains("document.xml")) {
              return DocumentType.WORD
            }
            if (name.startsWith("xl/") || name.contains("workbook.xml")) {
              return DocumentType.EXCEL
            }
            if (name.startsWith("contents/") || name.contains("section0.xml") || name.contains("content.hpf")) {
              return DocumentType.HWPX
            }
            entry = zis.nextEntry
            count++
          }
        }
      }
    } catch (_: Exception) {}
    return null
  }

  private fun inspectOleStructure(context: Context, uri: Uri): DocumentType? {
    try {
      context.contentResolver.openInputStream(uri)?.use { stream ->
        val names = CompoundDocument(DocumentIo.readLimited(stream)).names
        if ("FileHeader" in names && names.any { it.startsWith("BodyText/") || it.startsWith("ViewText/") }) return DocumentType.HWP
        if ("WordDocument" in names) return DocumentType.WORD
        if ("Workbook" in names || "Book" in names) return DocumentType.EXCEL
      }
    } catch (_: Exception) {}
    return null
  }
}

package com.example.ui.viewer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentTab
import com.example.model.ImageDocumentContent

@Composable
fun ImageViewer(
  tab: DocumentTab,
  content: ImageDocumentContent,
  onZoomChange: (Float) -> Unit
) {
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .pointerInput(Unit) {
        detectTapGestures(
          onDoubleTap = {
            if (tab.zoomLevel > 1.0f) {
              onZoomChange(1.0f)
              offsetX = 0f
              offsetY = 0f
            } else {
              onZoomChange(2.0f)
            }
          }
        )
      }
      .pointerInput(Unit) {
        detectTransformGestures { _, pan, zoom, _ ->
          val newZoom = (tab.zoomLevel * zoom).coerceIn(0.5f, 5.0f)
          onZoomChange(newZoom)
          if (newZoom > 1.0f) {
            offsetX += pan.x
            offsetY += pan.y
          } else {
            offsetX = 0f
            offsetY = 0f
          }
        }
      }
      .testTag("image_viewer"),
    contentAlignment = Alignment.Center
  ) {
    Image(
      bitmap = content.bitmap.asImageBitmap(),
      contentDescription = tab.displayName,
      modifier = Modifier
        .graphicsLayer {
          scaleX = tab.zoomLevel
          scaleY = tab.zoomLevel
          translationX = offsetX
          translationY = offsetY
        }
    )

    // Image resolution badge
    Surface(
      color = Color.Black.copy(alpha = 0.6f),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp)
    ) {
      Text(
        text = "${content.originalWidth} × ${content.originalHeight}",
        fontSize = 11.sp,
        color = Color.White,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
      )
    }
  }
}

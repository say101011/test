package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Splitscreen
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(
  onOpenFileClick: () -> Unit,
  onToggleSplitView: () -> Unit,
  isSplitView: Boolean,
  canSplit: Boolean,
  onSupportMatrixClick: () -> Unit,
  onSettingsClick: () -> Unit
) {
  TopAppBar(
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = stringResource(R.string.app_name),
          fontWeight = FontWeight.Bold,
          fontSize = 19.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(8.dp))
        // 100% On-Device privacy badge
        Box(
          modifier = Modifier
            .background(
              color = MaterialTheme.colorScheme.primaryContainer,
              shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              modifier = Modifier.size(12.dp),
              tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "On-Device",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
          }
        }
      }
    },
    actions = {
      IconButton(
        onClick = onOpenFileClick,
        modifier = Modifier.testTag("top_bar_open_button")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = stringResource(R.string.open_file),
          tint = MaterialTheme.colorScheme.primary
        )
      }

      if (canSplit) {
        IconButton(
          onClick = onToggleSplitView,
          modifier = Modifier.testTag("top_bar_split_button")
        ) {
          Icon(
            imageVector = Icons.Default.Splitscreen,
            contentDescription = stringResource(if (isSplitView) R.string.single_view else R.string.split_view),
            tint = if (isSplitView) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      IconButton(
        onClick = onSupportMatrixClick,
        modifier = Modifier.testTag("top_bar_support_button")
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.HelpOutline,
          contentDescription = stringResource(R.string.support_matrix_btn),
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      IconButton(
        onClick = onSettingsClick,
        modifier = Modifier.testTag("top_bar_settings_button")
      ) {
        Icon(
          imageVector = Icons.Default.Settings,
          contentDescription = stringResource(R.string.settings),
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    },
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.surface
    )
  )
}

package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.CellData
import com.example.model.CorruptedDocumentContent
import com.example.model.DocumentContent
import com.example.model.PlainTextDocumentContent
import com.example.model.SheetData
import com.example.model.SpreadsheetDocumentContent
import java.nio.charset.Charset

object TextCsvDocumentParser {

  val SUPPORTED_ENCODINGS = listOf(
    "Auto",
    "UTF-8",
    "CP949",
    "EUC-KR",
    "UTF-16LE",
    "UTF-16BE",
    "ISO-8859-1",
    "Windows-1252"
  )

  fun parse(
    context: Context,
    uri: Uri,
    isCsv: Boolean,
    preferredEncoding: String? = null,
    csvDelimiter: Char = ','
  ): DocumentContent {
    return try {
      val rawBytes = context.contentResolver.openInputStream(uri)?.use { stream ->
        DocumentIo.readLimited(stream)
      } ?: return CorruptedDocumentContent("Could not read file data.")

      val effectiveEncoding = preferredEncoding?.takeUnless { it == "Auto" } ?: detectEncoding(rawBytes)
      val charset = try {
        Charset.forName(effectiveEncoding)
      } catch (_: Exception) {
        Charsets.UTF_8
      }

      val decodedText = String(rawBytes, charset).removePrefix("\uFEFF")

      if (isCsv) {
        parseCsv(decodedText, csvDelimiter)
      } else {
        val lines = decodedText.lines()
        PlainTextDocumentContent(
          text = decodedText,
          lines = lines,
          encoding = effectiveEncoding
        )
      }
    } catch (e: Exception) {
      CorruptedDocumentContent("Text decoding error: ${e.localizedMessage}")
    }
  }

  fun parseCsv(text: String, delimiter: Char): SpreadsheetDocumentContent {
    val rows = mutableListOf<List<CellData>>()
    val tokens = mutableListOf<String>()
    val field = StringBuilder()
    var quoted = false
    var fieldStarted = false
    var recordStarted = false
    var cells = 0
    fun finishField() {
      require(++cells <= 100_000) { "CSV exceeds the 100,000-cell limit." }
      tokens.add(field.toString())
      field.setLength(0)
      fieldStarted = false
    }
    fun finishRow() {
      finishField()
      val row = rows.size
      rows.add(tokens.mapIndexed { col, value ->
        CellData(row, col, value, formattedValue = value, isBold = row == 0, isHeader = row == 0)
      })
      tokens.clear()
      recordStarted = false
    }
    val input = text.removePrefix("\uFEFF")
    var i = 0
    while (i < input.length) {
      if (i % 8192 == 0) DocumentIo.checkCancelled()
      val char = input[i]
      when {
        char == '"' && quoted -> {
          if (i + 1 < input.length && input[i + 1] == '"') { field.append('"'); i++ }
          else quoted = false
        }
        char == '"' && !fieldStarted -> { quoted = true; fieldStarted = true; recordStarted = true }
        char == delimiter && !quoted -> { finishField(); recordStarted = true }
        (char == '\n' || char == '\r') && !quoted -> {
          finishRow()
          if (char == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
        }
        else -> { field.append(char); fieldStarted = true; recordStarted = true }
      }
      i++
    }
    require(!quoted) { "CSV contains an unclosed quoted field." }
    if (recordStarted || tokens.isNotEmpty() || rows.isEmpty()) finishRow()

    if (rows.isEmpty()) {
      rows.add(listOf(CellData(0, 0, "")))
    }

    val maxCols = rows.maxOfOrNull { it.size } ?: 1
    val colHeaders = (0 until maxCols).map { getColumnName(it) }

    val sheet = SheetData(
      name = "CSV Data",
      maxRows = rows.size,
      maxCols = maxCols,
      columnHeaders = colHeaders,
      rows = rows
    )

    return SpreadsheetDocumentContent(
      sheets = listOf(sheet),
      activeSheetIndex = 0,
      isSimplified = false,
      noticeMessage = null
    )
  }

  private fun detectEncoding(bytes: ByteArray): String {
    if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
      return "UTF-8"
    }
    if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
      return "UTF-16LE"
    }
    if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
      return "UTF-16BE"
    }

    // Check if valid UTF-8
    if (isValidUtf8(bytes)) {
      return "UTF-8"
    }

    // Default to CP949 for Korean environment compatibility, or ISO-8859-1
    return "CP949"
  }

  private fun isValidUtf8(bytes: ByteArray): Boolean {
    var i = 0
    while (i < bytes.size) {
      val b = bytes[i].toInt() and 0xFF
      if (b <= 0x7F) {
        i++
      } else if ((b in 0xC2..0xDF) && i + 1 < bytes.size) {
        val b2 = bytes[i + 1].toInt() and 0xFF
        if (b2 !in 0x80..0xBF) return false
        i += 2
      } else if ((b in 0xE0..0xEF) && i + 2 < bytes.size) {
        val b2 = bytes[i + 1].toInt() and 0xFF
        val b3 = bytes[i + 2].toInt() and 0xFF
        if (b2 !in 0x80..0xBF || b3 !in 0x80..0xBF) return false
        i += 3
      } else if ((b in 0xF0..0xF4) && i + 3 < bytes.size) {
        val b2 = bytes[i + 1].toInt() and 0xFF
        val b3 = bytes[i + 2].toInt() and 0xFF
        val b4 = bytes[i + 3].toInt() and 0xFF
        if (b2 !in 0x80..0xBF || b3 !in 0x80..0xBF || b4 !in 0x80..0xBF) return false
        i += 4
      } else {
        return false
      }
    }
    return true
  }

  private fun getColumnName(colIndex: Int): String {
    var c = colIndex
    val sb = StringBuilder()
    while (c >= 0) {
      sb.insert(0, ('A'.code + (c % 26)).toChar())
      c = c / 26 - 1
    }
    return sb.toString()
  }
}

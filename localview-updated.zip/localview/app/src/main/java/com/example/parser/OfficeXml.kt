package com.example.parser

import android.content.Context
import android.net.Uri
import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory

internal object OfficeXml {
  fun parts(context: Context, uri: Uri): Map<String, ByteArray> {
    val parts = linkedMapOf<String,ByteArray>()
    context.contentResolver.openInputStream(uri)!!.use { stream -> BoundedZipInputStream(stream).use { zip ->
      var entry = zip.nextEntry
      while(entry != null) {
        if(!entry.isDirectory) parts[entry.name] = DocumentIo.readLimited(zip)
        entry = zip.nextEntry
      }
    } }
    return parts
  }
  fun parse(bytes: ByteArray): Element {
    val document=DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument()
    val parser=android.util.Xml.newPullParser()
    parser.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES,true)
    parser.setInput(bytes.inputStream(),null)
    val stack=mutableListOf<Element>();var nodes=0
    var event=parser.eventType
    while(event!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
      DocumentIo.checkCancelled()
      when(event) {
        org.xmlpull.v1.XmlPullParser.DOCDECL -> error("Document type declarations are not allowed.")
        org.xmlpull.v1.XmlPullParser.START_TAG -> {
          require(++nodes<=100_000 && stack.size<128) { "XML structure exceeds preview limits." }
          val element=document.createElementNS(parser.namespace.takeIf { it.isNotEmpty() },parser.name)
          for(i in 0 until parser.attributeCount) element.setAttributeNS(parser.getAttributeNamespace(i).takeIf { it.isNotEmpty() },parser.getAttributeName(i),parser.getAttributeValue(i))
          if(stack.isEmpty()) document.appendChild(element) else stack.last().appendChild(element)
          stack.add(element)
        }
        org.xmlpull.v1.XmlPullParser.END_TAG -> stack.removeAt(stack.lastIndex)
        org.xmlpull.v1.XmlPullParser.TEXT,org.xmlpull.v1.XmlPullParser.CDSECT,org.xmlpull.v1.XmlPullParser.ENTITY_REF -> {
          if(stack.isNotEmpty()) { require(++nodes<=100_000);stack.last().appendChild(document.createTextNode(parser.text ?: error("Unresolved XML entity."))) }
        }
      }
      event=parser.nextToken()
    }
    return document.documentElement ?: error("Empty XML part.")
  }

  fun children(element: Element): List<Element> = (0 until element.childNodes.length).mapNotNull { element.childNodes.item(it) as? Element }
  fun attr(element: Element, name: String): String = (0 until element.attributes.length).map { element.attributes.item(it) }
    .firstOrNull { (it.localName ?: it.nodeName.substringAfter(':')) == name }?.nodeValue ?: ""
  fun name(element: Element) = element.localName ?: element.tagName.substringAfter(':')
  fun descendants(element: Element, name: String): List<Element> {
    val result = mutableListOf<Element>()
    fun visit(e: Element, depth: Int) {
      DocumentIo.checkCancelled(); require(depth < 128) { "XML nesting is too deep." }
      if(OfficeXml.name(e)==name) result.add(e)
      children(e).forEach { visit(it,depth+1) }
    }
    visit(element,0); return result
  }
}

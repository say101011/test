package com.example.model

import android.net.Uri

data class DocumentTab(
  val id: String,
  val uri: Uri,
  val displayName: String,
  val fileSizeBytes: Long,
  val type: DocumentType,
  val content: DocumentContent? = null,
  val isLoading: Boolean = true,
  val errorMessage: String? = null,
  val zoomLevel: Float = 1.0f,
  val currentPage: Int = 0,
  val activeSheetIndex: Int = 0,
  val isMarkdownRendered: Boolean = true,
  val textEncoding: String = "Auto",
  val csvDelimiter: Char = ',',
  val isWordWrap: Boolean = true,
  val fontSizeSp: Float = 15f,
  val imageRotation: Int = 0,
  val searchQuery: String = "",
  val searchMatchCount: Int = 0
)

package com.example.parser

import android.graphics.Bitmap
import com.example.model.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class OcrScript(val label: String) { LATIN("Latin"), KOREAN("Korean"), CHINESE("Chinese"), JAPANESE("Japanese"), DEVANAGARI("Devanagari") }

object PdfOcr {
  /** Takes ownership of the bitmap. Native processing owns it until the completion listener runs. */
  suspend fun recognize(bitmap: Bitmap, script: OcrScript): PdfPageText = suspendCancellableCoroutine { continuation ->
    val recognizer = try {
      when(script) {
        OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        OcrScript.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        OcrScript.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        OcrScript.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
      }
    } catch(e: Exception) { bitmap.recycle(); continuation.resumeWithException(e); return@suspendCancellableCoroutine }
    try {
      recognizer.process(InputImage.fromBitmap(bitmap, 0)).addOnCompleteListener { task ->
        try {
          if(continuation.isActive) {
            if(!task.isSuccessful) continuation.resumeWithException(task.exception ?: IllegalStateException("OCR failed."))
            else {
              val text = StringBuilder(); val boxes = mutableListOf<PdfTextBox>()
              for(block in task.result.textBlocks) for(line in block.lines) {
                if(text.length > 100_000) break
                for(element in line.elements) {
                  val start = text.length; text.append(element.text)
                  element.boundingBox?.let { r -> boxes.add(PdfTextBox(start,text.length,
                    (r.left.toFloat()/bitmap.width).coerceIn(0f,1f),(r.top.toFloat()/bitmap.height).coerceIn(0f,1f),
                    (r.right.toFloat()/bitmap.width).coerceIn(0f,1f),(r.bottom.toFloat()/bitmap.height).coerceIn(0f,1f))) }
                  text.append(' ')
                }
                text.append('\n')
              }
              continuation.resume(PdfPageText(text.toString(),boxes,"OCR (${script.label})"))
            }
          }
        } catch(e: Exception) { if(continuation.isActive) continuation.resumeWithException(e) }
        finally { recognizer.close(); bitmap.recycle() }
      }
    } catch(e: Exception) { recognizer.close(); bitmap.recycle(); if(continuation.isActive) continuation.resumeWithException(e) }
  }
}

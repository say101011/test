package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.*
import com.example.parser.CompoundDocument.Companion.i32
import com.example.parser.CompoundDocument.Companion.u16

object LegacyXls {
  private data class Record(val offset: Int, val id: Int, val data: ByteArray)
  fun parse(context: Context, uri: Uri): DocumentContent = try {
    val cfb = context.contentResolver.openInputStream(uri)!!.use { CompoundDocument(DocumentIo.readLimited(it)) }
    val bytes = cfb.read(if ("Workbook" in cfb.names) "Workbook" else "Book")
    val records = mutableListOf<Record>(); var p = 0
    while(p + 4 <= bytes.size) {
      DocumentIo.checkCancelled()
      val size = u16(bytes, p + 2)
      require(p + 4 + size <= bytes.size) { "Truncated BIFF record." }
      records.add(Record(p, u16(bytes, p), bytes.copyOfRange(p + 4, p + 4 + size))); p += size + 4
      require(records.size <= 200_000) { "Too many BIFF records." }
    }
    require(records.firstOrNull()?.id == 0x809 && u16(records[0].data, 0) == 0x600) { "Only BIFF8 Excel 97–2003 workbooks are supported." }
    if(records.any { it.id == 0x2f }) EncryptedDocumentContent("Password-protected XLS workbooks are not supported.")
    else {
      val strings = mutableListOf<String>()
      val formats = records.filter { it.id == 0xe0 }.map { u16(it.data, 2) }
      val customFormats = records.filter { it.id == 0x41e }.associate { u16(it.data,0) to Segments(listOf(it.data.copyOfRange(2,it.data.size))).string() }
      val date1904 = records.firstOrNull { it.id == 0x22 }?.let { u16(it.data, 0) == 1 } ?: false
      val sstIndex = records.indexOfFirst { it.id == 0xfc }
      if(sstIndex >= 0) {
        val chunks = mutableListOf(records[sstIndex].data)
        var n = sstIndex + 1
        while(n < records.size && records[n].id == 0x3c) chunks.add(records[n++].data)
        val sst = Segments(chunks)
        sst.int(); val count = sst.int(); require(count in 0..100_000)
        repeat(count) { strings.add(sst.string()) }
      }
      val refs = records.filter { it.id == 0x85 }
      require(refs.size in 1..64) { "Invalid sheet count or more than 64 sheets." }
      var budget = 100_000
      val sheets = refs.map { ref ->
        val d = ref.data
        val offset = i32(d, 0); val length = d[6].toInt() and 255; val wide = d[7].toInt() and 1 != 0
        val name = String(d, 8, length * if(wide) 2 else 1, if(wide) Charsets.UTF_16LE else Charsets.ISO_8859_1)
        val start = records.indexOfFirst { it.offset == offset }
        require(start >= 0 && records[start].id == 0x809) { "Missing sheet stream: $name" }
        if(d[5].toInt() != 0 || budget <= 0) SheetData(name, 0, 0, emptyList(), emptyList(), "Sheet not displayed: unsupported sheet type or workbook preview limit reached.")
        else {
          val cells = mutableMapOf<Pair<Int, Int>, CellData>()
          var maxRow = 0; var maxCol = 0; var omitted = false; var specialFormula = false
          var textFormula: Triple<Int,Int,Int>? = null
          val merges = mutableListOf<MergedRegion>()
          fun put(row: Int, col: Int, value: String, xf: Int, numeric: Boolean) {
            require(row in 0..65535 && col in 0..255)
            maxRow = maxOf(maxRow, row); maxCol = maxOf(maxCol, col)
            if(row < 1000 && col < 100) cells[row to col] = CellData(row, col, value,
              if(numeric) SpreadsheetValues.format(value, formats.getOrNull(xf) ?: 0, date1904, customFormats[formats.getOrNull(xf) ?: 0]) else value)
          }
          for(recordIndex in start + 1 until records.size) {
            val r=records[recordIndex]
            DocumentIo.checkCancelled()
            if(r.id == 0xa) break
            val b = r.data
            when(r.id) {
              0x203 -> put(u16(b,0),u16(b,2),number(b,6),u16(b,4),true)
              0x27e -> put(u16(b,0),u16(b,2),rk(i32(b,6)),u16(b,4),true)
              0xbd -> { val row = u16(b,0); val first = u16(b,2); val last = u16(b,b.size-2); require(b.size == 6 + (last-first+1)*6); for(c in first..last) { val q=4+(c-first)*6; put(row,c,rk(i32(b,q+2)),u16(b,q),true) } }
              0xfd -> put(u16(b,0),u16(b,2),strings.getOrNull(i32(b,6)) ?: error("Invalid shared string."),u16(b,4),false)
              0x205 -> put(u16(b,0),u16(b,2),if(b[7].toInt()==0) if(b[6].toInt()==0) "FALSE" else "TRUE" else "[Excel error ${b[6].toInt() and 255}]",u16(b,4),false)
              0xe5 -> {
                val count=u16(b,0);require(b.size>=2+count*8 && merges.size+count<=10_000)
                repeat(count) { n -> val q=2+n*8;val r1=u16(b,q);val r2=u16(b,q+2);val c1=u16(b,q+4);val c2=u16(b,q+6)
                  require(r2>=r1 && c2>=c1 && c2<256)
                  merges.add(MergedRegion(r1,c1,r2,c2));maxRow=maxOf(maxRow,r2);maxCol=maxOf(maxCol,c2)
                }
              }
              0x207 -> textFormula?.let { (row,col,xf) ->
                val chunks=mutableListOf(b);var next=recordIndex+1
                while(next<records.size && records[next].id==0x3c) chunks.add(records[next++].data)
                put(row,col,Segments(chunks).string(),xf,false);textFormula=null
              }
              6 -> {
                val value = if(u16(b,12)==0xffff) {
                  specialFormula=true
                  if(b[6].toInt()==0) textFormula=Triple(u16(b,0),u16(b,2),u16(b,4))
                  when(b[6].toInt()) { 1 -> if(b[8].toInt()==0) "FALSE" else "TRUE"; 2 -> "[Formula error]"; 3 -> ""; else -> "[Missing cached text result]" }
                } else number(b,6)
                put(u16(b,0),u16(b,2),value,u16(b,4),u16(b,12)!=0xffff)
              }
              0x204, 0xd6 -> { omitted=true; put(u16(b,0),u16(b,2),"[Unsupported inline label]",u16(b,4),false) }
            }
          }
          val cols=minOf(maxCol+1,100,budget); val rows=minOf(maxRow+1,1000,budget/cols); budget-=rows*cols
          SpreadsheetLayout.coveredCells(merges,rows,cols)
          val notices=mutableListOf<String>()
          if(d[4].toInt()!=0) notices.add("Hidden worksheet in original workbook.")
          if(rows<maxRow+1 || cols<maxCol+1) notices.add("Partial preview: rows 1–$rows, columns A–${SpreadsheetValues.column(cols-1)}. Data extends to row ${maxRow+1}, column ${SpreadsheetValues.column(maxCol)}.")
          if(omitted || specialFormula) notices.add("Some inline labels or special formula results are not reproduced and are marked in their cells.")
          SheetData(name,rows,cols,(0 until cols).map(SpreadsheetValues::column),(0 until rows).map { row -> (0 until cols).map { col -> cells[row to col] ?: CellData(row,col,"") } },notices.joinToString(" ").ifEmpty { null }, merges.filter { it.firstRow<rows && it.firstCol<cols })
        }
      }
      SpreadsheetDocumentContent(sheets,isSimplified=true,noticeMessage="BIFF8 values preview preserves sheet order and cell coordinates. Formulas use saved numeric, text and Boolean results; no recalculation. Charts, macros, advanced custom formats and print formatting are not reproduced. Tap a cell for its full value.")
    }
  } catch(e: java.util.concurrent.CancellationException) { throw e }
  catch(e: Exception) { CorruptedDocumentContent("Unable to read XLS: ${e.message}") }

  private fun number(b: ByteArray,p:Int):String { val bits=(i32(b,p).toLong() and 0xffffffffL) or (i32(b,p+4).toLong() shl 32); return java.lang.Double.longBitsToDouble(bits).toString() }
  private fun rk(bits:Int):String { var value=if(bits and 2 != 0) (bits shr 2).toDouble() else java.lang.Double.longBitsToDouble((bits.toLong() and 0xfffffffcL) shl 32); if(bits and 1 != 0) value/=100; return value.toString() }
  private class Segments(private val chunks:List<ByteArray>) {
    private var chunk=0; private var pos=0
    private fun next() { chunk++; pos=0; require(chunk<chunks.size) { "Truncated shared string." } }
    private fun byte():Int { if(pos==chunks[chunk].size) next(); return chunks[chunk][pos++].toInt() and 255 }
    fun int():Int = byte() or (byte() shl 8) or (byte() shl 16) or (byte() shl 24)
    private fun short():Int = byte() or (byte() shl 8)
    fun string():String {
      val count=short(); val flags=byte(); var wide=flags and 1 != 0
      val runs=if(flags and 8 != 0) short() else 0; val ext=if(flags and 4 != 0) int() else 0
      require(ext in 0..8_000_000)
      val text=StringBuilder()
      repeat(count) { if(pos==chunks[chunk].size) { next(); wide=byte() and 1 != 0 }; val lo=byte(); text.append((if(wide) lo or (byte() shl 8) else lo).toChar()) }
      repeat(runs*4+ext) { byte() }
      return text.toString()
    }
  }
}

package com.example.parser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import com.example.model.CorruptedDocumentContent
import com.example.model.DocumentContent
import com.example.model.ImageDocumentContent

object ImageDocumentParser {

  fun parse(context: Context, uri: Uri, rotation: Int = 0): DocumentContent {
    return try {
      val options = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
      }
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, options)
      }

      val origW = options.outWidth
      val origH = options.outHeight

      if (origW <= 0 || origH <= 0) {
        return CorruptedDocumentContent("Invalid or unsupported image dimensions.")
      }

      // Calculate safe sample size (limit max dimension to 3000px to prevent OOM)
      var sampleSize = 1
      while ((origW / sampleSize) > 3000 || (origH / sampleSize) > 3000) {
        sampleSize *= 2
      }

      val decodeOptions = BitmapFactory.Options().apply {
        inSampleSize = sampleSize
        inPreferredConfig = Bitmap.Config.ARGB_8888
      }

      val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, decodeOptions)
      } ?: return CorruptedDocumentContent("Failed to decode image data.")

      val finalBitmap = if (rotation != 0) {
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
      } else {
        rawBitmap
      }

      ImageDocumentContent(
        bitmap = finalBitmap,
        originalWidth = origW,
        originalHeight = origH,
        rotationDegrees = rotation
      )
    } catch (e: Exception) {
      CorruptedDocumentContent("Error loading image: ${e.localizedMessage}")
    }
  }
}

package com.example.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentTab
import com.example.model.MarkdownBlock
import com.example.model.MarkdownDocumentContent

@Composable
fun MarkdownViewer(
  tab: DocumentTab,
  content: MarkdownDocumentContent
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("markdown_viewer")
  ) {
    if (tab.isMarkdownRendered) {
      // Rendered View
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        items(content.blocks) { block ->
          RenderMarkdownBlock(block = block, searchQuery = tab.searchQuery)
          Spacer(modifier = Modifier.height(10.dp))
        }
      }
    } else {
      // Raw Source View
      val lines = content.rawText.lines()
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
          .padding(8.dp)
      ) {
        items(lines.size) { lineIdx ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
          ) {
            Text(
              text = "${lineIdx + 1}",
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.width(36.dp)
            )
            Text(
              text = highlightSearch(lines[lineIdx], tab.searchQuery),
              fontFamily = FontFamily.Monospace,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun RenderMarkdownBlock(block: MarkdownBlock, searchQuery: String) {
  when (block) {
    is MarkdownBlock.Heading -> {
      val (fontSize, weight) = when (block.level) {
        1 -> Pair(22.sp, FontWeight.Bold)
        2 -> Pair(18.sp, FontWeight.Bold)
        3 -> Pair(16.sp, FontWeight.SemiBold)
        else -> Pair(14.sp, FontWeight.SemiBold)
      }
      Text(
        text = highlightSearch(block.text, searchQuery),
        fontSize = fontSize,
        fontWeight = weight,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
      )
    }
    is MarkdownBlock.Paragraph -> {
      Text(
        text = highlightSearch(block.text, searchQuery),
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 22.sp
      )
    }
    is MarkdownBlock.CodeBlock -> {
      Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          if (block.language.isNotBlank()) {
            Text(
              text = block.language.uppercase(),
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF94A3B8),
              modifier = Modifier.padding(bottom = 6.dp)
            )
          }
          Text(
            text = block.code,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = Color(0xFFF8FAFC),
            lineHeight = 18.sp
          )
        }
      }
    }
    is MarkdownBlock.BlockQuote -> {
      Row(modifier = Modifier.fillMaxWidth()) {
        Box(
          modifier = Modifier
            .width(4.dp)
            .height(28.dp)
            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = highlightSearch(block.text, searchQuery),
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
        )
      }
    }
    is MarkdownBlock.ListItem -> {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = (block.level * 16).dp),
        verticalAlignment = Alignment.Top
      ) {
        Text(
          text = if (block.isOrdered) "${block.index}." else "•",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.width(20.dp)
        )
        Text(
          text = highlightSearch(block.text, searchQuery),
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.weight(1f)
        )
      }
    }
    is MarkdownBlock.ChecklistItem -> {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = if (block.isChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
          contentDescription = null,
          tint = if (block.isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(end = 8.dp)
        )
        Text(
          text = highlightSearch(block.text, searchQuery),
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    }
    is MarkdownBlock.Table -> {
      Surface(
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          if (block.headers.isNotEmpty()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(vertical = 6.dp)
            ) {
              block.headers.forEach { header ->
                Text(
                  text = header,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
                )
              }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
          }

          block.rows.forEachIndexed { rIdx, row ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(if (rIdx % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                .padding(vertical = 6.dp)
            ) {
              row.forEach { cell ->
                Text(
                  text = highlightSearch(cell, searchQuery),
                  fontSize = 11.sp,
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
                )
              }
            }
            if (rIdx < block.rows.size - 1) {
              HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            }
          }
        }
      }
    }
  }
}

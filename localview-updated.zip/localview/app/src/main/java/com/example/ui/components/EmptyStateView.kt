package com.example.ui.components

import androidx.core.net.toUri
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.RecentDocumentEntity
import com.example.model.DocumentType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EmptyStateView(
  onOpenFileClick: () -> Unit,
  onLoadSample: (String) -> Unit,
  recentDocuments: List<RecentDocumentEntity>,
  onOpenRecent: (Uri, String, Long) -> Unit,
  onRemoveRecent: (String) -> Unit = {},
  onReselectRecent: (String) -> Unit = {}
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp, vertical = 16.dp)
      .testTag("empty_state_view"),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    item {
      Spacer(modifier = Modifier.height(24.dp))

      // Hero Icon
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.FileOpen,
          contentDescription = null,
          modifier = Modifier.size(40.dp),
          tint = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = stringResource(R.string.empty_open_prompt),
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = stringResource(R.string.empty_supported_formats),
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 16.dp)
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Primary Open File Button
      Button(
        onClick = onOpenFileClick,
        modifier = Modifier
          .fillMaxWidth(0.8f)
          .height(48.dp)
          .testTag("empty_state_open_button"),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.open_file),
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Sample documents section
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.Science,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
          tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.sample_files),
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = false,
          onClick = { onLoadSample("pdf") },
          label = { Text("PDF Sample") },
          modifier = Modifier.testTag("sample_chip_pdf")
        )
        FilterChip(
          selected = false,
          onClick = { onLoadSample("xlsx") },
          label = { Text("Excel (XLSX)") },
          modifier = Modifier.testTag("sample_chip_xlsx")
        )
        FilterChip(
          selected = false,
          onClick = { onLoadSample("docx") },
          label = { Text("Word (DOCX)") },
          modifier = Modifier.testTag("sample_chip_docx")
        )
        FilterChip(
          selected = false,
          onClick = { onLoadSample("hwpx") },
          label = { Text("Hangul (HWPX)") },
          modifier = Modifier.testTag("sample_chip_hwpx")
        )
        FilterChip(
          selected = false,
          onClick = { onLoadSample("csv") },
          label = { Text("CSV Data") },
          modifier = Modifier.testTag("sample_chip_csv")
        )
        FilterChip(
          selected = false,
          onClick = { onLoadSample("md") },
          label = { Text("Markdown") },
          modifier = Modifier.testTag("sample_chip_md")
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Recent documents section
      if (recentDocuments.isNotEmpty()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            Icons.Default.History,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = stringResource(R.string.recent_files),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    if (recentDocuments.isNotEmpty()) {
      items(recentDocuments) { doc ->
        RecentDocItem(
          doc = doc,
          onClick = { onOpenRecent(doc.uriString.toUri(), doc.displayName, doc.fileSize) },
          onRemove = { onRemoveRecent(doc.uriString) },
          onReselect = { onReselectRecent(doc.uriString) }
        )
        Spacer(modifier = Modifier.height(6.dp))
      }
    }

    item {
      Spacer(modifier = Modifier.height(20.dp))
      // Privacy Assurance Tag
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 12.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Lock,
          contentDescription = null,
          modifier = Modifier.size(14.dp),
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Documents are processed on your device",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
      }
    }
  }
}

@Composable
private fun RecentDocItem(
  doc: RecentDocumentEntity,
  onClick: () -> Unit,
  onRemove: () -> Unit,
  onReselect: () -> Unit
) {
  val type = DocumentType.fromExtension(doc.extension)
  val dateStr = remember(doc.lastOpenedTimestamp) {
    val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
    sdf.format(Date(doc.lastOpenedTimestamp))
  }

  val formattedSize = remember(doc.fileSize) {
    if (doc.fileSize <= 0) ""
    else if (doc.fileSize < 1024) "${doc.fileSize} B"
    else if (doc.fileSize < 1024 * 1024) "${doc.fileSize / 1024} KB"
    else String.format(Locale.US, "%.1f MB", doc.fileSize / (1024.0 * 1024.0))
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag("recent_item_${doc.id}"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(8.dp)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      FormatBadge(type = type)
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = doc.displayName,
          fontWeight = FontWeight.Medium,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Row {
          Text(
            text = dateStr,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          if (formattedSize.isNotEmpty()) {
            Text(
              text = " • $formattedSize",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
      IconButton(onClick = onReselect, modifier = Modifier.testTag("reselect_recent_" + doc.id)) { Icon(Icons.Default.FileOpen, contentDescription = "Select file again: " + doc.displayName) }
      IconButton(onClick = onRemove, modifier = Modifier.testTag("remove_recent_" + doc.id)) { Icon(Icons.Default.Delete, contentDescription = "Remove recent entry: " + doc.displayName) }
    }
  }
}

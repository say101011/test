package com.example.model

enum class DocumentType(
  val displayName: String,
  val extensions: List<String>,
  val supportLevel: SupportLevel
) {
  PDF("PDF", listOf("pdf"), SupportLevel.FULL),
  EXCEL("Excel", listOf("xlsx", "xls"), SupportLevel.STRUCTURED),
  CSV("CSV", listOf("csv"), SupportLevel.FULL),
  WORD("Word", listOf("docx", "doc"), SupportLevel.STRUCTURED),
  HWP("HWP", listOf("hwp"), SupportLevel.SIMPLIFIED),
  HWPX("HWPX", listOf("hwpx"), SupportLevel.STRUCTURED),
  MARKDOWN("Markdown", listOf("md", "markdown"), SupportLevel.FULL),
  TEXT("Text", listOf("txt", "log", "ini", "json", "xml"), SupportLevel.FULL),
  IMAGE("Image", listOf("jpg", "jpeg", "png", "webp", "gif", "bmp"), SupportLevel.FULL),
  UNKNOWN("Unknown", emptyList(), SupportLevel.UNSUPPORTED);

  companion object {
    fun fromExtension(ext: String): DocumentType {
      val lower = ext.lowercase().trim().substringAfterLast('.').removePrefix(".")
      return entries.find { it.extensions.contains(lower) } ?: UNKNOWN
    }
  }
}

enum class SupportLevel {
  FULL,        // Complete rendering (PDF, Images, Markdown, TXT, CSV)
  STRUCTURED,  // High-fidelity structured text/tables/images/sheets (DOCX, XLSX, HWPX)
  SIMPLIFIED,  // Local extraction of text, tables, sections (HWP 5.0, DOC, XLS)
  UNSUPPORTED  // Not supported locally
}

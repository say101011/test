package com.example

import android.content.Context
import android.content.Intent
import androidx.core.net.toUri
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import androidx.appcompat.app.AppCompatActivity

/** Offline policy with optional HTTPS publication URL configured in privacy_config.xml. */
class PrivacyPolicyActivity : AppCompatActivity() {
  private var webView: WebView? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    webView = WebView(this).apply {
      settings.javaScriptEnabled = false
      settings.allowFileAccess = false
      settings.allowContentAccess = false
      webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
          val uri = request.url
          if (uri.host == "appassets.androidplatform.net" && uri.path == "/privacy/") return false
          if (uri.scheme == "https" || uri.scheme == "mailto") {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            catch (_: android.content.ActivityNotFoundException) {
              android.widget.Toast.makeText(this@PrivacyPolicyActivity, R.string.browser_unavailable, android.widget.Toast.LENGTH_LONG).show()
            }
          }
          return true
        }
      }
      val html = assets.open("privacy/index.html").bufferedReader().use { it.readText() }
      loadDataWithBaseURL("https://appassets.androidplatform.net/privacy/", html, "text/html", "UTF-8", null)
    }
    setContentView(webView!!)
    androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(webView!!) { view, insets ->
      val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
      view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
      insets
    }
  }

  override fun onDestroy() {
    webView?.destroy()
    webView = null
    super.onDestroy()
  }

  companion object {
    fun open(context: Context) {
      val uri = context.getString(R.string.privacy_policy_url).trim().toUri()
      if (uri.scheme == "https" && !uri.host.isNullOrBlank()) {
        try {
          context.startActivity(Intent(Intent.ACTION_VIEW, uri))
          return
        } catch (_: android.content.ActivityNotFoundException) { /* Use bundled policy. */ }
      }
      context.startActivity(Intent(context, PrivacyPolicyActivity::class.java))
    }
  }
}

package com.example.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import com.example.model.CellData
import com.example.model.DocumentTab
import com.example.model.SpreadsheetDocumentContent

@Composable
fun SpreadsheetViewer(
  tab: DocumentTab,
  content: SpreadsheetDocumentContent,
  onSheetChange: (Int) -> Unit
) {
  val activeSheet = content.sheets.getOrNull(tab.activeSheetIndex)
    ?: content.sheets.firstOrNull()

  val rowsState = rememberLazyListState()
  val visibleRange by remember(rowsState) { derivedStateOf {
    val items=rowsState.layoutInfo.visibleItemsInfo
    items.firstOrNull()?.index?.let { it to items.last().index }
  } }
  val density = LocalDensity.current
  var chartDialog by remember { mutableStateOf(false) }
  val coveredCells = remember(activeSheet) { activeSheet?.let { com.example.parser.SpreadsheetLayout.coveredCells(it.mergedRegions,it.maxRows,it.maxCols) }.orEmpty() }
  LaunchedEffect(tab.activeSheetIndex) { rowsState.scrollToItem(0) }
  val horizontalScrollState = rememberScrollState()
  var selectedCell by remember(tab.id, tab.activeSheetIndex) { mutableStateOf<CellData?>(null) }
  selectedCell?.let { cell -> AlertDialog(
    onDismissRequest = { selectedCell = null },
    title = { Text(com.example.parser.SpreadsheetValues.column(cell.col) + (cell.row + 1)) },
    text = { androidx.compose.foundation.text.selection.SelectionContainer { Text(cell.formattedValue, modifier = Modifier.verticalScroll(rememberScrollState())) } },
    confirmButton = { TextButton(onClick = { selectedCell = null }) { Text("Close") } }
  ) }
  val notice = listOfNotNull(content.noticeMessage, activeSheet?.noticeMessage).joinToString(" ")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("spreadsheet_viewer_container")
  ) {
    if (notice.isNotBlank()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFFEF3C7))
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Text(
          text = notice,
          fontSize = 11.sp,
          color = Color(0xFF92400E)
        )
      }
    }

    if (activeSheet == null || activeSheet.rows.isEmpty()) {
      Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Text("No sheet data available", color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    } else {

    // Sheet Grid with Sticky Headers
    Box(modifier = Modifier.weight(1f)) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .horizontalScroll(horizontalScrollState)
      ) {
        // Sticky Column Header (A, B, C...)
        Row(
          modifier = Modifier
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .height(30.dp)
        ) {
          // Top-left corner box
          Box(
            modifier = Modifier
              .width(42.dp)
              .height(30.dp)
              .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
              .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
          ) {
            Text("#", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          // Column letters
          activeSheet.columnHeaders.forEach { colName ->
            Box(
              modifier = Modifier
                .width(110.dp)
                .height(30.dp)
                .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                .background(MaterialTheme.colorScheme.surfaceVariant),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = colName,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Virtualized Rows
        Box(Modifier.weight(1f).clipToBounds()) {
        LazyColumn(state = rowsState, modifier = Modifier.fillMaxSize().testTag("spreadsheet_rows")) {
          itemsIndexed(activeSheet.rows) { rowIndex, rowCells ->
            Row(
              modifier = Modifier.height(32.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Sticky Row Number
              Box(
                modifier = Modifier
                  .width(42.dp)
                  .height(32.dp)
                  .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                  .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "${rowIndex + 1}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Medium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              // Data Cells
              rowCells.forEach { cell ->
                val isMatch = tab.searchQuery.isNotBlank() &&
                  cell.formattedValue.contains(tab.searchQuery, ignoreCase = true)

                val cellBg = when {
                  isMatch -> Color(0xFFFEF08A)
                  cell.isHeader -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                  else -> MaterialTheme.colorScheme.surface
                }

                Box(
                  modifier = Modifier
                    .width(110.dp)
                    .height(32.dp)
                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    .background(cellBg)
                    .then(if(cell.row * activeSheet.maxCols + cell.col in coveredCells) Modifier.clearAndSetSemantics {} else Modifier)
                    .clickable { selectedCell = cell }
                    .padding(horizontal = 6.dp),
                  contentAlignment = Alignment.CenterStart
                ) {
                  Text(
                    text = cell.formattedValue,
                    fontSize = 12.sp,
                    fontWeight = if (cell.isBold || cell.isHeader) FontWeight.SemiBold else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }
            }
          }
        }
        val range=visibleRange
        if(range != null) activeSheet.mergedRegions.filter { it.lastRow >= range.first && it.firstRow <= range.second }.forEach { region ->
          val cell = activeSheet.rows.getOrNull(region.firstRow)?.getOrNull(region.firstCol)
          val width = 110.dp * (minOf(region.lastCol,activeSheet.maxCols-1)-region.firstCol+1)
          val height = 32.dp * (minOf(region.lastRow,activeSheet.maxRows-1)-region.firstRow+1)
          Box(Modifier.testTag("merged_cell_${region.firstRow}_${region.firstCol}").offset {
            with(density) { IntOffset((42.dp+110.dp*region.firstCol).roundToPx(),
              (32.dp*(region.firstRow-rowsState.firstVisibleItemIndex)).roundToPx()-rowsState.firstVisibleItemScrollOffset) }
          }.width(width).height(height)
            .background(if(tab.searchQuery.isNotBlank() && cell?.formattedValue?.contains(tab.searchQuery,true)==true) Color(0xFFFEF08A) else MaterialTheme.colorScheme.surface)
            .border(0.5.dp,MaterialTheme.colorScheme.outline.copy(alpha=0.3f)).clickable { selectedCell=cell }.padding(6.dp)) {
              Text(cell?.formattedValue.orEmpty(),fontSize=12.sp,overflow=TextOverflow.Ellipsis)
          }
        }
        }
      }
    }

    }
    if(activeSheet?.charts?.isNotEmpty()==true) TextButton(onClick={chartDialog=true}) { Text("View charts ("+activeSheet.charts.size+")") }
    if(chartDialog && activeSheet!=null) AlertDialog(onDismissRequest={chartDialog=false}, title={Text("Charts and saved values")}, text={
      Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState())) {
        Text("Saved chart values; external data and formulas are not refreshed.")
        activeSheet.charts.forEach { chart ->
          Text(chart.title, fontWeight=FontWeight.Bold)
          chart.preview?.let { ChartPreviewView(it) }
            ?: Text("A graphical preview is unavailable for this chart. Saved values are shown below.")
          chart.rows.forEach { Text(it.joinToString(" | ")) }
        }
      }
    },confirmButton={TextButton(onClick={chartDialog=false}) {Text("Close")}})
    // Bottom Sheet Tabs remain available even when the current sheet has no preview.
    if (content.sheets.size > 1) {
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
          horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
        ) {
          itemsIndexed(content.sheets) { sIdx, sheet ->
            val isSelected = sIdx == tab.activeSheetIndex
            FilterChip(
              selected = isSelected,
              onClick = { onSheetChange(sIdx) },
              label = {
                Text(sheet.name, fontSize = 12.sp)
              }
            )
          }
        }
      }
    }
  }
}

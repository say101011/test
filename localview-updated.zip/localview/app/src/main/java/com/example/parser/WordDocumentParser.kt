package com.example.parser

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.model.*
import org.w3c.dom.Element
import java.net.URI
import com.example.parser.OfficeXml.attr
import com.example.parser.OfficeXml.children
import com.example.parser.OfficeXml.name
import com.example.parser.OfficeXml.descendants

object WordDocumentParser {
  fun parse(context: Context, uri: Uri, isLegacyDoc: Boolean): DocumentContent {
    if(isLegacyDoc) return LegacyDocuments.doc(context,uri)
    return try {
      val parts = OfficeXml.parts(context,uri)
      val root = OfficeXml.parse(parts["word/document.xml"] ?: error("Missing document.xml"))
      val blocks = mutableListOf<DocBlock>()
      var imageBytes = 0L
      var omitted = false
      fun relationships(part: String): Map<String,String> {
        val path = part.substringBeforeLast('/')+"/_rels/"+part.substringAfterLast('/')+".rels"
        return parts[path]?.let { bytes -> descendants(OfficeXml.parse(bytes),"Relationship").filter { attr(it,"TargetMode") != "External" }
          .associate { attr(it,"Id") to URI(part).resolve(attr(it,"Target")).normalize().path.removePrefix("/") } } ?: emptyMap()
      }
      fun image(id: String, rels: Map<String,String>) {
        val path = rels[id] ?: return
        val data = parts[path] ?: return
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds=true }
        BitmapFactory.decodeByteArray(data,0,data.size,bounds)
        if(bounds.outWidth <= 0 || bounds.outHeight <= 0) { omitted=true; return }
        var sample=1
        while(bounds.outWidth/sample>1200 || bounds.outHeight/sample>1200) sample*=2
        val estimate=(bounds.outWidth/sample).toLong()*(bounds.outHeight/sample)*4
        if(imageBytes+estimate>16L*1024*1024) { omitted=true; return }
        BitmapFactory.decodeByteArray(data,0,data.size,BitmapFactory.Options().apply { inSampleSize=sample })?.let {
          imageBytes += it.allocationByteCount; blocks.add(DocBlock.EmbeddedImage(it,path.substringAfterLast('/')))
        }
      }
      fun cellText(cell: Element): String = descendants(cell,"p").joinToString("\n") { p -> descendants(p,"t").joinToString("") { it.textContent } }
      fun read(container: Element, rels: Map<String,String>, depth: Int = 0) {
        require(depth<128) { "Document nesting is too deep." }
        for(e in children(container)) {
          DocumentIo.checkCancelled()
          when(name(e)) {
            "p" -> {
              val text=StringBuilder(); val styles=mutableListOf<TextStyleRange>()
              val heading=descendants(e,"pStyle").firstOrNull()?.let { attr(it,"val").takeIf { value -> value.startsWith("Heading",true) }?.filter(Char::isDigit)?.toIntOrNull() } ?: 0
              fun flush() {
                if(text.isNotEmpty()) blocks.add(if(heading>0) DocBlock.Heading(heading,text.toString()) else DocBlock.Paragraph(text.toString(),styles=styles.toList()))
                text.clear();styles.clear()
              }
              fun run(node: Element, depth: Int) {
                require(depth<128)
                when(name(node)) {
                  "del", "instrText" -> return
                  "r" -> {
                    val props=children(node).firstOrNull { name(it)=="rPr" }
                    fun enabled(tag: String)=props?.let { children(it).firstOrNull { p -> name(p)==tag } }?.let { attr(it,"val") !in listOf("0","false","off") } ?: false
                    val bold=enabled("b");val italic=enabled("i")
                    for(child in children(node)) {
                      val start=text.length
                      run(child,depth+1)
                      if(text.length>start && (bold||italic)) styles.add(TextStyleRange(start,text.length,bold,italic))
                    }
                  }
                  "t" -> text.append(node.textContent)
                  "tab" -> text.append('\t')
                  "br", "cr" -> text.append('\n')
                  "drawing", "pict" -> {
                    flush()
                    descendants(node,"blip").forEach { image(attr(it,"embed"),rels) }
                    descendants(node,"imagedata").forEach { image(attr(it,"id"),rels) }
                  }
                  else -> children(node).forEach { run(it,depth+1) }
                }
              }
              children(e).filter { name(it)!="pPr" }.forEach { run(it,0) }; flush()
            }
            "tbl" -> {
              val rows=children(e).filter { name(it)=="tr" }.map { row ->
                buildList { for(cell in children(row).filter { name(it)=="tc" }) {
                  add(cellText(cell))
                  val span=descendants(cell,"gridSpan").firstOrNull()?.let { attr(it,"val").toIntOrNull() }?.coerceIn(1,100) ?: 1
                  repeat(span-1) { add("") }
                } }
              }
              blocks.add(DocBlock.Table(emptyList(),rows))
              if(descendants(e,"gridSpan").isNotEmpty()||descendants(e,"vMerge").isNotEmpty()) omitted=true
              descendants(e,"blip").forEach { image(attr(it,"embed"),rels) }
            }
            else -> read(e,rels,depth+1)
          }
        }
      }
      val rels=relationships("word/document.xml")
      val headers=descendants(root,"headerReference").mapNotNull { rels[attr(it,"id")] }.distinct()
      val footers=descendants(root,"footerReference").mapNotNull { rels[attr(it,"id")] }.distinct()
      for(path in headers) parts[path]?.let { blocks.add(DocBlock.Heading(3,"Header")); read(OfficeXml.parse(it),relationships(path)) }
      children(root).firstOrNull { name(it)=="body" }?.let { read(it,rels) } ?: error("Missing document body")
      for(path in footers) parts[path]?.let { blocks.add(DocBlock.Heading(3,"Footer")); read(OfficeXml.parse(it),relationships(path)) }
      StructuredTextDocumentContent(DocumentType.WORD,blocks,true,
        "Reading-order preview with run styles, paragraph breaks, referenced images, tables, and headers/footers shown once. Original pagination, floating positions and merged table layout are simplified." + if(omitted) " Some image or table formatting was limited." else "")
    } catch(e: java.util.concurrent.CancellationException) { throw e }
    catch(e: Exception) { CorruptedDocumentContent("Unable to read DOCX: ${e.message}") }
  }
}

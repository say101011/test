package com.example.parser

import java.io.ByteArrayOutputStream

/** Bounded CFB v3/v4 reader. Resolves FAT, MiniFAT and directory storage paths. */
class CompoundDocument(private val bytes: ByteArray) {
  private val sectorSize: Int
  private val fat: IntArray
  private val miniFat: IntArray
  private val miniStream: ByteArray
  private data class Entry(val name: String, val type: Int, val left: Int, val right: Int,
    val child: Int, val start: Int, val size: Int)
  private val streams = linkedMapOf<String, Entry>()
  val names: Set<String> get() = streams.keys

  init {
    require(bytes.size >= 512 && bytes.copyOfRange(0, 8).contentEquals(
      byteArrayOf(0xd0.toByte(), 0xcf.toByte(), 0x11, 0xe0.toByte(), 0xa1.toByte(), 0xb1.toByte(), 0x1a, 0xe1.toByte()))) { "Invalid compound document header." }
    val version = u16(bytes, 26)
    require(u16(bytes, 28) == 0xfffe && ((version == 3 && u16(bytes, 30) == 9) || (version == 4 && u16(bytes, 30) == 12))) { "Unsupported compound document version." }
    require(u16(bytes, 32) == 6 && i32(bytes, 56) == 4096) { "Invalid compound sector configuration." }
    sectorSize = 1 shl u16(bytes, 30)
    val sectorCount = bytes.size / sectorSize - 1
    val fatCount = i32(bytes, 44)
    require(fatCount in 1..sectorCount) { "Invalid FAT size." }
    val fatSectors = mutableListOf<Int>()
    for (i in 0 until 109) { val id = i32(bytes, 76 + i * 4); if (id >= 0) fatSectors.add(id) }
    var difat = i32(bytes, 68)
    val seenDifat = mutableSetOf<Int>()
    val difatCount = i32(bytes, 72)
    require(difatCount in 0..sectorCount)
    repeat(difatCount) {
      require(seenDifat.add(difat)) { "Cyclic DIFAT chain." }
      val data = sector(difat)
      for (i in 0 until sectorSize / 4 - 1) { val id = i32(data, i * 4); if (id >= 0) fatSectors.add(id) }
      difat = i32(data, sectorSize - 4)
    }
    require(fatSectors.size == fatCount && fatSectors.toSet().size == fatCount) { "Invalid FAT directory." }
    fat = fatSectors.flatMap { id -> val data = sector(id); (0 until sectorSize / 4).map { i32(data, it * 4) } }.toIntArray()
    val directory = chain(i32(bytes, 48), fat, sectorSize, null, ::sector)
    require(directory.size / 128 <= 8192) { "Too many directory entries." }
    val entries = (0 until directory.size / 128).map { index ->
      val p = index * 128
      val type = directory[p + 66].toInt() and 255
      val length = u16(directory, p + 64)
      require(type == 0 || (length in 2..64 && length % 2 == 0)) { "Invalid stream name." }
      val size = i32(directory, p + 120)
      require(type == 0 || (size >= 0 && (version == 3 || i32(directory, p + 124) == 0))) { "Stream too large." }
      Entry(if (length >= 2) String(directory, p, length - 2, Charsets.UTF_16LE) else "", type,
        i32(directory, p + 68), i32(directory, p + 72), i32(directory, p + 76), i32(directory, p + 116), size)
    }
    require(entries.isNotEmpty() && entries[0].type == 5) { "Missing compound root." }
    miniStream = chain(entries[0].start, fat, sectorSize, entries[0].size, ::sector)
    val miniCount = i32(bytes, 64)
    require(miniCount in 0..sectorCount)
    val miniBytes = if (miniCount == 0) byteArrayOf() else chain(i32(bytes, 60), fat, sectorSize, miniCount * sectorSize, ::sector)
    miniFat = IntArray(miniBytes.size / 4) { i32(miniBytes, it * 4) }
    val visited = mutableSetOf<Int>()
    fun walk(id: Int, parent: String, depth: Int) {
      if (id == -1) return
      require(depth <= 256 && id in entries.indices && visited.add(id)) { "Invalid compound directory tree." }
      val e = entries[id]
      walk(e.left, parent, depth + 1)
      val name = if (parent.isEmpty()) e.name else "$parent/${e.name}"
      if (e.type == 2) streams[name] = e
      if (e.type == 1) walk(e.child, name, depth + 1)
      walk(e.right, parent, depth + 1)
    }
    walk(entries[0].child, "", 0)
  }

  fun read(name: String): ByteArray {
    val e = streams[name] ?: error("Missing document stream: $name")
    return if (e.size < 4096) chain(e.start, miniFat, 64, e.size) { id ->
      require(id >= 0 && id.toLong() * 64 + 64 <= miniStream.size) { "Invalid mini-sector." }
      miniStream.copyOfRange(id * 64, id * 64 + 64)
    } else chain(e.start, fat, sectorSize, e.size, ::sector)
  }

  private fun sector(id: Int): ByteArray {
    val start = (id.toLong() + 1) * sectorSize
    require(id >= 0 && start + sectorSize <= bytes.size) { "Invalid compound sector." }
    return bytes.copyOfRange(start.toInt(), start.toInt() + sectorSize)
  }
  private fun chain(start: Int, table: IntArray, unit: Int, size: Int?, read: (Int) -> ByteArray): ByteArray {
    require(size == null || size.toLong() <= DocumentIo.MAX_TEXT_BYTES) { "Compound stream exceeds the 8 MiB limit." }
    if (size == 0) return byteArrayOf()
    val out = ByteArrayOutputStream()
    val seen = mutableSetOf<Int>()
    var id = start
    while (id != -2 && (size == null || out.size() < size)) {
      DocumentIo.checkCancelled()
      require(id in table.indices && seen.add(id)) { "Invalid or cyclic compound stream." }
      val data = read(id)
      val count = minOf(unit, (size ?: Int.MAX_VALUE) - out.size())
      require(out.size().toLong() + count <= DocumentIo.MAX_TEXT_BYTES) { "Compound stream exceeds the 8 MiB limit." }
      out.write(data, 0, count)
      id = table[id]
    }
    require(size == null || out.size() == size) { "Truncated compound stream." }
    return out.toByteArray()
  }
  companion object {
    fun u16(b: ByteArray, p: Int): Int { require(p >= 0 && p + 2 <= b.size); return (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8) }
    fun i32(b: ByteArray, p: Int): Int { require(p >= 0 && p + 4 <= b.size); return u16(b, p) or (u16(b, p + 2) shl 16) }
  }
}

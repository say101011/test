package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.FormatCapability
import com.example.model.FormatSupportMatrix
import com.example.model.SupportLevel

@Composable
fun SupportMatrixDialog(
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(R.string.support_matrix_title),
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
      )
    },
    text = {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 480.dp)
          .testTag("support_matrix_list")
      ) {
        items(FormatSupportMatrix.items) { cap ->
          FormatCapabilityCard(cap = cap)
          Spacer(modifier = Modifier.height(10.dp))
        }
      }
    },
    confirmButton = {
      Button(onClick = onDismiss, modifier = Modifier.testTag("support_matrix_close_button")) {
        Text(stringResource(R.string.close))
      }
    }
  )
}

@Composable
private fun FormatCapabilityCard(cap: FormatCapability) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ),
    shape = RoundedCornerShape(8.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = cap.formatName,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = cap.extensions,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.weight(1f))
        SupportLevelBadge(level = cap.supportLevel)
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "• Capabilities:",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
      )
      cap.capabilities.forEach { c ->
        Text(
          text = "  - $c",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      if (cap.limitations.isNotEmpty()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "• Limitations / Privacy Scope:",
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.error
        )
        cap.limitations.forEach { lim ->
          Text(
            text = "  - $lim",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Engine: ${cap.licenseOrEngine}",
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
      )
    }
  }
}

@Composable
private fun SupportLevelBadge(level: SupportLevel) {
  val (bgColor, textColor, text) = when (level) {
    SupportLevel.FULL -> Triple(Color(0xFFDCFCE7), Color(0xFF166534), "Full Support")
    SupportLevel.STRUCTURED -> Triple(Color(0xFFDBEAFE), Color(0xFF1E40AF), "Structured")
    SupportLevel.SIMPLIFIED -> Triple(Color(0xFFFEF3C7), Color(0xFF92400E), "Simplified")
    SupportLevel.UNSUPPORTED -> Triple(Color(0xFFFEE2E2), Color(0xFF991B1B), "Unsupported")
  }

  Box(
    modifier = Modifier
      .background(bgColor, RoundedCornerShape(4.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

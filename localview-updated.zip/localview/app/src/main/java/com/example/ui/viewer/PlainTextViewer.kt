package com.example.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentTab
import com.example.model.PlainTextDocumentContent

@Composable
fun PlainTextViewer(
  tab: DocumentTab,
  content: PlainTextDocumentContent
) {
  val horizontalScroll = rememberScrollState()

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("plain_text_viewer")
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .then(if (!tab.isWordWrap) Modifier.horizontalScroll(horizontalScroll) else Modifier)
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      itemsIndexed(content.lines) { index, line ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.Top
        ) {
          // Line numbers
          Text(
            text = "${index + 1}",
            fontFamily = FontFamily.Monospace,
            fontSize = (tab.fontSizeSp - 3).coerceAtLeast(10f).sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.width(42.dp)
          )

          // Line Content
          Text(
            text = highlightSearch(line, tab.searchQuery),
            fontFamily = FontFamily.Monospace,
            fontSize = tab.fontSizeSp.sp,
            color = MaterialTheme.colorScheme.onSurface,
            softWrap = tab.isWordWrap,
            lineHeight = (tab.fontSizeSp * 1.4f).sp,
            modifier = Modifier.weight(1f, fill = false)
          )
        }
      }
    }
  }
}

package com.example.parser

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

object SpreadsheetValues {
  fun column(index: Int): String { var n = index + 1; var s = ""; while (n > 0) { n--; s = ('A'.code + n % 26).toChar() + s; n /= 26 }; return s }
  fun format(raw: String, formatId: Int, date1904: Boolean = false, custom: String? = null): String {
    val value = raw.toDoubleOrNull() ?: return raw
    if (!value.isFinite()) return raw
    val code = custom?.lowercase(Locale.ROOT)?.replace(Regex("\"[^\"]*\"|\\\\.|\\[(?![hms]\\])[^\\]]*\\]"), "") ?: ""
    if(custom != null && code.contains("[h]")) {
      val seconds = kotlin.math.round(kotlin.math.abs(value) * 86400).toLong()
      return (if(value < 0) "-" else "") + (seconds / 3600).toString() + ":" + ((seconds / 60) % 60).toString().padStart(2,'0') + if(code.contains("ss")) ":"+(seconds%60).toString().padStart(2,'0') else ""
    }
    val date = formatId in 14..22 || formatId in 45..47 || code.contains('y') || code.contains('d') || code.contains("h:")
    if (date && value >= 0 && value < 2_000_000) {
      val dateFormat = when {
        formatId in 18..21 || formatId in 45..47 -> "HH:mm:ss"
        formatId == 22 || code.contains('h') -> "yyyy-MM-dd HH:mm:ss"
        else -> "yyyy-MM-dd"
      }
      if (!date1904 && value.toInt() == 60 && dateFormat.startsWith("yyyy")) return "1900-02-29 (Excel leap-day convention)"
      val calendar = GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.US).apply {
        clear(); set(if (date1904) 1904 else 1899, if (date1904) 0 else 11, if (date1904) 1 else 31)
      }
      val days = if (!date1904 && value >= 60) value - 1 else value
      val formatter = SimpleDateFormat(dateFormat, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
      return formatter.format(Date(calendar.timeInMillis + (days * 86400000).toLong()))
    }
    if(custom != null && custom.length <= 256) customNumber(value,custom)?.let { return it }
    val pattern = when (formatId) { 1 -> "0"; 2 -> "0.00"; 3 -> "#,##0"; 4 -> "#,##0.00"; 9 -> "0%"; 10 -> "0.00%"; 11 -> "0.00E0"; else -> null }
      ?: if (code.contains('%')) "0.00%" else null
    return if (pattern != null) DecimalFormat(pattern, DecimalFormatSymbols(Locale.US)).format(value) else raw
  }
  private fun customNumber(value:Double,format:String):String? {
    val sections=mutableListOf<String>();val current=StringBuilder();var quoted=false;var escape=false
    for(ch in format) {
      if(ch==';' && !quoted && !escape) { sections.add(current.toString());current.clear() }
      else current.append(ch)
      if(ch=='"' && !escape) quoted=!quoted
      escape=ch=='\\' && !escape
    }
    sections.add(current.toString())
    if(sections.any { it.contains(Regex("\\[[<>=]")) }) return null
    val selected=when { value<0 && sections.size>1 -> sections[1]; value==0.0 && sections.size>2 -> sections[2];else -> sections[0] }
    if(selected.isEmpty()) return ""
    var pattern=selected.replace(Regex("\\[(?:Black|Blue|Cyan|Green|Magenta|Red|White|Yellow|Color[0-9]+)\\]",RegexOption.IGNORE_CASE),"")
    pattern=pattern.replace(Regex("\\[\\$(.*?)(?:-[0-9A-Fa-f]+)?\\]")) { "'"+it.groupValues[1].replace("'","''")+"'" }
    if(pattern.contains('[') || pattern.contains('?') || pattern.contains('@') || pattern.contains('/'))return null
    pattern=pattern.replace(Regex("_.|\\*."),"")
    val out=StringBuilder();var i=0
    while(i<pattern.length) {
      val c=pattern[i]
      when(c) {
        '"' -> { val end=pattern.indexOf('"',i+1);if(end<0)return null;out.append("'").append(pattern.substring(i+1,end).replace("'","''")).append("'");i=end }
        '\\' -> { if(i+1>=pattern.length)return null;out.append("'").append(pattern[++i].toString().replace("'","''")).append("'") }
        else -> out.append(c)
      };i++
    }
    if(!out.contains('0') && !out.contains('#'))return null
    if(out.contains(Regex("[0#],+(?:[^0#]|$)")))return null // scaling commas require Excel-specific semantics
    return try { DecimalFormat(out.toString().replace("E+","E"),DecimalFormatSymbols(Locale.US)).format(if(value<0 && sections.size>1) -value else value) } catch(_:IllegalArgumentException) { null }
  }
}

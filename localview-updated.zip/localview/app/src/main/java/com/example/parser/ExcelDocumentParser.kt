package com.example.parser
import android.content.Context
import android.net.Uri
import com.example.model.DocumentContent
object ExcelDocumentParser {
  fun parse(context: Context, uri: Uri, isLegacyXls: Boolean): DocumentContent =
    if (isLegacyXls) LegacyXls.parse(context, uri) else XlsxParser.parse(context, uri)
}

package com.example.data

import java.io.File

object DocumentCache {
  /** Only app-owned document directories; never follows a link outside the cache. */
  fun clear(cacheDir: File): Int {
    val root = cacheDir.canonicalFile
    var deleted = 0
    fun remove(file: File) {
      val canonical = file.canonicalFile
      require(canonical.path.startsWith(root.path + File.separator)) { "Invalid cache path." }
      if (file.isDirectory) {
        val children = file.listFiles() ?: error("Unable to read cached files.")
        children.forEach(::remove)
      }
      if (file.isFile) deleted++
      check(file.delete()) { "Some cached files could not be deleted. Please try again." }
    }
    for (name in listOf("pdf_cache", "sample_docs", "document_imports")) {
      val directory = File(root, name)
      if (directory.exists()) remove(directory)
    }
    return deleted
  }
}

package com.example.parser

import com.example.model.MergedRegion

object SpreadsheetLayout {
  /** Only the bounded preview is allocated. Overlapping merged cells are invalid. */
  fun coveredCells(regions: List<MergedRegion>, rows: Int, cols: Int): Set<Int> {
    val covered=HashSet<Int>()
    for(region in regions) {
      require(region.firstRow>=0 && region.firstCol>=0 && region.lastRow>=region.firstRow && region.lastCol>=region.firstCol)
      for(row in region.firstRow until minOf(rows,region.lastRow+1)) for(col in region.firstCol until minOf(cols,region.lastCol+1)) {
        require(covered.add(row*cols+col)) { "Overlapping merged ranges are not supported." }
      }
    }
    return covered
  }
}

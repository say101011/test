package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

/**
 * Dedicated Google AdMob Banner Container.
 * Completely isolated from document contents and file metadata.
 * Uses official Google AdMob test banner ad unit ID.
 */
object AdMobConfig {
  // Official Google AdMob sample banner ad unit ID
  const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
}

@Composable
fun AdMobBanner(
  modifier: Modifier = Modifier,
  adUnitId: String = AdMobConfig.TEST_BANNER_AD_UNIT_ID
) {
  val context = LocalContext.current
  var isAdLoaded by remember { mutableStateOf(false) }
  var adFailedError by remember { mutableStateOf<String?>(null) }

  // Initialize MobileAds once safely
  remember {
    try {
      MobileAds.initialize(context.applicationContext) {}
    } catch (_: Exception) {}
    true
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
      .navigationBarsPadding()
      .testTag("admob_banner_container"),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Privacy and data isolation notice
    Text(
      text = stringResource(R.string.privacy_banner_notice),
      fontSize = 10.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
      textAlign = TextAlign.Center,
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 2.dp)
    )

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp),
      contentAlignment = Alignment.Center
    ) {
      if (adFailedError != null || !isAdLoaded) {
        // Polite placeholder showing dedicated AdMob test area
        Text(
          text = stringResource(R.string.test_ad_banner),
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Safe AndroidView embedding AdView
      AndroidView(
        modifier = Modifier.fillMaxWidth(),
        onRelease = { view -> (view as? AdView)?.destroy() },
        factory = { ctx ->
          try {
            AdView(ctx).apply {
              setAdSize(AdSize.BANNER)
              this.adUnitId = adUnitId
              adListener = object : AdListener() {
                override fun onAdLoaded() {
                  isAdLoaded = true
                  adFailedError = null
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                  isAdLoaded = false
                  adFailedError = error.message
                }
              }
              val adRequest = AdRequest.Builder().build()
              loadAd(adRequest)
            }
          } catch (e: Exception) {
            adFailedError = e.localizedMessage
            android.view.View(ctx)
          }
        }
      )
    }
    Spacer(modifier = Modifier.height(2.dp))
  }
}

package com.example.parser

import android.content.Context
import androidx.core.graphics.createBitmap
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.model.CorruptedDocumentContent
import com.example.model.DocumentContent
import com.example.model.EncryptedDocumentContent
import com.example.model.PdfDocumentContent
import java.io.File
import java.io.FileOutputStream
import java.util.regex.Pattern

object PdfDocumentParser {

  fun parse(context: Context, uri: Uri, fileName: String): DocumentContent {
    val tempFile = createLocalTempPdf(context, uri) ?: return CorruptedDocumentContent("Unable to read PDF file data")

    var keepFile = false
    return try {
      val dimensions = mutableListOf<Pair<Int, Int>>()
      val pageCount = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
          require(renderer.pageCount <= 2000) { "PDF exceeds the 2,000-page limit." }
          for (i in 0 until renderer.pageCount) {
            DocumentIo.checkCancelled()
            renderer.openPage(i).use { page -> dimensions.add(page.width to page.height) }
          }
          renderer.pageCount
        }
      }
      val extractedText = PdfTextIndex.read(context, tempFile, pageCount)
      DocumentIo.checkCancelled()
      val content = PdfDocumentContent(Uri.fromFile(tempFile), pageCount, dimensions, fileName, extractedText.pages, extractedText.notice, extractedText.geometry)
      keepFile = true
      content
    } catch (e: java.util.concurrent.CancellationException) {
      throw e
    } catch (e: SecurityException) {
      EncryptedDocumentContent("Password required to view this PDF.")
    } catch (e: Exception) {
      CorruptedDocumentContent(e.message ?: "Error opening PDF.")
    } finally {
      if (!keepFile) tempFile.delete()
    }
  }

  fun renderPage(file: File, pageIndex: Int, targetWidth: Int, targetHeight: Int): Bitmap? {
    var pfd: ParcelFileDescriptor? = null
    var renderer: PdfRenderer? = null
    var page: PdfRenderer.Page? = null
    return try {
      pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
      renderer = PdfRenderer(pfd)
      if (pageIndex in 0 until renderer.pageCount) {
        page = renderer.openPage(pageIndex)
        val scale = minOf(1.0, 1600.0 / maxOf(targetWidth, targetHeight).coerceAtLeast(1))
        val w = (targetWidth * scale).toInt().coerceIn(1, 1600)
        val h = (targetHeight * scale).toInt().coerceIn(1, 1600)
        val bitmap = createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(android.graphics.Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        bitmap
      } else null
    } catch (_: Exception) {
      null
    } finally {
      page?.close()
      renderer?.close()
      pfd?.close()
    }
  }

  private fun createLocalTempPdf(context: Context, uri: Uri): File? {
    val cacheDir = File(context.cacheDir, "pdf_cache").apply { mkdirs() }
    val tempFile = File.createTempFile("doc_", ".pdf", cacheDir)
    return try {
      context.contentResolver.openInputStream(uri)?.use { input ->
        tempFile.outputStream().use { output -> DocumentIo.copyLimited(input, output) }
      } ?: error("Unable to read PDF data.")
      tempFile
    } catch (e: Exception) {
      tempFile.delete()
      if (e is java.util.concurrent.CancellationException) throw e
      null
    }
  }

}

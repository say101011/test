package com.example.parser
import android.content.Context
import android.net.Uri
object HwpDocumentParser { fun parse(context: Context, uri: Uri) = LegacyDocuments.hwp(context, uri) }

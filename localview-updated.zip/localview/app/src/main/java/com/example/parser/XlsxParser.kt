package com.example.parser

import android.content.Context
import android.net.Uri
import android.util.Xml
import com.example.model.*
import org.xmlpull.v1.XmlPullParser
import java.net.URI

object XlsxParser {
  private fun xml(bytes: ByteArray, visit: (XmlPullParser) -> Unit) {
    val p = Xml.newPullParser()
    p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
    p.setInput(bytes.inputStream(), null)
    while (p.eventType != XmlPullParser.END_DOCUMENT) { DocumentIo.checkCancelled(); visit(p); p.next() }
  }
  private fun XmlPullParser.attr(name: String) = (0 until attributeCount).firstOrNull { getAttributeName(it) == name }?.let { getAttributeValue(it) }
  fun parse(context: Context, uri: Uri): DocumentContent = try {
    val parts = mutableMapOf<String, ByteArray>()
    context.contentResolver.openInputStream(uri)!!.use { input -> BoundedZipInputStream(input).use { zip ->
      var entry = zip.nextEntry
      while (entry != null) {
        if (entry.name.startsWith("xl/") && (entry.name.endsWith(".xml") || entry.name.endsWith(".rels"))) parts[entry.name] = DocumentIo.readLimited(zip)
        entry = zip.nextEntry
      }
    } }
    val shared = mutableListOf<String>()
    var string = StringBuilder(); var inText = false
    parts["xl/sharedStrings.xml"]?.let { bytes -> xml(bytes) { p -> when (p.eventType) {
      XmlPullParser.START_TAG -> when(p.name) { "si" -> string = StringBuilder(); "t" -> inText = true }
      XmlPullParser.TEXT -> if (inText) string.append(p.text)
      XmlPullParser.END_TAG -> when(p.name) { "t" -> inText = false; "si" -> { require(shared.size < 100_000); shared.add(string.toString()) } }
    } } }
    val relationships = mutableMapOf<String, String>()
    parts["xl/_rels/workbook.xml.rels"]?.let { bytes -> xml(bytes) { p ->
      if (p.eventType == XmlPullParser.START_TAG && p.name == "Relationship" && p.attr("TargetMode") != "External" && p.attr("Type")?.endsWith("/worksheet") == true) {
        val target = URI("xl/workbook.xml").resolve(p.attr("Target") ?: "").normalize()
        val part = target.path?.removePrefix("/") ?: ""
        require(!target.isAbsolute && part.startsWith("xl/") && !part.contains("../")) { "Invalid worksheet relationship." }
        relationships[p.attr("Id") ?: error("Missing relationship ID")] = part
      }
    } }
    val formats = mutableListOf<Int>(); val customFormats = mutableMapOf<Int, String>()
    var inCellFormats = false
    parts["xl/styles.xml"]?.let { bytes -> xml(bytes) { p ->
      if (p.eventType == XmlPullParser.START_TAG) when(p.name) {
        "cellXfs" -> inCellFormats = true
        "xf" -> if(inCellFormats) formats.add(p.attr("numFmtId")?.toIntOrNull() ?: 0)
        "numFmt" -> p.attr("numFmtId")?.toIntOrNull()?.let { customFormats[it] = p.attr("formatCode") ?: "" }
      }
      if(p.eventType == XmlPullParser.END_TAG && p.name == "cellXfs") inCellFormats = false
    } }
    data class Ref(val name: String, val id: String, val hidden: Boolean)
    val references = mutableListOf<Ref>()
    var date1904 = false
    xml(parts["xl/workbook.xml"] ?: error("Missing workbook.xml")) { p ->
      if (p.eventType == XmlPullParser.START_TAG) when(p.name) {
        "workbookPr" -> date1904 = p.attr("date1904") in listOf("1", "true")
        "sheet" -> references.add(Ref(p.attr("name") ?: "Sheet", p.attr("id") ?: error("Missing worksheet relationship ID"), p.attr("state") in listOf("hidden", "veryHidden")))
      }
    }
    require(references.isNotEmpty()) { "Workbook contains no sheets." }
    require(references.size <= 64) { "Workbook exceeds the 64-sheet preview limit." }
    var remaining = 100_000
    val sheets = references.map { ref ->
      val target = relationships[ref.id] ?: error("Missing worksheet relationship for ${ref.name}. No substitute sheet was displayed.")
      val bytes = parts[target] ?: error("Missing worksheet data for ${ref.name}.")
      if (remaining <= 0) SheetData(ref.name, 0, 0, emptyList(), emptyList(), "Not displayed: the workbook reached its 100,000-cell preview limit.")
      else parseSheet(bytes, ref.name, shared, formats, customFormats, date1904, remaining, ref.hidden).copy(charts = XlsxCharts.read(parts,target)).also { remaining -= it.maxRows * it.maxCols }
    }
    SpreadsheetDocumentContent(sheets, isSimplified = true,
      noticeMessage = "Values preview. Formulas use saved results and are not recalculated. Dates and common number formats are normalized; custom formatting may differ. Shapes and advanced chart styling are not reproduced. Tap a cell to read its full value.")
  } catch (e: java.util.concurrent.CancellationException) { throw e }
  catch (e: Exception) { CorruptedDocumentContent("Unable to read XLSX: ${e.message}") }

  private fun parseSheet(bytes: ByteArray, name: String, shared: List<String>, formats: List<Int>, custom: Map<Int, String>, date1904: Boolean, budget: Int, hidden: Boolean): SheetData {
    val cells = mutableMapOf<Pair<Int, Int>, CellData>()
    var nextRow = 0; var row = 0; var col = 0; var nextCol = 0; var type = ""; var style = 0
    var maxRow = 0; var maxCol = 0; var inCell = false; var valueTag = false; var formulaTag = false
    var raw = StringBuilder(); var formula = StringBuilder(); var hasFormula = false
    val merges = mutableListOf<MergedRegion>(); var missingFormula = false
    xml(bytes) { p -> when(p.eventType) {
      XmlPullParser.START_TAG -> when(p.name) {
        "row" -> { row = (p.attr("r")?.toIntOrNull()?.minus(1)) ?: nextRow; nextRow = row + 1; nextCol = 0 }
        "mergeCell" -> {
          val refs=p.attr("ref")?.split(':').orEmpty()
          if(refs.size==2) {
            fun point(value:String):Pair<Int,Int> { val m=Regex("([A-Za-z]{1,3})([0-9]{1,7})").matchEntire(value) ?: error("Invalid merged cell range")
              return m.groupValues[2].toInt()-1 to m.groupValues[1].uppercase(java.util.Locale.ROOT).fold(0) { a,c -> a*26+c.code-'A'.code+1 }-1 }
            val (r1,c1)=point(refs[0]);val (r2,c2)=point(refs[1])
            require(r1>=0 && c1>=0 && r2>=r1 && c2>=c1 && r2<1_048_576 && c2<16384)
            require(merges.size<10_000)
            merges.add(MergedRegion(r1,c1,r2,c2)); maxRow=maxOf(maxRow,r2);maxCol=maxOf(maxCol,c2)
          }
        }
        "c" -> {
          val reference = p.attr("r")
          if (reference != null) {
            val match = Regex("([A-Za-z]{1,3})([0-9]{1,7})").matchEntire(reference) ?: error("Invalid cell reference.")
            col = match.groupValues[1].uppercase().fold(0) { a, c -> a * 26 + c.code - 'A'.code + 1 } - 1
            row = match.groupValues[2].toInt() - 1
          } else col = nextCol
          require(row in 0..1_048_575 && col in 0..16383) { "Cell is outside worksheet bounds." }
          nextCol = col + 1; maxRow = maxOf(maxRow, row); maxCol = maxOf(maxCol, col)
          type = p.attr("t") ?: ""; style = p.attr("s")?.toIntOrNull() ?: 0
          raw = StringBuilder(); formula = StringBuilder(); hasFormula = false; inCell = true
        }
        "v", "t" -> if(inCell) valueTag = true
        "f" -> if(inCell) { formulaTag = true; hasFormula = true }
      }
      XmlPullParser.TEXT -> { if(valueTag) raw.append(p.text); if(formulaTag) formula.append(p.text) }
      XmlPullParser.END_TAG -> when(p.name) {
        "v", "t" -> valueTag = false
        "f" -> formulaTag = false
        "c" -> {
          inCell = false
          var value = raw.toString()
          if(type == "s") value = shared.getOrNull(value.trim().toIntOrNull() ?: -1) ?: error("Invalid shared-string reference.")
          if(type == "b") value = if(value == "1") "TRUE" else "FALSE"
          if(hasFormula && raw.isEmpty()) { missingFormula = true; value = "[No saved result]" + if(formula.isNotEmpty()) " =${formula}" else "" }
          val numberFormat = formats.getOrNull(style) ?: 0
          val display = if(type in listOf("", "n") && !(hasFormula && raw.isEmpty())) SpreadsheetValues.format(value, numberFormat, date1904, custom[numberFormat]) else value
          if(row < 1000 && col < 100) cells[row to col] = CellData(row, col, value, display)
        }
      }
    } }
    val cols = minOf(maxCol + 1, 100, budget)
    val rows = minOf(maxRow + 1, 1000, budget / cols)
    SpreadsheetLayout.coveredCells(merges,rows,cols)
    val notices = mutableListOf<String>()
    if(hidden) notices.add("This worksheet is hidden in the original workbook.")
    if(rows < maxRow + 1 || cols < maxCol + 1) notices.add("Partial preview: showing rows 1–$rows and columns A–${SpreadsheetValues.column(cols - 1)}; populated cells extend to row ${maxRow + 1}, column ${SpreadsheetValues.column(maxCol)}.")
    if(merges.any { it.lastRow >= rows || it.lastCol >= cols }) notices.add("Some merged ranges extend beyond the displayed preview.")
    if(missingFormula) notices.add("Some formulas have no saved result; they are marked instead of shown as blank.")
    return SheetData(name, rows, cols, (0 until cols).map(SpreadsheetValues::column),
      (0 until rows).map { r -> (0 until cols).map { c -> cells[r to c] ?: CellData(r, c, "") } }, notices.joinToString(" ").ifEmpty { null }, merges.filter { it.firstRow < rows && it.firstCol < cols })
  }
}

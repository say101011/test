package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [RecentDocumentEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
  abstract fun recentDocumentDao(): RecentDocumentDao

  companion object {
    val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
      override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("DELETE FROM recent_documents WHERE id NOT IN (SELECT r.id FROM recent_documents r WHERE r.id = (SELECT r2.id FROM recent_documents r2 WHERE r2.uriString = r.uriString ORDER BY r2.lastOpenedTimestamp DESC, r2.id DESC LIMIT 1))")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_recent_documents_uriString ON recent_documents(uriString)")
      }
    }

    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "local_view_db"
        )
        .addMigrations(MIGRATION_1_2)
        .build()
        INSTANCE = instance
        instance
      }
    }
  }
}

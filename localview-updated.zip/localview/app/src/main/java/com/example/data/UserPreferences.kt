package com.example.data

import androidx.core.content.edit
import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("local_view_prefs", Context.MODE_PRIVATE)

  private val _isRecentHistoryEnabled = MutableStateFlow(
    prefs.getBoolean(KEY_RECENT_HISTORY, true)
  )
  val isRecentHistoryEnabled: StateFlow<Boolean> = _isRecentHistoryEnabled.asStateFlow()

  private val _selectedTheme = MutableStateFlow(
    prefs.getString(KEY_THEME, "system") ?: "system"
  )
  val selectedTheme: StateFlow<String> = _selectedTheme.asStateFlow()

  fun setRecentHistoryEnabled(enabled: Boolean) {
    prefs.edit { putBoolean(KEY_RECENT_HISTORY, enabled) }
    _isRecentHistoryEnabled.value = enabled
  }

  fun setSelectedTheme(theme: String) {
    prefs.edit { putString(KEY_THEME, theme) }
    _selectedTheme.value = theme
  }

  companion object {
    private const val KEY_RECENT_HISTORY = "pref_recent_history_enabled"
    private const val KEY_THEME = "pref_selected_theme"
  }
}

package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RecentDocumentDao {
  @Query("SELECT * FROM recent_documents ORDER BY lastOpenedTimestamp DESC LIMIT 30")
  fun getAllRecentDocuments(): Flow<List<RecentDocumentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(doc: RecentDocumentEntity): Long

  @androidx.room.Transaction
  suspend fun saveVisit(doc: RecentDocumentEntity) {
    val old = findByUri(doc.uriString)
    insertOrUpdate(doc.copy(id = old?.id ?: 0, lastPage = old?.lastPage ?: doc.lastPage, lastZoom = old?.lastZoom ?: doc.lastZoom))
  }

  @Query("DELETE FROM recent_documents WHERE uriString = :uriString")
  suspend fun deleteByUri(uriString: String)

  @Query("DELETE FROM recent_documents")
  suspend fun clearAll()

  @Query("SELECT * FROM recent_documents WHERE uriString = :uriString LIMIT 1")
  suspend fun findByUri(uriString: String): RecentDocumentEntity?

  @Query("UPDATE recent_documents SET lastPage = :page, lastZoom = :zoom WHERE uriString = :uriString")
  suspend fun updatePosition(uriString: String, page: Int, zoom: Float)
}

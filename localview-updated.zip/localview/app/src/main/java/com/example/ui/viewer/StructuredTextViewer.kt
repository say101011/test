package com.example.ui.viewer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocBlock
import com.example.model.DocumentTab
import com.example.model.StructuredTextDocumentContent

@Composable
fun StructuredTextViewer(
  tab: DocumentTab,
  content: StructuredTextDocumentContent,
  onZoomChange: (Float) -> Unit
) {
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("structured_text_viewer")
  ) {
    // Notice banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
        .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
      Text(
        text = content.noticeMessage,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onPrimaryContainer
      )
    }

    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .pointerInput(Unit) {
          detectTransformGestures { _, pan, zoom, _ ->
            val newZoom = (tab.zoomLevel * zoom).coerceIn(0.5f, 3.0f)
            onZoomChange(newZoom)
            if (newZoom > 1.0f) {
              offsetX += pan.x
              offsetY += pan.y
            } else {
              offsetX = 0f
              offsetY = 0f
            }
          }
        }
    ) {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .graphicsLayer {
            scaleX = tab.zoomLevel
            scaleY = tab.zoomLevel
            translationX = offsetX
            translationY = offsetY
          }
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        items(content.blocks) { block ->
          RenderDocBlock(block = block, searchQuery = tab.searchQuery)
          Spacer(modifier = Modifier.height(10.dp))
        }
      }
    }
  }
}

@Composable
private fun RenderDocBlock(block: DocBlock, searchQuery: String) {
  when (block) {
    is DocBlock.Heading -> {
      val (fontSize, weight) = when (block.level) {
        1 -> Pair(22.sp, FontWeight.Bold)
        2 -> Pair(18.sp, FontWeight.Bold)
        3 -> Pair(16.sp, FontWeight.SemiBold)
        else -> Pair(14.sp, FontWeight.SemiBold)
      }
      Text(
        text = highlightSearch(block.text, searchQuery),
        fontSize = fontSize,
        fontWeight = weight,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
      )
    }
    is DocBlock.Paragraph -> {
      val highlighted = highlightSearch(block.text, searchQuery)
      val styled = buildAnnotatedString {
        append(highlighted)
        block.styles.forEach { range -> if(range.start >= 0 && range.end <= length && range.end > range.start) addStyle(SpanStyle(fontWeight = if(range.bold) FontWeight.Bold else null, fontStyle = if(range.italic) FontStyle.Italic else null),range.start,range.end) }
      }
      Text(
        text = styled,
        fontSize = 14.sp,
        fontStyle = if (block.isItalic) FontStyle.Italic else FontStyle.Normal,
        fontWeight = if (block.isBold) FontWeight.SemiBold else FontWeight.Normal,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 22.sp
      )
    }
    is DocBlock.Table -> {
      Surface(
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          if (block.headers.isNotEmpty()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(vertical = 6.dp)
            ) {
              block.headers.forEach { header ->
                Text(
                  text = highlightSearch(header, searchQuery),
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
                )
              }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
          }

          block.rows.forEachIndexed { rIdx, row ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(if (rIdx % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                .padding(vertical = 6.dp)
            ) {
              row.forEach { cell ->
                Text(
                  text = highlightSearch(cell, searchQuery),
                  fontSize = 11.sp,
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
                )
              }
            }
            if (rIdx < block.rows.size - 1) {
              HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            }
          }
        }
      }
    }
    is DocBlock.EmbeddedImage -> {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Image(
          bitmap = block.bitmap.asImageBitmap(),
          contentDescription = block.altText,
          modifier = Modifier.fillMaxWidth(0.85f)
        )
      }
    }
    DocBlock.Divider -> {
      HorizontalDivider(
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
        modifier = Modifier.padding(vertical = 8.dp)
      )
    }
  }
}

@Composable
fun highlightSearch(text: String, query: String) = buildAnnotatedString {
  if (query.isBlank() || !text.contains(query, ignoreCase = true)) {
    append(text)
    return@buildAnnotatedString
  }

  var currentIndex = 0
  

  while (currentIndex < text.length) {
    val foundIndex = text.indexOf(query, currentIndex, ignoreCase = true)
    if (foundIndex == -1) {
      append(text.substring(currentIndex))
      break
    } else {
      if (foundIndex > currentIndex) {
        append(text.substring(currentIndex, foundIndex))
      }
      withStyle(SpanStyle(background = Color(0xFFFEF08A), color = Color.Black, fontWeight = FontWeight.Bold)) {
        append(text.substring(foundIndex, foundIndex + query.length))
      }
      currentIndex = foundIndex + query.length
    }
  }
}

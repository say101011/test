package com.example.parser

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object DocumentIo {
  const val MAX_FILE_BYTES = 64L * 1024 * 1024
  const val MAX_TEXT_BYTES = 8L * 1024 * 1024
  fun checkCancelled() {
    if (Thread.currentThread().isInterrupted) throw CancellationException("Document loading cancelled")
  }
  fun copyLimited(input: InputStream, output: OutputStream, limit: Long = MAX_FILE_BYTES): Long {
    val buffer = ByteArray(8192)
    var total = 0L
    while (true) {
      checkCancelled()
      val count = input.read(buffer)
      if (count < 0) return total
      total += count
      require(total <= limit) { "Document exceeds the ${limit / 1024 / 1024} MB processing limit." }
      output.write(buffer, 0, count)
    }
  }
  fun readLimited(input: InputStream, limit: Long = MAX_TEXT_BYTES): ByteArray =
    ByteArrayOutputStream().use { output -> copyLimited(input, output, limit); output.toByteArray() }
}

/** Counts expanded bytes, including entries skipped by nextEntry. */
class BoundedZipInputStream(input: InputStream) : ZipInputStream(input) {
  private var expanded = 0L
  private var entries = 0
  override fun read(bytes: ByteArray, offset: Int, length: Int): Int {
    DocumentIo.checkCancelled()
    val count = super.read(bytes, offset, length)
    if (count > 0) expanded += count
    require(expanded <= 24L * 1024 * 1024) { "Archive exceeds the 24 MB expanded-data limit." }
    return count
  }
  override fun getNextEntry(): ZipEntry? {
    DocumentIo.checkCancelled()
    val entry = super.getNextEntry()
    if (entry != null) require(++entries <= 2048) { "Archive contains too many entries." }
    return entry
  }
}

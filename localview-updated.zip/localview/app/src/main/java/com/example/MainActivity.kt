package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Parcelable
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.os.LocaleListCompat
import com.example.ui.components.AdMobBanner
import com.example.ui.components.DocumentTabs
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SettingsDialog
import com.example.ui.components.SupportMatrixDialog
import com.example.ui.components.TopBar
import com.example.ui.theme.LocalViewTheme
import com.example.ui.viewmodel.LocalViewerViewModel
import com.example.ui.viewer.DocumentViewerContainer
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

class MainActivity : AppCompatActivity() {

  private var canRequestAds by mutableStateOf(false)
  private var privacyOptionsRequired by mutableStateOf(false)

  private fun refreshConsentState() {
    val info = UserMessagingPlatform.getConsentInformation(this)
    canRequestAds = info.canRequestAds()
    privacyOptionsRequired = info.privacyOptionsRequirementStatus ==
      ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
  }

  private val viewModel: LocalViewerViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
    enableEdgeToEdge()

    // Request AdMob UMP (User Messaging Platform) consent asynchronously
    initUmpConsent()

    // Handle initial intent if file opened with this app
    if (savedInstanceState == null) handleIntent(intent)

    setContent {
      val userPrefs = viewModel.userPrefs
      val selectedTheme by userPrefs.selectedTheme.collectAsState()
      val isDark = when (selectedTheme) {
        "light" -> false
        "dark" -> true
        else -> isSystemInDarkTheme()
      }

      LocalViewTheme(darkTheme = isDark) {
        MainScreen(
          viewModel = viewModel,
          canRequestAds = canRequestAds,
          privacyOptionsRequired = privacyOptionsRequired,
          onPrivacyOptions = {
            canRequestAds = false
            UserMessagingPlatform.showPrivacyOptionsForm(this) { error ->
              refreshConsentState()
              if (error != null) android.widget.Toast.makeText(this, error.message, android.widget.Toast.LENGTH_LONG).show()
            }
          }
        )
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleIntent(intent)
  }

  private fun handleIntent(intent: Intent?) {
    if (intent == null) return
    when (intent.action) {
      Intent.ACTION_VIEW -> {
        intent.data?.let { uri ->
          viewModel.openDocument(uri)
        }
      }
      Intent.ACTION_SEND -> {
        @Suppress("DEPRECATION")
        val uri = intent.getParcelableExtra<Parcelable>(Intent.EXTRA_STREAM) as? Uri
        uri?.let {
          viewModel.openDocument(it)
        }
      }
    }
  }

  private fun initUmpConsent() {
    try {
      val params = ConsentRequestParameters.Builder()
        .setTagForUnderAgeOfConsent(false)
        .build()

      val consentInformation = UserMessagingPlatform.getConsentInformation(this)
      consentInformation.requestConsentInfoUpdate(
        this,
        params,
        {
          UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { _ ->
            refreshConsentState()
          }
        },
        { _ ->
          refreshConsentState()
        }
      )
      refreshConsentState()
    } catch (_: Exception) {}
  }
}

@Composable
fun MainScreen(
  viewModel: LocalViewerViewModel,
  canRequestAds: Boolean = false,
  privacyOptionsRequired: Boolean = false,
  onPrivacyOptions: () -> Unit = {}
) {
  val openTabs by viewModel.openTabs.collectAsState()
  val activeTabIndex by viewModel.activeTabIndex.collectAsState()
  val splitTabIndex by viewModel.splitTabIndex.collectAsState()
  val isSplitView by viewModel.isSplitView.collectAsState()
  val recentDocuments by viewModel.recentDocuments.collectAsState()
  val isRecentHistoryEnabled by viewModel.userPrefs.isRecentHistoryEnabled.collectAsState()
  val selectedTheme by viewModel.userPrefs.selectedTheme.collectAsState()

  val isClearingCache by viewModel.isClearingCache.collectAsState()
  val cacheMessage by viewModel.cacheMessage.collectAsState()

  var showSupportMatrix by remember { mutableStateOf(false) }
  var showSettings by remember { mutableStateOf(false) }

  var replacementUri by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }

  // SAF File Picker
  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri ->
    uri?.let {
      replacementUri?.let { old -> viewModel.reselectDocument(old, it) } ?: viewModel.openDocument(it)
    }
    replacementUri = null
  }

  Scaffold(
    topBar = {
      TopBar(
        onOpenFileClick = { filePickerLauncher.launch(arrayOf("*/*")) },
        onToggleSplitView = { viewModel.toggleSplitView() },
        isSplitView = isSplitView,
        canSplit = openTabs.size >= 2,
        onSupportMatrixClick = { showSupportMatrix = true },
        onSettingsClick = { showSettings = true }
      )
    },
    bottomBar = {
      // Anchored adaptive AdMob Banner at bottom
      if (canRequestAds) AdMobBanner()
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      if (openTabs.isNotEmpty()) {
        // Document Tab Strip
        DocumentTabs(
          tabs = openTabs,
          activeIndex = activeTabIndex,
          onSelectTab = { viewModel.selectTab(it) },
          onCloseTab = { viewModel.closeTab(it) },
          onAddTabClick = { filePickerLauncher.launch(arrayOf("*/*")) }
        )

        val activeTab = openTabs.getOrNull(activeTabIndex)
        val splitTab = splitTabIndex?.let { openTabs.getOrNull(it) }

        if (activeTab != null) {
          Box(modifier = Modifier.weight(1f)) {
            DocumentViewerContainer(
              activeTab = activeTab,
              splitTab = splitTab,
              isSplitView = isSplitView,
              onZoomIn = { viewModel.zoomIn(it) },
              onZoomOut = { viewModel.zoomOut(it) },
              onSetZoom = { id, z -> viewModel.setZoom(id, z) },
              onPageChange = { id, p -> viewModel.setPage(id, p) },
              onSheetChange = { id, s -> viewModel.setActiveSheet(id, s) },
              onToggleMarkdownRendered = { id, r -> viewModel.setMarkdownRendered(id, r) },
              onEncodingChange = { id, e -> viewModel.setTextEncoding(id, e) },
              onDelimiterChange = { id, d -> viewModel.setCsvDelimiter(id, d) },
              onToggleWordWrap = { viewModel.toggleWordWrap(it) },
              onRotateImage = { viewModel.rotateImage(it) },
              onSearchQueryChange = { id, q -> viewModel.setSearchQuery(id, q) },
              onOpenSupportMatrix = { showSupportMatrix = true },
              onOcrResult = { id, page, text -> viewModel.applyOcrResult(id, page, text) },
              onReselectDocument = { id ->
                replacementUri = openTabs.find { it.id == id }?.uri?.toString()
                filePickerLauncher.launch(arrayOf("*/*"))
              }
            )
          }
        }
      } else {
        // Empty State View with Sample documents and Recent Documents
        Box(modifier = Modifier.weight(1f)) {
          EmptyStateView(
            onOpenFileClick = { filePickerLauncher.launch(arrayOf("*/*")) },
            onLoadSample = { sampleType -> viewModel.loadSampleFile(sampleType) },
            recentDocuments = recentDocuments,
            onOpenRecent = { uri, name, size -> viewModel.openDocument(uri, name, size) },
            onRemoveRecent = { viewModel.removeRecent(it) },
            onReselectRecent = { old -> replacementUri = old; filePickerLauncher.launch(arrayOf("*/*")) }
          )
        }
      }
    }
  }

  // Support Matrix Dialog
  if (showSupportMatrix) {
    SupportMatrixDialog(onDismiss = { showSupportMatrix = false })
  }

  // Settings Dialog
  if (showSettings) {
    SettingsDialog(
      isRecentHistoryEnabled = isRecentHistoryEnabled,
      selectedTheme = selectedTheme,
      onToggleRecentHistory = { viewModel.setRecentHistoryEnabled(it) },
      onClearRecentHistory = { viewModel.clearRecentHistory() },
      onClearCache = { viewModel.clearDocumentCache() },
      canClearCache = openTabs.isEmpty(),
      isClearingCache = isClearingCache,
      cacheMessage = cacheMessage,
      onSelectTheme = { viewModel.userPrefs.setSelectedTheme(it) },
      privacyOptionsRequired = privacyOptionsRequired,
      onPrivacyOptions = onPrivacyOptions,
      onDismiss = { showSettings = false }
    )
  }
}

package com.example.ui.viewer

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.TextButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import com.example.model.PdfPageText
import com.example.parser.PdfOcr
import com.example.parser.OcrScript
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentTab
import com.example.model.PdfDocumentContent
import com.example.parser.PdfDocumentParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfViewer(
  tab: DocumentTab,
  content: PdfDocumentContent,
  onPageChange: (Int) -> Unit,
  onZoomChange: (Float) -> Unit,
  onOcrResult: (Int, PdfPageText) -> Unit = { _, _ -> }
) {
  val context = LocalContext.current
  val density = LocalDensity.current
  val scope = rememberCoroutineScope()
  var ocrJob by remember { mutableStateOf<Job?>(null) }
  var ocrScript by remember { mutableStateOf(OcrScript.LATIN) }
  var languageMenu by remember { mutableStateOf(false) }
  var ocrMessage by remember { mutableStateOf<String?>(null) }
  val listState = rememberLazyListState(initialFirstVisibleItemIndex = tab.currentPage)

  val file = remember(content.uri) {
    content.uri.path?.let { File(it) }
  }

  // Cache rendered page bitmaps to ensure fast scrolling and prevent memory leaks
  val pageBitmaps = remember(content.uri) {
    object : android.util.LruCache<Int, Bitmap>(16 * 1024 * 1024) {
      override fun sizeOf(key: Int, value: Bitmap) = value.allocationByteCount
    }
  }
  androidx.compose.runtime.DisposableEffect(pageBitmaps) {
    onDispose { pageBitmaps.evictAll() }
  }

  // Pan offsets for pinch-zoom
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }
  var jumping by remember { mutableStateOf(false) }

  // Sync scroll position when currentPage changes externally (e.g. from jump dialog)
  LaunchedEffect(tab.currentPage) {
    if (tab.currentPage in 0 until content.pageCount && listState.firstVisibleItemIndex != tab.currentPage) {
      jumping = true
      try { listState.scrollToItem(tab.currentPage) } finally { jumping = false }
    }
  }

  // Update current page as user scrolls
  val currentPage by rememberUpdatedState(tab.currentPage)
  val reportPage by rememberUpdatedState(onPageChange)
  LaunchedEffect(listState) {
    snapshotFlow { Triple(listState.firstVisibleItemIndex,listState.isScrollInProgress,jumping) }.collect { (page,scrolling,isJumping) ->
      if (!isJumping && scrolling && page != currentPage) reportPage(page)
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFFE2E8F0))
      .pointerInput(tab.zoomLevel) {
        detectTransformGestures { _, pan, zoom, _ ->
          val newZoom = (tab.zoomLevel * zoom).coerceIn(0.5f, 4.0f)
          onZoomChange(newZoom)
          if (newZoom > 1.0f) {
            offsetX += pan.x
            offsetY += pan.y
          } else {
            offsetX = 0f
            offsetY = 0f
          }
        }
      }
      .testTag("pdf_viewer_container")
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
    content.searchNotice?.let { Text(it, fontSize = 12.sp, color = Color(0xFF92400E), modifier = Modifier.fillMaxWidth().background(Color(0xFFFEF3C7)).padding(8.dp)) }
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
      Box {
        TextButton(onClick = { languageMenu = true }, enabled = ocrJob == null) { Text("OCR: " + ocrScript.label) }
        DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
          OcrScript.entries.forEach { script -> DropdownMenuItem(text = { Text(script.label) }, onClick = { ocrScript = script; languageMenu = false }) }
        }
      }
      TextButton(enabled = ocrJob == null && file != null, onClick = {
        val page = tab.currentPage
        ocrMessage = "Reading page "+(page+1)+" on device…"
        ocrJob = scope.launch {
          try {
            val result = withContext(Dispatchers.IO) {
              val dim = content.pageDimensions[page]
              val bitmap = PdfDocumentParser.renderPage(file!!, page, dim.first * 2, dim.second * 2)
                ?: error("Unable to render this page for OCR.")
              PdfOcr.recognize(bitmap, ocrScript)
            }
            if(result.text.isNotBlank()) onOcrResult(page,result)
            ocrMessage = if(result.text.isBlank()) "No text recognized. Try a different script or a clearer scan." else "Page "+(page+1)+": OCR text is searchable. Recognition may contain errors."
          } catch(e: CancellationException) { ocrMessage = "OCR cancelled."; throw e }
          catch(e: Exception) { ocrMessage = "OCR failed: "+(e.message ?: "Please try again.") }
          finally { ocrJob = null }
        }
      }) { Text("Scan page "+(tab.currentPage+1)) }
      if(ocrJob != null) TextButton(onClick = { ocrJob?.cancel() }) { Text("Cancel") }
    }
    ocrMessage?.let { Text(it, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp)) }
    LazyColumn(
      state = listState,
      contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = if(content.pageCount > 1) 72.dp else 16.dp),
      modifier = Modifier
        .fillMaxSize()
        .graphicsLayer {
          scaleX = tab.zoomLevel
          scaleY = tab.zoomLevel
          translationX = offsetX
          translationY = offsetY
        },
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(content.pageCount) { pageIndex ->
        var bitmap by remember(content.uri, pageIndex) { mutableStateOf(pageBitmaps.get(pageIndex)) }
        var renderFailed by remember(content.uri, pageIndex) { mutableStateOf(false) }

        LaunchedEffect(content.uri, pageIndex) {
          if (file != null && file.exists() && bitmap == null) {
            withContext(Dispatchers.IO) {
              val dim = content.pageDimensions.getOrNull(pageIndex) ?: Pair(595, 842)
              val targetW = (dim.first * 1.5f).toInt()
              val targetH = (dim.second * 1.5f).toInt()
              val rendered = PdfDocumentParser.renderPage(file, pageIndex, targetW, targetH)
              if (rendered != null) {
                withContext(Dispatchers.Main) {
                  pageBitmaps.put(pageIndex, rendered)
                  bitmap = rendered
                }
              } else {
                withContext(Dispatchers.Main) { renderFailed = true }
              }
            }
          }
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          if (bitmap != null) {
            Surface(
              shadowElevation = 4.dp,
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.padding(vertical = 4.dp)
            ) {
              val pageText = content.pageGeometry.getOrNull(pageIndex)
              val highlights = remember(pageText, tab.searchQuery) { pageText?.matches(tab.searchQuery).orEmpty() }
              Box(Modifier.fillMaxWidth().aspectRatio(bitmap!!.width.toFloat()/bitmap!!.height)) {
                Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Page ${pageIndex + 1}", modifier = Modifier.matchParentSize())
                Canvas(Modifier.matchParentSize()) {
                  highlights.forEach { box -> drawRect(Color(0x66FFD600), Offset(box.left*size.width,box.top*size.height),
                    Size((box.right-box.left)*size.width,(box.bottom-box.top)*size.height)) }
                }
              }
            }
          } else {
            Box(
              modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(350.dp)
                .background(Color.White, RoundedCornerShape(4.dp)),
              contentAlignment = Alignment.Center
            ) {
              if (renderFailed) Text("Unable to render this page.", color = Color.DarkGray)
              else CircularProgressIndicator(modifier = Modifier.size(32.dp))
            }
          }
        }
      }
    }

    }

    // Thumbnail strip at bottom
    if (content.pageCount > 1) {
      Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
        shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp),
        shadowElevation = 6.dp,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .height(56.dp)
      ) {
        LazyRow(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          items(content.pageCount) { idx ->
            val isCurrent = idx == tab.currentPage
            Box(
              modifier = Modifier
                .width(36.dp)
                .height(44.dp)
                .background(
                  color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(4.dp)
                )
                .clickable {
                  onPageChange(idx)
                },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "${idx + 1}",
                fontSize = 11.sp,
                color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }
  }
}

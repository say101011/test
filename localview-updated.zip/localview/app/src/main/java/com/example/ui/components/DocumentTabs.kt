package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DocumentTab
import com.example.model.DocumentType

@Composable
fun DocumentTabs(
  tabs: List<DocumentTab>,
  activeIndex: Int,
  onSelectTab: (Int) -> Unit,
  onCloseTab: (Int) -> Unit,
  onAddTabClick: () -> Unit
) {
  if (tabs.isEmpty()) return

  Surface(
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      tabs.forEachIndexed { index, tab ->
        val isSelected = index == activeIndex
        TabItem(
          tab = tab,
          isSelected = isSelected,
          onClick = { onSelectTab(index) },
          onClose = { onCloseTab(index) },
          index = index
        )
        Spacer(modifier = Modifier.width(6.dp))
      }

      IconButton(
        onClick = onAddTabClick,
        modifier = Modifier
          .size(36.dp)
          .testTag("tab_add_button")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = stringResource(R.string.open_file),
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

@Composable
private fun TabItem(
  tab: DocumentTab,
  isSelected: Boolean,
  onClick: () -> Unit,
  onClose: () -> Unit,
  index: Int
) {
  val containerColor = if (isSelected) {
    MaterialTheme.colorScheme.surface
  } else {
    Color.Transparent
  }

  val textColor = if (isSelected) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.onSurfaceVariant
  }

  val shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = 8.dp, bottomEnd = 8.dp)

  Surface(
    shape = shape,
    color = containerColor,
    shadowElevation = if (isSelected) 2.dp else 0.dp,
    modifier = Modifier
      .height(38.dp)
      .widthIn(min = 120.dp, max = 220.dp)
      .clickable { onClick() }
      .testTag("document_tab_$index")
  ) {
    Row(
      modifier = Modifier.padding(start = 8.dp, end = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Format badge
      FormatBadge(type = tab.type)
      Spacer(modifier = Modifier.width(6.dp))

      Text(
        text = tab.displayName,
        fontSize = 13.sp,
        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
        color = textColor,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f)
      )

      IconButton(
        onClick = onClose,
        modifier = Modifier
          .size(28.dp)
          .testTag("close_tab_$index")
      ) {
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = stringResource(R.string.tabs_close),
          tint = textColor.copy(alpha = 0.7f),
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

@Composable
fun FormatBadge(type: DocumentType) {
  val (bgColor, label) = when (type) {
    DocumentType.PDF -> Pair(Color(0xFFDC2626), "PDF")
    DocumentType.EXCEL -> Pair(Color(0xFF16A34A), "XLS")
    DocumentType.CSV -> Pair(Color(0xFF059669), "CSV")
    DocumentType.WORD -> Pair(Color(0xFF2563EB), "DOC")
    DocumentType.HWP -> Pair(Color(0xFF0284C7), "HWP")
    DocumentType.HWPX -> Pair(Color(0xFF0891B2), "HWPX")
    DocumentType.MARKDOWN -> Pair(Color(0xFF7C3AED), "MD")
    DocumentType.TEXT -> Pair(Color(0xFF64748B), "TXT")
    DocumentType.IMAGE -> Pair(Color(0xFFD97706), "IMG")
    DocumentType.UNKNOWN -> Pair(Color(0xFF6B7280), "?")
  }

  Box(
    modifier = Modifier
      .background(color = bgColor, shape = RoundedCornerShape(4.dp))
      .padding(horizontal = 4.dp, vertical = 2.dp)
  ) {
    Text(
      text = label,
      color = Color.White,
      fontSize = 9.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

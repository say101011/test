package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.*
import com.example.parser.CompoundDocument.Companion.i32
import com.example.parser.CompoundDocument.Companion.u16
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

object LegacyDocuments {
  private fun compound(context: Context, uri: Uri) = context.contentResolver.openInputStream(uri)!!.use { CompoundDocument(DocumentIo.readLimited(it)) }

  fun hwp(context: Context, uri: Uri): DocumentContent = safely("HWP") {
    val cfb = compound(context, uri)
    val header = cfb.read("FileHeader")
    require(header.size >= 40 && String(header, 0, 17, Charsets.US_ASCII) == "HWP Document File") { "Not an HWP 5 document." }
    val flags = i32(header, 36)
    if (flags and 2 != 0) return@safely EncryptedDocumentContent("Password-protected HWP documents are not supported.")
    if (flags and 4 != 0) return@safely UnsupportedDocumentContent("Distribution-protected HWP documents are not supported. Open an unprotected HWPX or PDF export.")
    val sections = cfb.names.filter { it.matches(Regex("BodyText/Section\\d+")) }.sortedBy { it.substringAfter("Section").toInt() }
    require(sections.isNotEmpty()) { "No HWP body sections were found." }
    val blocks = mutableListOf<DocBlock>()
    var expanded = 0L
    for (name in sections) {
      val raw = cfb.read(name)
      val bytes = if (flags and 1 != 0) {
        val inflater = Inflater(true)
        try { InflaterInputStream(raw.inputStream(), inflater).use { DocumentIo.readLimited(it) } }
        finally { inflater.end() }
      } else raw
      expanded += bytes.size
      require(expanded <= DocumentIo.MAX_TEXT_BYTES) { "HWP body exceeds the 8 MiB expanded limit." }
      blocks.addAll(hwpSection(bytes))
    }
    StructuredTextDocumentContent(DocumentType.HWP, blocks, true,
      "HWP body text and basic table grids are shown in section order. Cell paragraphs and coordinates are preserved; nested/merged layouts, images, headers, notes and page formatting remain simplified. Use a PDF export for the original layout.")
  }

  internal fun hwpSection(bytes: ByteArray): List<DocBlock> {
    data class Record(val tag: Int,val level: Int,val offset: Int,val size: Int)
    val records=mutableListOf<Record>();var p=0
    while(p<bytes.size) {
      DocumentIo.checkCancelled()
      val header=i32(bytes,p);p+=4
      var size=header ushr 20
      if(size==4095) { size=i32(bytes,p);p+=4 }
      require(size>=0 && p.toLong()+size<=bytes.size) { "Truncated HWP record." }
      records.add(Record(header and 1023,(header ushr 10) and 1023,p,size));p+=size
      require(records.size<=100_000)
    }
    fun text(r: Record):String {
      val out=StringBuilder();var q=r.offset
      while(q+1<r.offset+r.size) {
        val code=u16(bytes,q)
        when {
          code==9 -> { out.append('\t');q+=16 }
          code==10 || code==13 -> { out.append('\n');q+=2 }
          code in 1..8 || code in 11..12 || code in 14..23 -> q+=16
          code>=32 -> { out.append(code.toChar());q+=2 }
          else -> q+=2
        }
      }
      return out.toString().trimEnd('\n')
    }
    val blocks=mutableListOf<DocBlock>();var i=0
    while(i<records.size) {
      val r=records[i]
      if(r.tag==77 && r.size>=8) {
        val rows=u16(bytes,r.offset+4);val cols=u16(bytes,r.offset+6)
        require(rows in 1..1000 && cols in 1..100 && rows*cols<=100_000) { "HWP table exceeds preview limits." }
        val cells=Array(rows) { Array(cols) { StringBuilder() } }
        var end=i+1;var cell:Pair<Int,Int>?=null
        while(end<records.size && records[end].level>=r.level) {
          val next=records[end]
          if(next.tag==72 && next.level==r.level && next.size>=38) {
            val col=u16(bytes,next.offset+8);val row=u16(bytes,next.offset+10)
            cell=if(row in 0 until rows && col in 0 until cols) row to col else null
          } else if(next.tag==67 && cell!=null) {
            val value=text(next);val target=cells[cell.first][cell.second]
            if(target.isNotEmpty()) target.append('\n')
            target.append(value)
          }
          end++
        }
        blocks.add(DocBlock.Table(emptyList(),cells.map { row -> row.map { it.toString() } }));i=end
      } else { if(r.tag==67) text(r).takeIf { it.isNotBlank() }?.let { blocks.add(DocBlock.Paragraph(it)) };i++ }
    }
    return blocks
  }

  fun doc(context: Context, uri: Uri): DocumentContent = safely("DOC") {
    val cfb = compound(context, uri)
    val word = cfb.read("WordDocument")
    require(u16(word, 0) == 0xa5ec && u16(word, 2) >= 0xc1) { "Only Word 97–2003 DOC files are supported." }
    val flags = u16(word, 10)
    if (flags and 0x8100 != 0) return@safely EncryptedDocumentContent("Encrypted or obfuscated DOC documents are not supported.")
    val table = cfb.read(if (flags and 0x200 != 0) "1Table" else "0Table")
    var p = 32
    p += 2 + u16(word, p) * 2
    val longs = u16(word, p); p += 2
    require(longs >= 4)
    val bodyChars = i32(word, p + 12)
    require(bodyChars in 0..4_000_000)
    p += longs * 4
    require(u16(word, p) > 33); p += 2
    val fc = i32(word, p + 33 * 8)
    val length = i32(word, p + 33 * 8 + 4)
    require(fc >= 0 && length > 0 && fc.toLong() + length <= table.size) { "DOC piece table is missing or invalid." }
    p = fc
    while (p < fc + length && table[p].toInt() == 1) p += 3 + u16(table, p + 1)
    require(p < fc + length && table[p].toInt() == 2) { "Unsupported DOC piece table." }
    val size = i32(table, p + 1); p += 5
    require(size >= 4 && (size - 4) % 12 == 0 && p.toLong() + size <= fc + length) { "Invalid DOC piece records." }
    val pieces = (size - 4) / 12
    val text = StringBuilder()
    for (index in 0 until pieces) {
      DocumentIo.checkCancelled()
      val first = i32(table, p + index * 4)
      val last = i32(table, p + (index + 1) * 4)
      require(first >= 0 && last >= first)
      if (first >= bodyChars) break
      val count = minOf(last, bodyChars) - first
      val packed = i32(table, p + (pieces + 1) * 4 + index * 8 + 2)
      val compressed = packed and 0x40000000 != 0
      val offset = (packed and 0x3fffffff) / if (compressed) 2 else 1
      val byteCount = count.toLong() * if (compressed) 1 else 2
      require(offset.toLong() + byteCount <= word.size) { "Truncated DOC text piece." }
      text.append(String(word, offset, byteCount.toInt(), if (compressed) charset("windows-1252") else Charsets.UTF_16LE))
    }
    require(text.length == bodyChars) { "DOC body text is incomplete." }
    val cleaned = StringBuilder()
    val fields = mutableListOf<Boolean>()
    for (ch in text) when (ch.code) {
      19 -> fields.add(false)
      20 -> if (fields.isNotEmpty()) fields[fields.lastIndex] = true
      21 -> if (fields.isNotEmpty()) fields.removeAt(fields.lastIndex)
      else -> if (fields.all { it }) when {
        ch == '\r' || ch.code == 11 || ch.code == 12 -> cleaned.append('\n')
        ch.code == 7 || ch == '\t' -> cleaned.append('\t')
        ch.code >= 32 -> cleaned.append(ch)
      }
    }
    StructuredTextDocumentContent(DocumentType.WORD,
      cleaned.lines().filter { it.isNotBlank() }.map { DocBlock.Paragraph(it) }, true,
      "DOC body text follows the document piece table. Table cells are separated by tabs; original grid layout, images, headers, notes and styling are not reproduced. Field results may be cached. Use DOCX or PDF for richer layout.")
  }

  private inline fun safely(format: String, block: () -> DocumentContent): DocumentContent = try { block() }
  catch (e: java.util.concurrent.CancellationException) { throw e }
  catch (e: Exception) { CorruptedDocumentContent("Unable to read $format: ${e.message}") }
}

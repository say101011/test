package com.example.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CorruptedDocumentContent
import com.example.model.DocumentTab
import com.example.model.EncryptedDocumentContent
import com.example.model.ImageDocumentContent
import com.example.model.MarkdownDocumentContent
import com.example.model.PdfDocumentContent
import com.example.model.PlainTextDocumentContent
import com.example.model.SpreadsheetDocumentContent
import com.example.model.StructuredTextDocumentContent
import com.example.model.UnsupportedDocumentContent
import com.example.ui.components.ViewerToolbar

@Composable
fun DocumentViewerContainer(
  activeTab: DocumentTab,
  splitTab: DocumentTab?,
  isSplitView: Boolean,
  onZoomIn: (String) -> Unit,
  onZoomOut: (String) -> Unit,
  onSetZoom: (String, Float) -> Unit,
  onPageChange: (String, Int) -> Unit,
  onSheetChange: (String, Int) -> Unit,
  onToggleMarkdownRendered: (String, Boolean) -> Unit,
  onEncodingChange: (String, String) -> Unit,
  onDelimiterChange: (String, Char) -> Unit,
  onToggleWordWrap: (String) -> Unit,
  onRotateImage: (String) -> Unit,
  onSearchQueryChange: (String, String) -> Unit,
  onOpenSupportMatrix: () -> Unit,
  onReselectDocument: (String) -> Unit = {},
  onOcrResult: (String, Int, com.example.model.PdfPageText) -> Unit = { _, _, _ -> }
) {
  BoxWithConstraints(modifier = Modifier.fillMaxSize().testTag("viewer_content_area")) {
    val isWideScreen = maxWidth > 600.dp

    if (isSplitView && splitTab != null) {
      if (isWideScreen) {
        // Horizontal split (Left & Right panes)
        Row(modifier = Modifier.fillMaxSize()) {
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            SingleTabViewer(
              tab = activeTab,
              onZoomIn = { onZoomIn(activeTab.id) },
              onZoomOut = { onZoomOut(activeTab.id) },
              onSetZoom = { onSetZoom(activeTab.id, it) },
              onPageChange = { onPageChange(activeTab.id, it) },
              onSheetChange = { onSheetChange(activeTab.id, it) },
              onToggleMarkdownRendered = { onToggleMarkdownRendered(activeTab.id, it) },
              onEncodingChange = { onEncodingChange(activeTab.id, it) },
              onDelimiterChange = { onDelimiterChange(activeTab.id, it) },
              onToggleWordWrap = { onToggleWordWrap(activeTab.id) },
              onRotateImage = { onRotateImage(activeTab.id) },
              onSearchQueryChange = { onSearchQueryChange(activeTab.id, it) },
              onOpenSupportMatrix = onOpenSupportMatrix,
              onReselect = { onReselectDocument(activeTab.id) },
              onOcrResult = { page, text -> onOcrResult(activeTab.id, page, text) }
            )
          }
          androidx.compose.material3.VerticalDivider(modifier = Modifier.fillMaxHeight().width(2.dp), color = MaterialTheme.colorScheme.outline)
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            SingleTabViewer(
              tab = splitTab,
              onZoomIn = { onZoomIn(splitTab.id) },
              onZoomOut = { onZoomOut(splitTab.id) },
              onSetZoom = { onSetZoom(splitTab.id, it) },
              onPageChange = { onPageChange(splitTab.id, it) },
              onSheetChange = { onSheetChange(splitTab.id, it) },
              onToggleMarkdownRendered = { onToggleMarkdownRendered(splitTab.id, it) },
              onEncodingChange = { onEncodingChange(splitTab.id, it) },
              onDelimiterChange = { onDelimiterChange(splitTab.id, it) },
              onToggleWordWrap = { onToggleWordWrap(splitTab.id) },
              onRotateImage = { onRotateImage(splitTab.id) },
              onSearchQueryChange = { onSearchQueryChange(splitTab.id, it) },
              onOpenSupportMatrix = onOpenSupportMatrix,
              onReselect = { onReselectDocument(splitTab.id) },
              onOcrResult = { page, text -> onOcrResult(splitTab.id, page, text) }
            )
          }
        }
      } else {
        // Vertical split (Top & Bottom panes)
        Column(modifier = Modifier.fillMaxSize()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            SingleTabViewer(
              tab = activeTab,
              onZoomIn = { onZoomIn(activeTab.id) },
              onZoomOut = { onZoomOut(activeTab.id) },
              onSetZoom = { onSetZoom(activeTab.id, it) },
              onPageChange = { onPageChange(activeTab.id, it) },
              onSheetChange = { onSheetChange(activeTab.id, it) },
              onToggleMarkdownRendered = { onToggleMarkdownRendered(activeTab.id, it) },
              onEncodingChange = { onEncodingChange(activeTab.id, it) },
              onDelimiterChange = { onDelimiterChange(activeTab.id, it) },
              onToggleWordWrap = { onToggleWordWrap(activeTab.id) },
              onRotateImage = { onRotateImage(activeTab.id) },
              onSearchQueryChange = { onSearchQueryChange(activeTab.id, it) },
              onOpenSupportMatrix = onOpenSupportMatrix,
              onReselect = { onReselectDocument(activeTab.id) },
              onOcrResult = { page, text -> onOcrResult(activeTab.id, page, text) }
            )
          }
          HorizontalDivider(modifier = Modifier.fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.outline)
          Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            SingleTabViewer(
              tab = splitTab,
              onZoomIn = { onZoomIn(splitTab.id) },
              onZoomOut = { onZoomOut(splitTab.id) },
              onSetZoom = { onSetZoom(splitTab.id, it) },
              onPageChange = { onPageChange(splitTab.id, it) },
              onSheetChange = { onSheetChange(splitTab.id, it) },
              onToggleMarkdownRendered = { onToggleMarkdownRendered(splitTab.id, it) },
              onEncodingChange = { onEncodingChange(splitTab.id, it) },
              onDelimiterChange = { onDelimiterChange(splitTab.id, it) },
              onToggleWordWrap = { onToggleWordWrap(splitTab.id) },
              onRotateImage = { onRotateImage(splitTab.id) },
              onSearchQueryChange = { onSearchQueryChange(splitTab.id, it) },
              onOpenSupportMatrix = onOpenSupportMatrix,
              onReselect = { onReselectDocument(splitTab.id) },
              onOcrResult = { page, text -> onOcrResult(splitTab.id, page, text) }
            )
          }
        }
      }
    } else {
      // Single Tab Mode
      SingleTabViewer(
        tab = activeTab,
        onZoomIn = { onZoomIn(activeTab.id) },
        onZoomOut = { onZoomOut(activeTab.id) },
        onSetZoom = { onSetZoom(activeTab.id, it) },
        onPageChange = { onPageChange(activeTab.id, it) },
        onSheetChange = { onSheetChange(activeTab.id, it) },
        onToggleMarkdownRendered = { onToggleMarkdownRendered(activeTab.id, it) },
        onEncodingChange = { onEncodingChange(activeTab.id, it) },
        onDelimiterChange = { onDelimiterChange(activeTab.id, it) },
        onToggleWordWrap = { onToggleWordWrap(activeTab.id) },
        onRotateImage = { onRotateImage(activeTab.id) },
        onSearchQueryChange = { onSearchQueryChange(activeTab.id, it) },
        onOpenSupportMatrix = onOpenSupportMatrix,
              onReselect = { onReselectDocument(activeTab.id) },
              onOcrResult = { page, text -> onOcrResult(activeTab.id, page, text) }
      )
    }
  }
}

@Composable
private fun SingleTabViewer(
  tab: DocumentTab,
  onZoomIn: () -> Unit,
  onZoomOut: () -> Unit,
  onSetZoom: (Float) -> Unit,
  onPageChange: (Int) -> Unit,
  onSheetChange: (Int) -> Unit,
  onToggleMarkdownRendered: (Boolean) -> Unit,
  onEncodingChange: (String) -> Unit,
  onDelimiterChange: (Char) -> Unit,
  onToggleWordWrap: () -> Unit,
  onRotateImage: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onOpenSupportMatrix: () -> Unit,
  onReselect: () -> Unit,
  onOcrResult: (Int, com.example.model.PdfPageText) -> Unit
) {
  Column(modifier = Modifier.fillMaxSize()) {
    // Toolbar for this tab
    ViewerToolbar(
      tab = tab,
      onZoomIn = onZoomIn,
      onZoomOut = onZoomOut,
      onSetZoom = onSetZoom,
      onPageChange = onPageChange,
      onSheetChange = onSheetChange,
      onToggleMarkdownRendered = onToggleMarkdownRendered,
      onEncodingChange = onEncodingChange,
      onDelimiterChange = onDelimiterChange,
      onToggleWordWrap = onToggleWordWrap,
      onRotateImage = onRotateImage,
      onSearchQueryChange = onSearchQueryChange
    )

    androidx.compose.runtime.key(tab.id) {
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        if (tab.isLoading) {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = stringResource(R.string.loading_document),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          when (val content = tab.content) {
            is PdfDocumentContent -> {
              PdfViewer(
                tab = tab,
                content = content,
                onPageChange = onPageChange,
                onZoomChange = onSetZoom,
                onOcrResult = onOcrResult
              )
            }
            is SpreadsheetDocumentContent -> {
              SpreadsheetViewer(
                tab = tab,
                content = content,
                onSheetChange = onSheetChange
              )
            }
            is StructuredTextDocumentContent -> {
              StructuredTextViewer(
                tab = tab,
                content = content,
                onZoomChange = onSetZoom
              )
            }
            is MarkdownDocumentContent -> {
              MarkdownViewer(
                tab = tab,
                content = content
              )
            }
            is PlainTextDocumentContent -> {
              PlainTextViewer(
                tab = tab,
                content = content
              )
            }
            is ImageDocumentContent -> {
              ImageViewer(
                tab = tab,
                content = content,
                onZoomChange = onSetZoom
              )
            }
            is EncryptedDocumentContent -> {
              ErrorStateCard(
                icon = Icons.Default.Lock,
                title = stringResource(R.string.encrypted_document_title),
                message = content.reason,
                actionLabel = null,
                onAction = {}
              )
            }
            is CorruptedDocumentContent -> {
              ErrorStateCard(
                icon = Icons.Default.ErrorOutline,
                title = stringResource(R.string.corrupted_document_title),
                message = content.reason,
                actionLabel = if (content.canReselect) "Select File Again" else stringResource(R.string.support_matrix_btn),
                onAction = if (content.canReselect) onReselect else onOpenSupportMatrix
              )
            }
            is UnsupportedDocumentContent -> {
              ErrorStateCard(
                icon = Icons.AutoMirrored.Filled.HelpOutline,
                title = stringResource(R.string.unsupported_format_title),
                message = content.reason,
                actionLabel = stringResource(R.string.support_matrix_btn),
                onAction = onOpenSupportMatrix
              )
            }
            null -> {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No document content loaded")
              }
            }
          }
        }
      }
    }
  }
  
}

@Composable
private fun ErrorStateCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  message: String,
  actionLabel: String?,
  onAction: () -> Unit
) {
  Box(
    modifier = Modifier.fillMaxSize().padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.fillMaxWidth(0.9f)
    ) {
      Box(
        modifier = Modifier
          .size(64.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.errorContainer),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          modifier = Modifier.size(32.dp),
          tint = MaterialTheme.colorScheme.error
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = message,
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      if (actionLabel != null) {
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedButton(onClick = onAction) {
          Text(actionLabel)
        }
      }
    }
  }
}

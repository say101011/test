package com.example.parser

import com.example.model.SheetChart
import com.example.model.ChartKind
import com.example.model.ChartPreview
import com.example.model.ChartSeries
import org.w3c.dom.Element
import java.net.URI
import com.example.parser.OfficeXml.attr
import com.example.parser.OfficeXml.children
import com.example.parser.OfficeXml.name
import com.example.parser.OfficeXml.descendants

internal object XlsxCharts {
  fun read(parts: Map<String,ByteArray>, sheetPath: String): List<SheetChart> {
    fun relationships(path:String):Map<String,String> {
      val relPath=path.substringBeforeLast('/')+"/_rels/"+path.substringAfterLast('/')+".rels"
      return parts[relPath]?.let { bytes -> descendants(OfficeXml.parse(bytes),"Relationship").filter { attr(it,"TargetMode")!="External" }
        .associate { attr(it,"Id") to URI(path).resolve(attr(it,"Target")).normalize().path.removePrefix("/") } } ?: emptyMap()
    }
    fun cache(node:Element?):Map<Int,String> {
      if(node==null)return emptyMap()
      return descendants(node,"pt").take(1000).mapNotNull { point -> attr(point,"idx").toIntOrNull()?.takeIf { it in 0..999 }?.let { it to descendants(point,"v").joinToString("") { v->v.textContent } } }.toMap()
    }
    return try {
      val sheet=OfficeXml.parse(parts.getValue(sheetPath));val sheetRels=relationships(sheetPath)
      val chartPaths=descendants(sheet,"drawing").mapNotNull { sheetRels[attr(it,"id")] }.flatMap { drawingPath ->
        val drawing=parts[drawingPath]?.let(OfficeXml::parse) ?: return@flatMap emptyList<String>()
        val rels=relationships(drawingPath)
        descendants(drawing,"chart").mapNotNull { rels[attr(it,"id")] }
      }.distinct().take(16)
      var pointBudget = 1000
      chartPaths.mapNotNull { path -> parts[path]?.let { bytes ->
        val chart=OfficeXml.parse(bytes)
        val title=descendants(chart,"title").firstOrNull()?.let { descendants(it,"t").joinToString(" ") { t->t.textContent } }.orEmpty().ifBlank { "Chart" }
        val rows=mutableListOf(listOf("Series","Category","Value"))
        descendants(chart,"ser").take(32).forEachIndexed { index,ser ->
          val tx=children(ser).firstOrNull { name(it)=="tx" }
          val series=tx?.let { descendants(it,"v").firstOrNull()?.textContent }.orEmpty().ifBlank { "Series ${index+1}" }
          val categories=cache(children(ser).firstOrNull { name(it) in listOf("cat","xVal") })
          val values=cache(children(ser).firstOrNull { name(it) in listOf("val","yVal") })
          values.toSortedMap().forEach { (i,value) -> if(pointBudget>0) { rows.add(listOf(series,categories[i] ?: (i+1).toString(),value));pointBudget-- } }
        }
        if(rows.size==1) rows.add(listOf(if(pointBudget==0) "Preview limit reached (1,000 chart points per sheet)" else "No saved chart values","",""))
        else if(pointBudget==0) rows.add(listOf("Preview limit reached (1,000 chart points per sheet)","",""))
        SheetChart(title,rows,preview(chart))
      } }
    } catch(e:java.util.concurrent.CancellationException) { throw e }
    catch(_:Exception) { listOf(SheetChart("Chart data unavailable",listOf(listOf("This chart could not be read.")))) }
  }

  // A small, complete cached chart is drawn only when its semantics are supported.
  // Complex/stacked/combo charts still expose the saved table without a misleading graph.
  internal fun preview(chart: Element): ChartPreview? {
    val plot = descendants(chart,"plotArea").firstOrNull() ?: return null
    val types = children(plot).filter { name(it).endsWith("Chart") }
    val type = types.singleOrNull() ?: return null
    val kind = when(name(type)) {
      "barChart" -> if(children(type).firstOrNull { name(it)=="barDir" }?.let { attr(it,"val") }=="bar") ChartKind.BAR else ChartKind.COLUMN
      "lineChart" -> ChartKind.LINE
      else -> return null
    }
    val grouping=children(type).firstOrNull { name(it)=="grouping" }?.let { attr(it,"val") }
    if(grouping!=null && grouping !in listOf("standard","clustered")) return null
    if(descendants(plot,"logBase").isNotEmpty()) return null
    val seriesNodes=children(type).filter { name(it)=="ser" }
    if(seriesNodes.isEmpty() || seriesNodes.size>8) return null
    fun points(node:Element?, numeric:Boolean):Map<Int,String> {
      if(node==null)return emptyMap()
      val cache=descendants(node,if(numeric) "numCache" else "strCache").firstOrNull()
        ?: descendants(node,"numCache").firstOrNull()
        ?: children(node).firstOrNull { name(it) in listOf("numLit","strLit") } ?: return emptyMap()
      return children(cache).filter { name(it)=="pt" }.associate { attr(it,"idx").toIntOrNull().let { i -> i ?: -1 } to children(it).firstOrNull { v->name(v)=="v" }?.textContent.orEmpty() }
    }
    val values=seriesNodes.map { points(children(it).firstOrNull { n->name(n)=="val" },true) }
    val indices=values.flatMap { it.keys }
    if(indices.isEmpty() || indices.any { it !in 0..23 })return null
    val count=indices.max()+1
    val categories=MutableList(count) { "${it+1}" }
    val known=mutableMapOf<Int,String>()
    for(ser in seriesNodes) for((i,label) in points(children(ser).firstOrNull { name(it)=="cat" },false)) {
      if(i !in 0 until count)return null
      if(known.containsKey(i) && known[i]!=label)return null
      known[i]=label;categories[i]=label
    }
    val series=seriesNodes.mapIndexed { index,ser ->
      val tx=children(ser).firstOrNull { name(it)=="tx" }
      val title=tx?.let { descendants(it,"v").firstOrNull()?.textContent }.orEmpty().ifBlank { "Series ${index+1}" }
      ChartSeries(title,List(count) { values[index][it]?.toDoubleOrNull()?.takeIf(Double::isFinite) })
    }
    if(series.none { s->s.values.any { it!=null } })return null
    return ChartPreview(kind,categories,series)
  }
}

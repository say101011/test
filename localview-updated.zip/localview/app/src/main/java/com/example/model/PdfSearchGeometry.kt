package com.example.model

/** Text offsets and normalized coordinates in the displayed (rotated) page. */
data class PdfTextBox(val start: Int, val end: Int, val left: Float, val top: Float, val right: Float, val bottom: Float)
data class PdfPageText(val text: String, val boxes: List<PdfTextBox>, val source: String = "PDF") {
  fun matches(query: String): List<PdfTextBox> {
    if (query.isBlank()) return emptyList()
    val ranges = mutableListOf<IntRange>()
    var offset = 0
    while(offset <= text.length - query.length && ranges.size < 2000) {
      val at = text.indexOf(query, offset, ignoreCase = true)
      if(at < 0) break
      ranges.add(at until at + query.length); offset = at + query.length
    }
    // Both collections are in text order; avoid O(glyphs * matches) on large pages.
    var range = 0
    return boxes.filter { box ->
      while(range < ranges.size && ranges[range].last < box.start) range++
      range < ranges.size && box.end > ranges[range].first && box.start <= ranges[range].last
    }
  }
}

package com.example.model

import android.graphics.Bitmap
import android.net.Uri

sealed interface DocumentContent

data class PdfDocumentContent(
  val uri: Uri,
  val pageCount: Int,
  val pageDimensions: List<Pair<Int, Int>>,
  val title: String,
  val pageTextList: List<String> = emptyList(),
  val searchNotice: String? = null,
  val pageGeometry: List<PdfPageText> = emptyList()
) : DocumentContent

data class CellData(
  val row: Int,
  val col: Int,
  val value: String,
  val formattedValue: String = value,
  val isBold: Boolean = false,
  val isHeader: Boolean = false
)

data class MergedRegion(val firstRow: Int, val firstCol: Int, val lastRow: Int, val lastCol: Int)

data class SheetData(
  val name: String,
  val maxRows: Int,
  val maxCols: Int,
  val columnHeaders: List<String>,
  val rows: List<List<CellData>>,
  val noticeMessage: String? = null,
  val mergedRegions: List<MergedRegion> = emptyList(),
  val charts: List<SheetChart> = emptyList()
)

enum class ChartKind { COLUMN, BAR, LINE }
data class ChartSeries(val name: String, val values: List<Double?>)
data class ChartPreview(val kind: ChartKind, val categories: List<String>, val series: List<ChartSeries>)
data class SheetChart(val title: String, val rows: List<List<String>>, val preview: ChartPreview? = null)

data class SpreadsheetDocumentContent(
  val sheets: List<SheetData>,
  val activeSheetIndex: Int = 0,
  val isSimplified: Boolean = false,
  val noticeMessage: String? = null
) : DocumentContent

data class TextStyleRange(val start: Int, val end: Int, val bold: Boolean = false, val italic: Boolean = false)

sealed interface DocBlock {
  data class Heading(val level: Int, val text: String) : DocBlock
  data class Paragraph(
    val text: String,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val styles: List<TextStyleRange> = emptyList()
  ) : DocBlock
  data class Table(val headers: List<String>, val rows: List<List<String>>) : DocBlock
  data class EmbeddedImage(val bitmap: Bitmap, val altText: String = "") : DocBlock
  data object Divider : DocBlock
}

data class StructuredTextDocumentContent(
  val type: DocumentType,
  val blocks: List<DocBlock>,
  val isSimplified: Boolean = true,
  val noticeMessage: String
) : DocumentContent

sealed interface MarkdownBlock {
  data class Heading(val level: Int, val text: String) : MarkdownBlock
  data class Paragraph(val text: String) : MarkdownBlock
  data class CodeBlock(val language: String, val code: String) : MarkdownBlock
  data class BlockQuote(val text: String) : MarkdownBlock
  data class ListItem(val text: String, val level: Int = 0, val isOrdered: Boolean = false, val index: Int = 1) : MarkdownBlock
  data class ChecklistItem(val text: String, val isChecked: Boolean) : MarkdownBlock
  data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock
}

data class MarkdownDocumentContent(
  val rawText: String,
  val blocks: List<MarkdownBlock>
) : DocumentContent

data class PlainTextDocumentContent(
  val text: String,
  val lines: List<String>,
  val encoding: String,
  val isWrapped: Boolean = true,
  val fontSizeSp: Float = 14f
) : DocumentContent

data class ImageDocumentContent(
  val bitmap: Bitmap,
  val originalWidth: Int,
  val originalHeight: Int,
  val rotationDegrees: Int = 0
) : DocumentContent

data class EncryptedDocumentContent(val reason: String) : DocumentContent
data class CorruptedDocumentContent(val reason: String, val canReselect: Boolean = false) : DocumentContent
data class UnsupportedDocumentContent(val reason: String) : DocumentContent

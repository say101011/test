package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import androidx.compose.ui.platform.LocalContext
import com.example.PrivacyPolicyActivity

@Composable
fun SettingsDialog(
  isRecentHistoryEnabled: Boolean,
  selectedTheme: String,
  onToggleRecentHistory: (Boolean) -> Unit,
  onClearRecentHistory: () -> Unit,
  onSelectTheme: (String) -> Unit,
  onDismiss: () -> Unit,
  onClearCache: () -> Unit = {},
  canClearCache: Boolean = false,
  isClearingCache: Boolean = false,
  cacheMessage: String? = null,
  privacyOptionsRequired: Boolean = false,
  onPrivacyOptions: () -> Unit = {}
) {
  val context = LocalContext.current
  var isThemeMenuOpen by remember { mutableStateOf(false) }

  val themes = listOf(
    Pair("system", "System Default"),
    Pair("light", "Light"),
    Pair("dark", "Dark")
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(R.string.settings),
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        // Privacy Guarantee Box
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
            .padding(12.dp)
        ) {
          Row(verticalAlignment = Alignment.Top) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = stringResource(R.string.privacy_title),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = stringResource(R.string.privacy_desc),
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
          onClick = { PrivacyPolicyActivity.open(context) },
          modifier = Modifier.fillMaxWidth().testTag("privacy_policy_button")
        ) {
          Text(stringResource(R.string.privacy_policy))
        }
        if (privacyOptionsRequired) {
          TextButton(onClick = onPrivacyOptions, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.privacy_options))
          }
        }
        TextButton(
          onClick = { context.startActivity(android.content.Intent(context, PrivacyPolicyActivity::class.java)) },
          modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.privacy_policy_offline)) }

        // Theme setting
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.theme),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
          )

          Box {
            OutlinedButton(
              onClick = { isThemeMenuOpen = true },
              modifier = Modifier.testTag("settings_theme_dropdown")
            ) {
              val currentThemeLabel = themes.find { it.first == selectedTheme }?.second ?: selectedTheme
              Text(currentThemeLabel, fontSize = 14.sp)
            }

            DropdownMenu(
              expanded = isThemeMenuOpen,
              onDismissRequest = { isThemeMenuOpen = false }
            ) {
              themes.forEach { (code, label) ->
                DropdownMenuItem(
                  text = { Text(label) },
                  onClick = {
                    onSelectTheme(code)
                    isThemeMenuOpen = false
                  }
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Save recent history switch
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.recent_history_toggle),
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = "Stores document references on device only",
              fontSize = 14.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Switch(
            checked = isRecentHistoryEnabled,
            onCheckedChange = onToggleRecentHistory,
            modifier = Modifier.testTag("save_recent_history_switch")
              .semantics { contentDescription = "Keep local recent history" }
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Clear history button
        OutlinedButton(
          onClick = onClearRecentHistory,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("clear_recent_history_button")
        ) {
          Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(stringResource(R.string.clear_recent_history_button), fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
          onClick = onClearCache,
          enabled = canClearCache && !isClearingCache,
          modifier = Modifier.fillMaxWidth().testTag("clear_document_cache_button")
        ) { Text(if (isClearingCache) "Clearing cached files…" else "Clear Document Cache", fontSize = 14.sp) }
        Text(
          text = if (!canClearCache) "Close all documents to clear temporary copies and sample files."
            else "Removes temporary document copies and samples. Original files and recent history are kept.",
          fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        cacheMessage?.let { Text(it, fontSize = 14.sp, modifier = Modifier.testTag("cache_status")) }

      }
    },
    confirmButton = {
      Button(onClick = onDismiss, modifier = Modifier.testTag("settings_close_button")) {
        Text(stringResource(R.string.close))
      }
    }
  )
}

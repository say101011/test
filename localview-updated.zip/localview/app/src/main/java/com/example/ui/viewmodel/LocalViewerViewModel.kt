package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.RecentDocumentEntity
import com.example.data.UserPreferences
import com.example.model.DocumentContent
import com.example.model.DocumentTab
import com.example.model.DocumentType
import com.example.parser.DocumentParserManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.coroutineContext
import com.example.data.DocumentCache
import java.util.UUID

class LocalViewerViewModel @JvmOverloads constructor(
  application: Application,
  private val documentLoader: suspend (Application, DocumentTab) -> Pair<DocumentType, DocumentContent> = { context, tab ->
    DocumentParserManager.parseDocument(context, tab.uri, tab.displayName,
      preferredEncoding = tab.textEncoding.takeUnless { it == "Auto" },
      csvDelimiter = tab.csvDelimiter, imageRotation = tab.imageRotation)
  },
  private val historyDao: com.example.data.RecentDocumentDao = AppDatabase.getDatabase(application).recentDocumentDao()
) : AndroidViewModel(application) {
  private val loadJobs = mutableMapOf<String, Job>()
  private val pendingJobs = java.util.Collections.synchronizedSet(mutableSetOf<Job>())
  private val _isClearingCache = MutableStateFlow(false)
  val isClearingCache = _isClearingCache.asStateFlow()
  private val _cacheMessage = MutableStateFlow<String?>(null)
  val cacheMessage = _cacheMessage.asStateFlow()

  private val recentDao = historyDao
  private val historyLock = Mutex()
  private var historyGeneration = 0
  private val replacements = mutableMapOf<String, String>()
  val userPrefs = UserPreferences(application)

  val recentDocuments: StateFlow<List<RecentDocumentEntity>> =
    recentDao.getAllRecentDocuments().stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5000),
      emptyList()
    )

  private val _openTabs = MutableStateFlow<List<DocumentTab>>(emptyList())
  val openTabs: StateFlow<List<DocumentTab>> = _openTabs.asStateFlow()

  private val _activeTabIndex = MutableStateFlow(0)
  val activeTabIndex: StateFlow<Int> = _activeTabIndex.asStateFlow()

  private val _isSplitView = MutableStateFlow(false)
  val isSplitView: StateFlow<Boolean> = _isSplitView.asStateFlow()

  private val _splitTabIndex = MutableStateFlow<Int?>(null)
  val splitTabIndex: StateFlow<Int?> = _splitTabIndex.asStateFlow()

  fun openDocument(uri: Uri, forcedName: String? = null, forcedSize: Long = 0L) {
    if (_isClearingCache.value) return
    val context = getApplication<Application>()
    if (uri.scheme == "content") {
      try {
        context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
      } catch (_: SecurityException) { /* Some shared providers grant only temporary access. */ }
    }
    var name = forcedName
    var size = forcedSize

    if (name == null) {
      try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
          if (cursor.moveToFirst()) {
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (nameIndex != -1) name = cursor.getString(nameIndex)
            if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
          }
        }
      } catch (_: Exception) {}
    }

    val finalName = name ?: uri.lastPathSegment ?: "document_${System.currentTimeMillis()}"
    val ext = finalName.substringAfterLast(".", "").lowercase()
    val initialType = DocumentType.fromExtension(ext)

    // Check if already open
    val existingIndex = _openTabs.value.indexOfFirst { it.uri == uri }
    if (existingIndex != -1) {
      _activeTabIndex.value = existingIndex
      return
    }

    val tabId = UUID.randomUUID().toString()
    val newTab = DocumentTab(
      id = tabId,
      uri = uri,
      displayName = finalName,
      fileSizeBytes = size,
      type = initialType,
      isLoading = true
    )

    val updatedList = _openTabs.value + newTab
    _openTabs.value = updatedList
    val newIndex = updatedList.size - 1
    _activeTabIndex.value = newIndex

    reloadDocument(tabId, recordHistory = true)
  }

  private fun reloadDocument(tabId: String, recordHistory: Boolean = false) {
    val tab = _openTabs.value.find { it.id == tabId } ?: return
    loadJobs.remove(tabId)?.cancel()
    updateTab(tabId) { it.copy(isLoading = true) }
    val generation = historyGeneration
    val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
      try {
        val saved = if (recordHistory && userPrefs.isRecentHistoryEnabled.value) historyLock.withLock {
          recentDao.findByUri(replacements[tab.uri.toString()] ?: tab.uri.toString())
        } else null
        val (type, content) = documentLoader(getApplication(), tab)
        coroutineContext.ensureActive()
        updateTab(tabId) {
          val page = (saved?.lastPage ?: it.currentPage).coerceAtLeast(0)
          it.copy(type = type, content = content, isLoading = false,
            currentPage = if (content is com.example.model.PdfDocumentContent) page.coerceAtMost((content.pageCount - 1).coerceAtLeast(0)) else 0,
            zoomLevel = (saved?.lastZoom ?: it.zoomLevel).takeIf { z -> z.isFinite() }?.coerceIn(0.25f, 4f) ?: 1f)
        }
        if (recordHistory && userPrefs.isRecentHistoryEnabled.value &&
          content !is com.example.model.CorruptedDocumentContent &&
          content !is com.example.model.UnsupportedDocumentContent) {
          historyLock.withLock {
            if (generation == historyGeneration && userPrefs.isRecentHistoryEnabled.value) {
              val current = _openTabs.value.find { it.id == tabId } ?: tab
              recentDao.saveVisit(RecentDocumentEntity(
                uriString = tab.uri.toString(), displayName = tab.displayName,
                mimeType = "", extension = tab.displayName.substringAfterLast(".", ""),
                fileSize = tab.fileSizeBytes, lastOpenedTimestamp = System.currentTimeMillis(),
                lastPage = current.currentPage, lastZoom = current.zoomLevel))
              recentDao.updatePosition(tab.uri.toString(), current.currentPage, current.zoomLevel)
              replacements.remove(tab.uri.toString())?.takeIf { it != tab.uri.toString() }?.let { recentDao.deleteByUri(it) }
            }
          }
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        updateTab(tabId) { it.copy(isLoading = false,
          content = com.example.model.CorruptedDocumentContent(e.message ?: "Unable to open document.")) }
      } finally {
        if (loadJobs[tabId] == coroutineContext[Job]) loadJobs.remove(tabId)
      }
    }
    loadJobs[tabId] = job
    pendingJobs.add(job)
    job.invokeOnCompletion { pendingJobs.remove(job) }
    job.start()
  }

  fun closeTab(index: Int) {
    val current = _openTabs.value.toMutableList()
    if (index in current.indices) {
      persistPosition(current[index])
      loadJobs.remove(current[index].id)?.cancel()
      val activeId = current.getOrNull(_activeTabIndex.value)?.id
      val splitId = _splitTabIndex.value?.let { current.getOrNull(it)?.id }
      current.removeAt(index)
      _openTabs.value = current
      if (current.isEmpty()) {
        _activeTabIndex.value = 0
        _isSplitView.value = false
        _splitTabIndex.value = null
      } else {
        _activeTabIndex.value = current.indexOfFirst { it.id == activeId }
          .takeIf { it >= 0 } ?: index.coerceAtMost(current.lastIndex)
        _splitTabIndex.value = current.indexOfFirst { it.id == splitId }
          .takeIf { it >= 0 && it != _activeTabIndex.value }
        if (_splitTabIndex.value == null) _isSplitView.value = false
      }
    }
  }

  fun selectTab(index: Int) {
    if (index in _openTabs.value.indices) {
      if (_isSplitView.value && _splitTabIndex.value == index) {
        _splitTabIndex.value = _activeTabIndex.value
      }
      _activeTabIndex.value = index
    }
  }

  fun toggleSplitView() {
    val current = _isSplitView.value
    if (!current && _openTabs.value.size >= 2) {
      _isSplitView.value = true
      _splitTabIndex.value = if (_activeTabIndex.value == 0) 1 else 0
    } else {
      _isSplitView.value = false
      _splitTabIndex.value = null
    }
  }

  fun selectSplitTab(index: Int) {
    if (index in _openTabs.value.indices) {
      _splitTabIndex.value = index
    }
  }

  fun zoomIn(tabId: String) {
    updateTab(tabId) { tab ->
      val newZoom = (tab.zoomLevel + 0.25f).coerceAtMost(4.0f)
      tab.copy(zoomLevel = newZoom)
    }
    _openTabs.value.find { it.id == tabId }?.let(::persistPosition)
  }

  fun zoomOut(tabId: String) {
    updateTab(tabId) { tab ->
      val newZoom = (tab.zoomLevel - 0.25f).coerceAtLeast(0.25f)
      tab.copy(zoomLevel = newZoom)
    }
    _openTabs.value.find { it.id == tabId }?.let(::persistPosition)
  }

  fun setZoom(tabId: String, zoom: Float) {
    updateTab(tabId) { tab ->
      tab.copy(zoomLevel = zoom.coerceIn(0.25f, 4.0f))
    }
    _openTabs.value.find { it.id == tabId }?.let(::persistPosition)
  }

  fun setPage(tabId: String, page: Int) {
    updateTab(tabId) { tab ->
      tab.copy(currentPage = page.coerceAtLeast(0))
    }
    _openTabs.value.find { it.id == tabId }?.let(::persistPosition)
  }

  fun setActiveSheet(tabId: String, sheetIndex: Int) {
    updateTab(tabId) { tab ->
      tab.copy(activeSheetIndex = sheetIndex.coerceAtLeast(0))
    }
  }

  fun setMarkdownRendered(tabId: String, rendered: Boolean) {
    updateTab(tabId) { tab ->
      tab.copy(isMarkdownRendered = rendered)
    }
  }

  fun toggleWordWrap(tabId: String) {
    updateTab(tabId) { tab ->
      tab.copy(isWordWrap = !tab.isWordWrap)
    }
  }

  fun setFontSize(tabId: String, sizeSp: Float) {
    updateTab(tabId) { tab ->
      tab.copy(fontSizeSp = sizeSp.coerceIn(10f, 32f))
    }
  }

  fun setTextEncoding(tabId: String, encoding: String) {
    updateTab(tabId) { it.copy(textEncoding = encoding) }
    reloadDocument(tabId)
  }

  fun setCsvDelimiter(tabId: String, delimiter: Char) {
    updateTab(tabId) { it.copy(csvDelimiter = delimiter) }
    reloadDocument(tabId)
  }

  fun rotateImage(tabId: String) {
    updateTab(tabId) { it.copy(imageRotation = (it.imageRotation + 90) % 360) }
    reloadDocument(tabId)
  }

  fun clearDocumentCache() {
    if (_isClearingCache.value) return
    if (_openTabs.value.isNotEmpty()) {
      _cacheMessage.value = "Close all documents before clearing cached files."
      return
    }
    _isClearingCache.value = true
    _cacheMessage.value = null
    viewModelScope.launch {
      try {
        val jobs = synchronized(pendingJobs) { pendingJobs.toList() }
        jobs.joinAll()
        val count = withContext(Dispatchers.IO) { DocumentCache.clear(getApplication<Application>().cacheDir) }
        _cacheMessage.value = "Cleared $count cached files. Your original documents are unchanged."
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _cacheMessage.value = e.message ?: "Unable to clear cached files. Please try again."
      } finally {
        _isClearingCache.value = false
      }
    }
  }

  fun applyOcrResult(tabId: String, page: Int, result: com.example.model.PdfPageText) {
    updateTab(tabId) { tab ->
      val pdf = tab.content as? com.example.model.PdfDocumentContent ?: return@updateTab tab
      if(page !in 0 until pdf.pageCount || result.text.isBlank()) return@updateTab tab
      val texts = MutableList(pdf.pageCount) { pdf.pageTextList.getOrElse(it) { "" } }
      val geometry = MutableList(pdf.pageCount) { pdf.pageGeometry.getOrElse(it) { com.example.model.PdfPageText(texts[it],emptyList()) } }
      require(texts.sumOf { it.length } - texts[page].length + result.text.length <= 4_000_000) { "The document text limit has been reached." }
      require(geometry.sumOf { it.boxes.size } - geometry[page].boxes.size + result.boxes.size <= 200_000) { "The document highlight limit has been reached." }
      texts[page] = result.text; geometry[page] = result
      tab.copy(content = pdf.copy(pageTextList = texts, pageGeometry = geometry), searchMatchCount =
        if(tab.searchQuery.isBlank()) 0 else texts.sumOf { countMatches(it,tab.searchQuery) })
    }
  }

  fun setSearchQuery(tabId: String, query: String) {
    updateTab(tabId) { tab ->
      var matches = 0
      if (query.isNotBlank()) {
        when (val c = tab.content) {
          is com.example.model.PlainTextDocumentContent -> {
            matches = countMatches(c.text, query)
          }
          is com.example.model.MarkdownDocumentContent -> {
            matches = countMatches(c.rawText, query)
          }
          is com.example.model.PdfDocumentContent -> {
            matches = c.pageTextList.sumOf { pageText ->
              if (pageText.isNotBlank()) countMatches(pageText, query)
              else 0
            }
          }
          is com.example.model.StructuredTextDocumentContent -> {
            matches = c.blocks.sumOf { b ->
              when (b) {
                is com.example.model.DocBlock.Paragraph -> countMatches(b.text, query)
                is com.example.model.DocBlock.Heading -> countMatches(b.text, query)
                is com.example.model.DocBlock.Table -> (b.headers + b.rows.flatten()).sumOf { countMatches(it,query) }
                else -> 0
              }
            }
          }
          else -> {}
        }
      }
      tab.copy(searchQuery = query, searchMatchCount = matches)
    }
  }

  private fun countMatches(text: String, query: String): Int {
    if (query.isEmpty()) return 0
    var count = 0
    var start = 0
    while (start <= text.length - query.length) {
      val index = text.indexOf(query, start, ignoreCase = true)
      if (index < 0) break
      count++
      start = index + 1
    }
    return count
  }

  fun clearRecentHistory() {
    historyGeneration++
    viewModelScope.launch {
      historyLock.withLock { recentDao.clearAll() }
    }
  }

  fun setRecentHistoryEnabled(enabled: Boolean) {
    historyGeneration++
    userPrefs.setRecentHistoryEnabled(enabled)
  }

  fun loadSampleFile(sampleType: String) {
    if (_isClearingCache.value) return
    val context = getApplication<Application>()
    val (uri, name) = DocumentParserManager.createSampleFile(context, sampleType)
    openDocument(uri, name)
  }

  private fun persistPosition(tab: DocumentTab) {
    if (!userPrefs.isRecentHistoryEnabled.value || tab.isLoading) return
    val generation = historyGeneration
    viewModelScope.launch {
      historyLock.withLock {
        if (generation == historyGeneration && userPrefs.isRecentHistoryEnabled.value)
          recentDao.updatePosition(tab.uri.toString(), tab.currentPage, tab.zoomLevel)
      }
    }
  }

  fun removeRecent(uri: String) {
    historyGeneration++
    viewModelScope.launch { historyLock.withLock { recentDao.deleteByUri(uri) } }
  }

  fun reselectDocument(oldUri: String, newUri: Uri) {
    replacements[newUri.toString()] = oldUri
    val oldIndex = _openTabs.value.indexOfFirst { it.uri.toString() == oldUri }
    if (oldIndex >= 0) closeTab(oldIndex)
    val existing = _openTabs.value.find { it.uri == newUri }
    if (existing != null) reloadDocument(existing.id, recordHistory = true) else openDocument(newUri)
  }

  private fun updateTab(tabId: String, transform: (DocumentTab) -> DocumentTab) {
    _openTabs.value = _openTabs.value.map {
      if (it.id == tabId) transform(it) else it
    }
  }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Calm Blue & Slate Palette
val BluePrimary = Color(0xFF2563EB)
val BlueOnPrimary = Color(0xFFFFFFFF)
val BluePrimaryContainer = Color(0xFFDBEAFE)
val BlueOnPrimaryContainer = Color(0xFF1E3A8A)

val BlueSecondary = Color(0xFF475569)
val BlueOnSecondary = Color(0xFFFFFFFF)
val BlueSecondaryContainer = Color(0xFFF1F5F9)
val BlueOnSecondaryContainer = Color(0xFF0F172A)

val BlueTertiary = Color(0xFF0284C7)
val BlueOnTertiary = Color(0xFFFFFFFF)
val BlueTertiaryContainer = Color(0xFFE0F2FE)
val BlueOnTertiaryContainer = Color(0xFF0369A1)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val BluePrimaryDark = Color(0xFF93C5FD)
val BlueOnPrimaryDark = Color(0xFF1E3A8A)
val BluePrimaryContainerDark = Color(0xFF1D4ED8)
val BlueOnPrimaryContainerDark = Color(0xFFDBEAFE)

val BlueSecondaryDark = Color(0xFF94A3B8)
val BlueOnSecondaryDark = Color(0xFF0F172A)
val BlueSecondaryContainerDark = Color(0xFF334155)
val BlueOnSecondaryContainerDark = Color(0xFFF1F5F9)

val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceVariantDark = Color(0xFF1E293B)
val OutlineDark = Color(0xFF475569)

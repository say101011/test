package com.example.parser

import android.content.Context
import android.net.Uri
import com.example.model.*
import org.w3c.dom.Element
import com.example.parser.OfficeXml.attr
import com.example.parser.OfficeXml.children
import com.example.parser.OfficeXml.name

object HwpxDocumentParser {
  fun parse(context: Context, uri: Uri): DocumentContent = try {
    val parts=OfficeXml.parts(context,uri)
    val sections=parts.keys.filter { it.matches(Regex("(?i)Contents/section[0-9]+\\.xml")) }.sortedBy { it.substringAfterLast('/').filter(Char::isDigit).toInt() }
    require(sections.isNotEmpty()) { "No HWPX body sections." }
    val blocks=mutableListOf<DocBlock>()
    fun plain(element: Element): String = buildString {
      fun walk(e: Element, depth: Int) {
        require(depth<128)
        when(name(e)) {
          "t" -> append(e.textContent)
          "lineBreak" -> append('\n')
          "tab" -> append('\t')
          else -> { children(e).forEach { walk(it,depth+1) }; if(name(e)=="p") append('\n') }
        }
      }
      walk(element,0)
    }.trimEnd('\n')
    fun table(e: Element) {
      val cells=linkedMapOf<Pair<Int,Int>,String>();var maxR=0;var maxC=0
      children(e).filter { name(it)=="tr" }.forEachIndexed { r,row ->
        var nextColumn=0
        children(row).filter { name(it)=="tc" }.forEach { cell ->
          val addr=children(cell).firstOrNull { name(it)=="cellAddr" }
          val span=children(cell).firstOrNull { name(it)=="cellSpan" }
          val rr=addr?.let { attr(it,"rowAddr").toIntOrNull() } ?: r
          val cc=addr?.let { attr(it,"colAddr").toIntOrNull() } ?: nextColumn
          val width=span?.let { attr(it,"colSpan").toIntOrNull() }?.coerceAtLeast(1) ?: 1
          require(rr in 0..999 && cc in 0..99 && width<=100) { "HWPX table exceeds preview limits." }
          cells[rr to cc]=plain(cell);maxR=maxOf(maxR,rr);maxC=maxOf(maxC,cc+width-1);nextColumn=cc+width
        }
      }
      blocks.add(DocBlock.Table(emptyList(),(0..maxR).map { r -> (0..maxC).map { c -> cells[r to c].orEmpty() } }))
    }
    fun read(e: Element, depth: Int) {
      DocumentIo.checkCancelled();require(depth<128)
      if(name(e)=="tbl") { table(e);return }
      if(name(e)=="p") {
        val text=StringBuilder()
        fun flush() { if(text.isNotEmpty()) { blocks.add(DocBlock.Paragraph(text.toString()));text.clear() } }
        fun run(node: Element, nesting: Int) {
          require(nesting<128)
          when(name(node)) {
            "tbl" -> { flush();table(node) }
            "t" -> text.append(node.textContent)
            "lineBreak" -> text.append('\n')
            "tab" -> text.append('\t')
            else -> children(node).forEach { run(it,nesting+1) }
          }
        }
        children(e).forEach { run(it,0) };flush()
      } else children(e).forEach { read(it,depth+1) }
    }
    sections.forEach { read(OfficeXml.parse(parts.getValue(it)),0) }
    StructuredTextDocumentContent(DocumentType.HWPX,blocks,true,"HWPX sections are shown in numeric order. Cell coordinates and paragraph breaks are preserved. Merged table cells, images, headers and print layout remain simplified.")
  } catch(e: java.util.concurrent.CancellationException) { throw e }
  catch(e: Exception) { CorruptedDocumentContent("Unable to read HWPX: ${e.message}") }
}


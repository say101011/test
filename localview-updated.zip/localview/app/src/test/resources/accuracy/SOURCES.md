# Regression document fixtures

- SampleDoc.doc and SampleDoc.txt: https://github.com/apache/poi/tree/trunk/test-data/document
- SimpleMultiCell.xls, SimpleMultiCell.xlsx and StringContinueRecords.xls and StringFormulas.xls: https://github.com/apache/poi/tree/trunk/test-data/spreadsheet
- changing-paragraph-text.hwp and merging-cell.hwp: https://github.com/neolord0/hwplib/tree/main/sample_hwp

Downloaded 2026-09-23. Fixtures are unmodified. Apache POI license and notice are in POI-LICENSE.txt and POI-NOTICE.txt; hwplib license is in HWPLIB-LICENSE.txt. These files are for unit tests only and are not included in application assets.

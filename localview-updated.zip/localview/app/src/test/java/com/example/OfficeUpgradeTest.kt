package com.example

import android.app.Application
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.model.*
import com.example.parser.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.*
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class OfficeUpgradeTest {
  private val app:Application get()=ApplicationProvider.getApplicationContext()
  private fun zip(parts:Map<String,String>):Uri {
    val f=File.createTempFile("office-test-",".zip",app.cacheDir)
    ZipOutputStream(f.outputStream()).use { out -> parts.forEach { (path,text) -> out.putNextEntry(ZipEntry(path));out.write(text.toByteArray());out.closeEntry() } }
    return Uri.fromFile(f)
  }
  private fun fixture(name:String):Uri {
    val f=File(app.cacheDir,name)
    javaClass.getResourceAsStream("/accuracy/$name")!!.use { i -> f.outputStream().use { i.copyTo(it) } }
    return Uri.fromFile(f)
  }
  @Test fun overlappingMergedRangesAreRejected() {
    try { SpreadsheetLayout.coveredCells(listOf(MergedRegion(0,0,1,1),MergedRegion(1,1,2,2)),3,3);fail("Overlapping merge accepted") }
    catch(_:IllegalArgumentException) { }
  }
  @Test fun positionedSearchDoesNotChangeOffsetsForUnicodeCaseFolding() {
    val page=PdfPageText("İ zebra",listOf(PdfTextBox(2,7,0f,0f,1f,1f)))
    assertEquals(1,page.matches("ZEBRA").size)
    assertEquals(0,page.matches("missing").size)
  }
  @Test fun docxKeepsRunStylesCellParagraphsAndReferencedHeader() {
    val result=WordDocumentParser.parse(app,zip(mapOf(
      "word/document.xml" to """<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Bold</w:t></w:r><w:r><w:t> normal</w:t><w:tab/><w:t>end</w:t><w:br/><w:t>next</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Line one</w:t></w:r></w:p><w:p><w:r><w:t>Line two</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:sectPr><w:headerReference r:id="head1"/></w:sectPr></w:body></w:document>""",
      "word/_rels/document.xml.rels" to """<Relationships><Relationship Id="head1" Target="headers/custom.xml"/></Relationships>""",
      "word/headers/custom.xml" to """<hdr><p><r><t>Header text</t></r></p></hdr>"""
    )),false)
    assertTrue(result.toString(),result is StructuredTextDocumentContent)
    val blocks=(result as StructuredTextDocumentContent).blocks
    val p=blocks.filterIsInstance<DocBlock.Paragraph>().first { it.text.startsWith("Bold") }
    assertEquals("Bold normal\tend\nnext",p.text)
    assertEquals(TextStyleRange(0,4,true,false),p.styles.single())
    assertEquals("Header text",(blocks[1] as DocBlock.Paragraph).text)
    val table=blocks.filterIsInstance<DocBlock.Table>().single()
    assertTrue(table.headers.isEmpty());assertEquals("Line one\nLine two",table.rows[0][0])
  }
  @Test fun docxRejectsDoctypeWithoutLoadingEntities() {
    val result=WordDocumentParser.parse(app,zip(mapOf("word/document.xml" to """<!DOCTYPE doc [<!ENTITY leak SYSTEM "file:///private/secret">]><document><body><p><t>&leak;</t></p></body></document>""")),false)
    assertTrue(result.toString(),result is CorruptedDocumentContent)
  }
  @Test fun hwpxOrdersSectionsNumericallyAndRetainsTableCoordinates() {
    val result=HwpxDocumentParser.parse(app,zip(linkedMapOf(
      "Contents/section10.xml" to "<sec><p><run><t>last</t></run></p></sec>",
      "Contents/section2.xml" to "<sec><p><run><t>first</t><tbl><tr><tc><cellAddr rowAddr=\"0\" colAddr=\"1\"/><subList><p><run><t>A</t></run></p><p><run><t>B</t></run></p></subList></tc></tr></tbl><t>after</t></run></p></sec>"
    )))
    assertTrue(result.toString(),result is StructuredTextDocumentContent)
    val blocks=(result as StructuredTextDocumentContent).blocks
    assertEquals("first",(blocks[0] as DocBlock.Paragraph).text)
    assertEquals(listOf("","A\nB"),(blocks[1] as DocBlock.Table).rows.single())
    assertEquals("last",(blocks.last() as DocBlock.Paragraph).text)
  }
  @Test fun realHwpTableHasNonemptyCells() {
    val result=LegacyDocuments.hwp(app,fixture("merging-cell.hwp"))
    assertTrue(result.toString(),result is StructuredTextDocumentContent)
    val tables=(result as StructuredTextDocumentContent).blocks.filterIsInstance<DocBlock.Table>()
    assertTrue(result.toString(),tables.isNotEmpty())
    assertTrue(tables.toString(),tables.any { t->t.rows.flatten().any(String::isNotBlank) })
  }
  @Test fun xlsCachedTextFormulasAreRead() {
    val result=LegacyXls.parse(app,fixture("StringFormulas.xls"))
    assertTrue(result.toString(),result is SpreadsheetDocumentContent)
    val values=(result as SpreadsheetDocumentContent).sheets.flatMap { it.rows.flatten() }.map { it.value }
    assertFalse(values.toString(),values.any { it.contains("Missing cached text") })
    assertTrue(values.any { it.isNotBlank() })
  }
  @Test fun customExcelFormatsSupportCurrencyNegativeSectionsAndElapsedHours() {
    assertEquals("$1,234.50",SpreadsheetValues.format("1234.5",164,custom="\"$\"#,##0.00"))
    assertEquals("(12.50)",SpreadsheetValues.format("-12.5",164,custom="0.00;[Red](0.00)"))
    assertEquals("12.5%",SpreadsheetValues.format("0.125",164,custom="0.0%"))
    assertEquals("00042",SpreadsheetValues.format("42",164,custom="00000"))
    assertEquals("36:00:00",SpreadsheetValues.format("1.5",164,custom="[h]:mm:ss"))
  }
  @Test fun xlsxMergedRangeAndChartRelationshipsUseCachedSeriesValues() {
    val result=XlsxParser.parse(app,zip(mapOf(
      "xl/workbook.xml" to """<workbook xmlns:r="urn:r"><sheets><sheet name="Data" r:id="sheet"/></sheets></workbook>""",
      "xl/_rels/workbook.xml.rels" to """<Relationships><Relationship Id="sheet" Type="urn:test/worksheet" Target="worksheets/custom.xml"/></Relationships>""",
      "xl/worksheets/custom.xml" to """<worksheet xmlns:r="urn:r"><sheetData><row><c r="A1" t="inlineStr"><is><t>Merged</t></is></c></row></sheetData><mergeCells><mergeCell ref="A1:C2"/></mergeCells><drawing r:id="drawing"/></worksheet>""",
      "xl/worksheets/_rels/custom.xml.rels" to """<Relationships><Relationship Id="drawing" Target="../drawings/one.xml"/></Relationships>""",
      "xl/drawings/one.xml" to """<drawing xmlns:r="urn:r"><chart r:id="chart"/></drawing>""",
      "xl/drawings/_rels/one.xml.rels" to """<Relationships><Relationship Id="chart" Target="../charts/two.xml"/></Relationships>""",
      "xl/charts/two.xml" to """<chart><title><t>Sales</t></title><ser><tx><v>Revenue</v></tx><cat><strCache><pt idx="0"><v>January</v></pt></strCache></cat><val><numCache><pt idx="0"><v>42</v></pt></numCache></val></ser></chart>"""
    )))
    assertTrue(result.toString(),result is SpreadsheetDocumentContent)
    val sheet=(result as SpreadsheetDocumentContent).sheets.single()
    assertEquals(MergedRegion(0,0,1,2),sheet.mergedRegions.single())
    assertEquals(2,sheet.maxRows);assertEquals(3,sheet.maxCols)
    assertEquals(listOf("Revenue","January","42"),sheet.charts.single().rows[1])
  }
  @Test fun pdfSearchGeometryTracksRotatedPageAndOnlyMatchingCharacters() {
    PDFBoxResourceLoader.init(app)
    val f=File(app.cacheDir,"geometry.pdf")
    PDDocument().use { doc ->
      for(rotation in listOf(0,90,180,270)) {
        val page=PDPage(PDRectangle(200f,300f));page.rotation=rotation;doc.addPage(page)
        PDPageContentStream(doc,page).use { s -> s.beginText();s.setFont(PDType1Font.HELVETICA,12f);s.newLineAtOffset(30f,200f);s.showText("alpha zebra");s.endText() }
      };doc.save(f)
    }
    val index=PdfTextIndex.read(app,f,4)
    assertEquals(4,index.geometry.size)
    index.geometry.forEach { page ->
      assertTrue(page.text,page.text.contains("alpha zebra"))
      val boxes=page.matches("zebra");assertEquals(5,boxes.size)
      assertTrue(boxes.all { it.left>=0 && it.right<=1 && it.top>=0 && it.bottom<=1 && it.right>it.left && it.bottom>it.top })
      assertTrue(boxes.all { page.text.substring(it.start,it.end).all { c->c in "zebra" } })
    }
    assertTrue(index.geometry[0].matches("alpha").first().left in 0.14f..0.16f)
    assertTrue(index.geometry[1].matches("alpha").first().top in 0.14f..0.16f)
  }
}

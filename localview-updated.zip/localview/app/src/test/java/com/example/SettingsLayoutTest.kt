package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.v2.createComposeRule
import com.example.ui.components.SettingsDialog
import com.example.ui.theme.LocalViewTheme
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.assertTrue
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(qualifiers = "w320dp-h640dp-mdpi", sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SettingsLayoutTest {
  @get:Rule val compose = createComposeRule()
  @Test fun cacheControlRemainsReachableWithLargeTextOnSmallScreen() {
    var cleared = false
    compose.setContent {
      CompositionLocalProvider(LocalDensity provides Density(1f, 1.3f)) {
        LocalViewTheme {
          SettingsDialog(true, "system", {}, {}, {}, {},
            onClearCache = { cleared = true }, canClearCache = true)
        }
      }
    }
    compose.onNodeWithTag("clear_document_cache_button").performScrollTo().assertIsDisplayed().performClick()
    compose.runOnIdle { assertTrue(cleared) }
    compose.onNode(isDialog()).captureRoboImage(filePath = "build/reports/settings-compact.png")
  }
  @Test fun cacheControlIsDisabledWhileDocumentsAreOpen() {
    compose.setContent {
      LocalViewTheme { SettingsDialog(true, "system", {}, {}, {}, {}, canClearCache = false) }
    }
    compose.onNodeWithTag("clear_document_cache_button").performScrollTo().assertIsNotEnabled()
  }
}

package com.example

import android.app.Application
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.model.*
import com.example.parser.*
import com.example.data.*
import androidx.room.Room
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.*
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DocumentAccuracyTest {
  private val app: Application get() = ApplicationProvider.getApplicationContext()
  private fun fixture(name: String): Uri {
    val file = File(app.cacheDir, name)
    javaClass.getResourceAsStream("/accuracy/$name")!!.use { input -> file.outputStream().use { input.copyTo(it) } }
    return Uri.fromFile(file)
  }
  @Test fun excelDatesPercentagesAndColumnNamesAreStable() {
    assertEquals("1900-01-01", SpreadsheetValues.format("1",14))
    assertEquals("1900-03-01", SpreadsheetValues.format("61",14))
    assertEquals("1904-01-01", SpreadsheetValues.format("0",14,true))
    assertEquals("12.50%", SpreadsheetValues.format("0.125",10))
    assertEquals("AA", SpreadsheetValues.column(26))
    assertEquals("CV", SpreadsheetValues.column(99))
  }
  @Test fun historyMigrationKeepsNewestVisitAndEnforcesUniqueUri() {
    val helper = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
      androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(app).callback(object:androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(1) {
        override fun onCreate(db:androidx.sqlite.db.SupportSQLiteDatabase) {
          db.execSQL("CREATE TABLE recent_documents (id INTEGER PRIMARY KEY, uriString TEXT NOT NULL, lastOpenedTimestamp INTEGER NOT NULL, lastPage INTEGER NOT NULL)")
        }
        override fun onUpgrade(db:androidx.sqlite.db.SupportSQLiteDatabase,oldVersion:Int,newVersion:Int) {}
      }).build())
    try {
      val db=helper.writableDatabase
      db.execSQL("INSERT INTO recent_documents VALUES (1,'same',10,2),(2,'same',20,4),(3,'other',10,1)")
      AppDatabase.MIGRATION_1_2.migrate(db)
      db.query("SELECT id,lastPage FROM recent_documents WHERE uriString='same'").use { cursor ->
        assertEquals(1,cursor.count); assertTrue(cursor.moveToFirst()); assertEquals(2,cursor.getInt(0)); assertEquals(4,cursor.getInt(1))
      }
      try { db.execSQL("INSERT INTO recent_documents VALUES (4,'same',30,0)"); fail("Duplicate URI accepted") }
      catch(_:android.database.sqlite.SQLiteConstraintException) { }
    } finally { helper.close() }
  }
  @Test fun legacyWordReadsBodyFromPieceTable() {
    val result = LegacyDocuments.doc(app, fixture("SampleDoc.doc"))
    assertTrue(result.toString(), result is StructuredTextDocumentContent)
    val text = (result as StructuredTextDocumentContent).blocks.filterIsInstance<DocBlock.Paragraph>().joinToString("\n") { it.text }
    assertTrue(text, text.contains("I am a test document"))
    assertTrue(text, text.contains("This is page two"))
    assertFalse(text.contains("Author = Nick Burch"))
  }
  @Test fun compressedHwpReadsRealBodySections() {
    val result = LegacyDocuments.hwp(app, fixture("changing-paragraph-text.hwp"))
    assertTrue(result.toString(), result is StructuredTextDocumentContent)
    assertTrue((result as StructuredTextDocumentContent).blocks.filterIsInstance<DocBlock.Paragraph>().any { it.text.isNotBlank() })
  }
  @Test fun binaryAndXmlSpreadsheetHaveSameCoordinatesAndValues() {
    val old = LegacyXls.parse(app, fixture("SimpleMultiCell.xls"))
    val modern = XlsxParser.parse(app, fixture("SimpleMultiCell.xlsx"))
    assertTrue(old.toString(), old is SpreadsheetDocumentContent)
    assertTrue(modern.toString(), modern is SpreadsheetDocumentContent)
    fun cells(doc: DocumentContent) = (doc as SpreadsheetDocumentContent).sheets.map { sheet ->
      sheet.rows.flatten().filter { it.value.isNotEmpty() }.map { Triple(it.row, it.col, it.value.toBigDecimalOrNull()?.stripTrailingZeros()?.toPlainString() ?: it.value) }
    }
    assertEquals(cells(modern), cells(old))
    assertTrue(cells(old).flatten().isNotEmpty())
  }
  @Test fun continuedBiffStringsRemainReadable() {
    val result = LegacyXls.parse(app, fixture("StringContinueRecords.xls"))
    assertTrue(result.toString(), result is SpreadsheetDocumentContent)
    assertTrue((result as SpreadsheetDocumentContent).sheets.flatMap { it.rows.flatten() }.any { it.value.length > 1000 })
  }
  @Test fun xlsxResolvesRelationshipAndShowsMissingFormulaAndClipping() {
    val file = File(app.cacheDir, "relationships.xlsx")
    val parts = mapOf(
      "xl/workbook.xml" to """<workbook xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Correct sheet" r:id="rId9"/></sheets></workbook>""",
      "xl/_rels/workbook.xml.rels" to """<Relationships><Relationship Id="rId9" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/custom.xml"/></Relationships>""",
      "xl/worksheets/custom.xml" to """<worksheet><sheetData><row r="2"><c r="B2" t="inlineStr"><is><t>Hello 世界</t></is></c><c r="C2"><f>1+1</f></c></row><row r="1001"><c r="A1001"><v>99</v></c></row></sheetData></worksheet>"""
    )
    ZipOutputStream(file.outputStream()).use { zip -> parts.forEach { (name, body) -> zip.putNextEntry(ZipEntry(name)); zip.write(body.toByteArray()); zip.closeEntry() } }
    val result = XlsxParser.parse(app, Uri.fromFile(file))
    assertTrue(result.toString(), result is SpreadsheetDocumentContent)
    val sheet = (result as SpreadsheetDocumentContent).sheets.single()
    assertEquals("Correct sheet", sheet.name)
    assertEquals("Hello 世界", sheet.rows[1][1].value)
    assertTrue(sheet.rows[1][2].value.isNotBlank())
    assertNotNull(sheet.noticeMessage)
    assertTrue(sheet.maxRows <= 1000)
  }
  @Test fun pdfSearchUsesActualPageBoundariesAndReportsBlankPages() {
    PDFBoxResourceLoader.init(app)
    val file = File(app.cacheDir, "search.pdf")
    PDDocument().use { doc ->
      for(text in listOf("First page alpha", "Second page zebra", "")) {
        val page = PDPage(); doc.addPage(page)
        if(text.isNotEmpty()) PDPageContentStream(doc, page, PDPageContentStream.AppendMode.OVERWRITE, true).use { stream ->
          stream.beginText(); stream.setFont(PDType1Font.HELVETICA, 12f); stream.newLineAtOffset(30f, 700f); stream.showText(text); stream.endText()
        }
      }
      doc.save(file)
    }
    val result = PdfTextIndex.read(app, file, 3)
    assertTrue(result.pages[0], result.pages[0].contains("alpha"))
    assertFalse(result.pages[0].contains("zebra"))
    assertTrue(result.pages[1].contains("zebra"))
    assertTrue(result.pages[2].isBlank())
    assertTrue(result.notice.orEmpty().contains("OCR"))
  }
  @Test fun revisitingPreservesPositionAndRemovalDoesNotDeleteOriginal() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(app, AppDatabase::class.java).allowMainThreadQueries().build()
    try {
      val dao = db.recentDocumentDao()
      val file = File(app.cacheDir, "keep.txt").apply { writeText("original") }
      val entry = RecentDocumentEntity(uriString=Uri.fromFile(file).toString(), displayName="keep.txt", mimeType="text/plain", extension="txt", fileSize=8, lastOpenedTimestamp=1)
      dao.saveVisit(entry); dao.updatePosition(entry.uriString, 4, 1.75f)
      dao.saveVisit(entry.copy(lastOpenedTimestamp=2))
      assertEquals(4, dao.findByUri(entry.uriString)!!.lastPage)
      assertEquals(1.75f, dao.findByUri(entry.uriString)!!.lastZoom)
      dao.deleteByUri(entry.uriString)
      assertNull(dao.findByUri(entry.uriString)); assertEquals("original", file.readText())
    } finally { db.close() }
  }
}

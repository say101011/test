package com.example

import android.app.Application
import android.net.Uri
import androidx.lifecycle.ViewModelStore
import androidx.test.core.app.ApplicationProvider
import com.example.model.*
import com.example.parser.DocumentParserManager
import com.example.parser.TextCsvDocumentParser
import com.example.ui.viewmodel.LocalViewerViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DocumentLoadingTest {
  private val dispatcher = StandardTestDispatcher()
  private val store = ViewModelStore()
  private val app: Application get() = ApplicationProvider.getApplicationContext()
  @Before fun setup() { Dispatchers.setMain(dispatcher) }
  @After fun cleanup() { store.clear(); Dispatchers.resetMain() }
  private fun viewer(loader: suspend (Application, DocumentTab) -> Pair<DocumentType, DocumentContent>) =
    LocalViewerViewModel(app, loader).also { store.put("test", it); it.userPrefs.setRecentHistoryEnabled(false) }
  private fun result(value: String): Pair<DocumentType, DocumentContent> =
    DocumentType.TEXT to PlainTextDocumentContent(value, listOf(value), "UTF-8")

  @Test fun closingTabCancelsItsLoad() = runTest(dispatcher) {
    var cancelled = false
    val vm = viewer { _, _ -> try { awaitCancellation() } finally { cancelled = true } }
    vm.openDocument(Uri.parse("file:///a.txt"), "a.txt")
    runCurrent()
    vm.closeTab(0)
    runCurrent()
    assertTrue(cancelled)
    assertTrue(vm.openTabs.value.isEmpty())
  }
  @Test fun oldResultCannotReplaceLatestSettings() = runTest(dispatcher) {
    var call = 0
    val vm = viewer { _, tab ->
      if (++call == 1) withContext(NonCancellable) { delay(1000) }
      result(tab.textEncoding + tab.csvDelimiter)
    }
    vm.openDocument(Uri.parse("file:///a.csv"), "a.csv")
    runCurrent()
    val id = vm.openTabs.value.single().id
    vm.setTextEncoding(id, "CP949")
    vm.setCsvDelimiter(id, ';')
    advanceUntilIdle()
    val tab = vm.openTabs.value.single()
    assertEquals("CP949;", (tab.content as PlainTextDocumentContent).text)
    assertFalse(tab.isLoading)
  }
  @Test fun cacheDeletionIsBlockedWhileDocumentsAreOpen() = runTest(dispatcher) {
    val vm = viewer { _, _ -> awaitCancellation() }
    vm.openDocument(Uri.parse("file:///a.txt"), "a.txt")
    vm.clearDocumentCache()
    assertFalse(vm.isClearingCache.value)
    assertTrue(vm.cacheMessage.value!!.contains("Close all documents"))
    vm.closeTab(0)
    runCurrent()
  }
  @Test fun generatedCsvHasSixColumnsIncludingCurrencyValues() {
    val (uri, _) = DocumentParserManager.createSampleFile(app, "csv")
    val text = app.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
    val rows = TextCsvDocumentParser.parseCsv(text, ',').sheets.single().rows
    assertEquals(6, rows.size)
    assertTrue(rows.all { it.size == 6 })
    assertEquals("$1,250,000", rows[1][2].value)
  }
}

package com.example

import com.example.model.*
import com.example.parser.OfficeXml
import com.example.parser.XlsxCharts
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class ChartPreviewTest {
  private fun series(values:String="<pt idx='0'><v>-12</v></pt><pt idx='2'><v>24</v></pt>",label:String="January")="""<ser><tx><v>Revenue</v></tx><cat><strCache><pt idx="0"><v>$label</v></pt></strCache></cat><val><numCache>$values</numCache></val></ser>"""
  private fun chart(type:String="barChart",options:String="<barDir val='col'/><grouping val='clustered'/>",data:String=series(),extra:String="") = XlsxCharts.preview(OfficeXml.parse("<chart><plotArea><$type>$options$data</$type>$extra</plotArea></chart>".toByteArray()))
  @Test fun columnsKeepNegativeValuesAndMissingPointPositions() {
    val result=chart()!!
    assertEquals(ChartKind.COLUMN,result.kind)
    assertEquals(listOf("January","2","3"),result.categories)
    assertEquals(listOf(-12.0,null,24.0),result.series.single().values)
  }
  @Test fun horizontalAndLineTypesRemainDistinct() {
    assertEquals(ChartKind.BAR,chart(options="<barDir val='bar'/>")!!.kind)
    assertEquals(ChartKind.LINE,chart(type="lineChart",options="")!!.kind)
  }
  @Test fun stackedComboLogAndUnsupportedChartsUseTableFallback() {
    assertNull(chart(options="<grouping val='stacked'/>"))
    assertNull(chart(extra="<lineChart/>"))
    assertNull(chart(extra="<valAx><scaling><logBase val='10'/></scaling></valAx>"))
    assertNull(chart(type="pieChart"))
  }
  @Test fun conflictingCategoriesAndOversizedChartsUseTableFallback() {
    assertNull(chart(data=series()+series(label="February")))
    assertNull(chart(data=series("<pt idx='24'><v>4</v></pt>")))
  }
  @Test fun nonFiniteCachedValuesAreNotDrawn() {
    assertNull(chart(data=series("<pt idx='0'><v>NaN</v></pt><pt idx='1'><v>Infinity</v></pt>")))
  }
}

package com.example

import com.example.parser.DocumentIo
import com.example.parser.BoundedZipInputStream
import com.example.parser.TextCsvDocumentParser
import com.example.data.DocumentCache
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.junit.Assert.*
import org.junit.Test

class DocumentSafetyTest {
  private fun rows(csv: String, delimiter: Char = ',') =
    TextCsvDocumentParser.parseCsv(csv, delimiter).sheets.single().rows.map { row -> row.map { it.value } }

  @Test fun quotedCommaNewlineAndEscapedQuoteStayInOneCell() {
    assertEquals(listOf(listOf("Name", "Notes"), listOf(" A ", "line 1\r\nline 2, \"quoted\"")),
      rows("Name,Notes\r\n\" A \",\"line 1\r\nline 2, \"\"quoted\"\"\"\r\n"))
  }
  @Test fun bomTrailingEmptyFieldsAndBlankRowsArePreserved() {
    assertEquals(listOf(listOf("a", "b", ""), listOf(""), listOf("c", "", "")),
      rows("\uFEFFa,b,\r\n\r\nc,,"))
  }
  @Test fun alternateDelimiterAndEmptyFile() {
    assertEquals(listOf(listOf("a", "b;c")), rows("a;\"b;c\"", ';'))
    assertEquals(listOf(listOf("")), rows(""))
  }
  @Test(expected = IllegalArgumentException::class)
  fun malformedQuotedFieldIsRejected() { rows("a,\"unfinished") }

  @Test(expected = IllegalArgumentException::class)
  fun excessiveCsvCellsAreRejected() { rows(",".repeat(100_000)) }

  @Test fun streamLimitAllowsExactBoundary() {
    assertArrayEquals(byteArrayOf(1, 2, 3), DocumentIo.readLimited(ByteArrayInputStream(byteArrayOf(1, 2, 3)), 3))
  }
  @Test(expected = IllegalArgumentException::class)
  fun unknownLengthStreamCannotExceedLimit() {
    DocumentIo.readLimited(ByteArrayInputStream(ByteArray(1024)), 1023)
  }
  @Test fun interruptionStopsReads() {
    try {
      Thread.currentThread().interrupt()
      try { DocumentIo.readLimited(ByteArrayInputStream(byteArrayOf(1))); fail("Expected cancellation") }
      catch (_: java.util.concurrent.CancellationException) { }
    } finally { Thread.interrupted() }
  }
  @Test fun skippingZipEntryStillEnforcesExpandedLimit() {
    val compressed = ByteArrayOutputStream()
    ZipOutputStream(compressed).use { zip ->
      zip.putNextEntry(ZipEntry("large.bin"))
      repeat(25) { zip.write(ByteArray(1024 * 1024)) }
      zip.closeEntry()
      zip.putNextEntry(ZipEntry("next.bin")); zip.write(1); zip.closeEntry()
    }
    BoundedZipInputStream(ByteArrayInputStream(compressed.toByteArray())).use { zip ->
      assertNotNull(zip.nextEntry)
      try { zip.nextEntry; fail("Expected expanded-size limit") }
      catch (_: IllegalArgumentException) { }
    }
  }
  @Test fun cacheCleanupPreservesUnrelatedFiles() {
    val root = Files.createTempDirectory("localview-cache-test").toFile()
    try {
      java.io.File(root, "pdf_cache").mkdir()
      java.io.File(root, "pdf_cache/copy.pdf").writeText("cached")
      java.io.File(root, "original.txt").writeText("keep")
      assertEquals(1, DocumentCache.clear(root))
      assertTrue(java.io.File(root, "original.txt").exists())
      assertFalse(java.io.File(root, "pdf_cache").exists())
      assertEquals(0, DocumentCache.clear(root))
    } finally { root.deleteRecursively() }
  }
}

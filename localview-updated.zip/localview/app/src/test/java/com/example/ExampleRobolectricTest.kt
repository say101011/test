package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.DocumentType
import com.example.model.FormatSupportMatrix
import com.example.parser.FormatDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameIsLocalView() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("LocalView", appName)
  }

  @Test
  fun testFormatDetector() {
    assertEquals(DocumentType.PDF, DocumentType.fromExtension("sample.pdf"))
    assertEquals(DocumentType.HWP, DocumentType.fromExtension("doc.hwp"))
    assertEquals(DocumentType.HWPX, DocumentType.fromExtension("doc.hwpx"))
    assertEquals(DocumentType.EXCEL, DocumentType.fromExtension("budget.xlsx"))
    assertEquals(DocumentType.WORD, DocumentType.fromExtension("report.docx"))
    assertEquals(DocumentType.MARKDOWN, DocumentType.fromExtension("README.md"))
    assertEquals(DocumentType.CSV, DocumentType.fromExtension("data.csv"))
    assertEquals(DocumentType.IMAGE, DocumentType.fromExtension("photo.png"))
  }

  @Test
  fun testSupportMatrixCoverage() {
    val items = FormatSupportMatrix.items
    assertTrue(items.any { it.formatName.contains("PDF") })
    assertTrue(items.any { it.formatName.contains("HWP") })
    assertTrue(items.any { it.formatName.contains("Excel") })
    assertTrue(items.any { it.formatName.contains("Word") })
    assertTrue(items.any { it.formatName.contains("Markdown") })
    assertTrue(items.any { it.formatName.contains("CSV") })
  }
}

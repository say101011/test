package com.example

import android.net.Uri
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.v2.createComposeRule
import com.example.model.*
import com.example.ui.viewer.SpreadsheetViewer
import com.example.ui.theme.LocalViewTheme
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(qualifiers="w400dp-h700dp-mdpi",sdk=[34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SpreadsheetMergeUiTest {
  @get:Rule val compose=createComposeRule()
  @Test fun mergedRegionRemainsClickableWhenAnchorScrollsOffscreen() {
    val sheet=SheetData("Sheet",40,3,listOf("A","B","C"),List(40){r->List(3){c->CellData(r,c,if(r==0 && c==0)"Tall merge" else "")}},mergedRegions=listOf(MergedRegion(0,0,8,2)))
    val content=SpreadsheetDocumentContent(listOf(sheet))
    val tab=DocumentTab("scroll",Uri.EMPTY,"scroll.xlsx",1,DocumentType.EXCEL,content,isLoading=false)
    compose.setContent { LocalViewTheme { SpreadsheetViewer(tab,content,{}) } }
    compose.onNodeWithTag("spreadsheet_rows").performScrollToIndex(5)
    compose.onNodeWithTag("merged_cell_0_0").assertIsDisplayed().performClick()
    compose.onNode(isDialog()).assertIsDisplayed()
    compose.onNodeWithText("A1").assertIsDisplayed()
  }
  @Test fun chartDialogDrawsPreviewAndRetainsExactValues() {
    val chart=SheetChart("Revenue",listOf(listOf("Series","Category","Value"),listOf("Revenue","Jan","-12")),ChartPreview(ChartKind.COLUMN,listOf("Jan","Feb","Mar"),listOf(ChartSeries("Revenue",listOf(-12.0,8.0,24.0)))))
    val content=SpreadsheetDocumentContent(listOf(SheetData("Sheet",0,0,emptyList(),emptyList(),charts=listOf(chart))))
    val tab=DocumentTab("chart",Uri.EMPTY,"chart.xlsx",1,DocumentType.EXCEL,content,isLoading=false)
    compose.setContent { LocalViewTheme { SpreadsheetViewer(tab,content,{}) } }
    compose.onNodeWithText("View charts (1)").performClick()
    compose.onNodeWithTag("chart_preview").assertIsDisplayed()
    compose.onNode(isDialog()).captureRoboImage(filePath="build/reports/chart-preview.png")
    compose.onNodeWithText("Revenue | Jan | -12").performScrollTo().assertIsDisplayed()
  }
  @Test fun mergedCellSpansRowsAndOpensFullValue() {
    val text="Merged title"
    val sheet=SheetData("Sheet",4,3,listOf("A","B","C"),List(4) { r->List(3) { c->CellData(r,c,if(r==0 && c==0)text else "") } },mergedRegions=listOf(MergedRegion(0,0,1,2)))
    val content=SpreadsheetDocumentContent(listOf(sheet))
    val tab=DocumentTab("merge",Uri.EMPTY,"merge.xlsx",1,DocumentType.EXCEL,content,isLoading=false)
    compose.setContent { LocalViewTheme { SpreadsheetViewer(tab,content,{}) } }
    val merged=compose.onNodeWithTag("merged_cell_0_0")
    merged.assertIsDisplayed().assertWidthIsEqualTo(androidx.compose.ui.unit.Dp(330f)).assertHeightIsEqualTo(androidx.compose.ui.unit.Dp(64f))
    compose.onRoot().captureRoboImage(filePath="build/reports/spreadsheet-merged.png")
    merged.performClick()
    compose.onNode(isDialog()).assertIsDisplayed()
    compose.onNodeWithText("A1").assertIsDisplayed()
  }
  @Test fun emptySheetStillAllowsSwitching() {
    var selected=-1
    val sheets=listOf(SheetData("Empty",0,0,emptyList(),emptyList()),SheetData("Data",1,1,listOf("A"),listOf(listOf(CellData(0,0,"value")))))
    val content=SpreadsheetDocumentContent(sheets)
    val tab=DocumentTab("tabs",Uri.EMPTY,"sheets.xlsx",1,DocumentType.EXCEL,content,isLoading=false)
    compose.setContent { LocalViewTheme { SpreadsheetViewer(tab,content,{selected=it}) } }
    compose.onNodeWithText("Data").assertIsDisplayed().performClick()
    compose.runOnIdle { assertEquals(1,selected) }
  }
}

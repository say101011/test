package com.example

import android.app.Application
import android.net.Uri
import androidx.lifecycle.ViewModelStore
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.model.*
import com.example.ui.viewmodel.LocalViewerViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.test.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ReadingHistoryTest {
  private val dispatcher = StandardTestDispatcher()
  private val store = ViewModelStore()
  private val dao = MemoryDao()
  private val app: Application get() = ApplicationProvider.getApplicationContext()
  private val uri = Uri.parse("content://documents/book.pdf")
  @Before fun setup() { Dispatchers.setMain(dispatcher) }
  @After fun cleanup() { store.clear(); Dispatchers.resetMain() }
  private fun entry(page:Int=2) = RecentDocumentEntity(uriString=uri.toString(), displayName="book.pdf", mimeType="application/pdf", extension="pdf", fileSize=1, lastOpenedTimestamp=1, lastPage=page, lastZoom=1.75f)
  private fun viewer(loader:suspend (Application, DocumentTab)->Pair<DocumentType,DocumentContent> = { _, tab -> DocumentType.PDF to PdfDocumentContent(tab.uri, 5, List(5) { 100 to 100 }, "book") }) =
    LocalViewerViewModel(app, loader, dao).also { store.put("test",it); it.userPrefs.setRecentHistoryEnabled(true) }
  @Test fun reopeningRestoresPageAndZoomAndClampsOutdatedPage() = runTest(dispatcher) {
    dao.saveVisit(entry(99)); val vm=viewer(); vm.openDocument(uri,"book.pdf"); advanceUntilIdle()
    val tab=vm.openTabs.value.single()
    assertEquals(4,tab.currentPage); assertEquals(1.75f,tab.zoomLevel)
    vm.setPage(tab.id,1); vm.setZoom(tab.id,2f); advanceUntilIdle()
    assertEquals(1,dao.findByUri(uri.toString())!!.lastPage)
    assertEquals(2f,dao.findByUri(uri.toString())!!.lastZoom)
  }
  @Test fun removingEntryWhileLoadingPreventsResurrection() = runTest(dispatcher) {
    dao.saveVisit(entry()); val gate=CompletableDeferred<Unit>()
    val vm=viewer { _,tab -> gate.await(); DocumentType.PDF to PdfDocumentContent(tab.uri,5,List(5){100 to 100},"book") }
    vm.openDocument(uri,"book.pdf"); runCurrent(); vm.removeRecent(uri.toString()); runCurrent()
    gate.complete(Unit); advanceUntilIdle()
    assertNull(dao.findByUri(uri.toString()))
  }
  @Test fun successfulReselectionPreservesPositionAndReplacesUri() = runTest(dispatcher) {
    dao.saveVisit(entry()); val vm=viewer(); val replacement=Uri.parse("content://new/book.pdf")
    vm.reselectDocument(uri.toString(),replacement); advanceUntilIdle()
    assertNull(dao.findByUri(uri.toString()))
    assertEquals(2,dao.findByUri(replacement.toString())!!.lastPage)
    assertEquals(1.75f,vm.openTabs.value.single().zoomLevel)
  }
  @Test fun failedReselectionKeepsOriginalEntry() = runTest(dispatcher) {
    dao.saveVisit(entry()); val vm=viewer { _,_-> DocumentType.PDF to CorruptedDocumentContent("No access",true) }
    vm.reselectDocument(uri.toString(),Uri.parse("content://bad/book.pdf")); advanceUntilIdle()
    assertNotNull(dao.findByUri(uri.toString()))
    assertNull(dao.findByUri("content://bad/book.pdf"))
  }
  @Test fun ocrResultUpdatesOnlySelectedPageAndSearchCount() = runTest(dispatcher) {
    val vm=viewer();vm.openDocument(uri,"book.pdf");advanceUntilIdle()
    val id=vm.openTabs.value.single().id
    vm.setSearchQuery(id,"zebra")
    val result=PdfPageText("zebra",listOf(PdfTextBox(0,5,0.1f,0.1f,0.4f,0.2f)),"OCR (Latin)")
    vm.applyOcrResult(id,2,result)
    val tab=vm.openTabs.value.single();val pdf=tab.content as PdfDocumentContent
    assertEquals(1,tab.searchMatchCount);assertEquals("zebra",pdf.pageTextList[2])
    assertTrue(pdf.pageTextList[1].isBlank());assertEquals(result,pdf.pageGeometry[2])
    vm.applyOcrResult(id,99,result);assertEquals(pdf,vm.openTabs.value.single().content)
    vm.closeTab(0);advanceUntilIdle();assertTrue(vm.openTabs.value.isEmpty())
  }

  private class MemoryDao:RecentDocumentDao {
    private val entries=MutableStateFlow<List<RecentDocumentEntity>>(emptyList())
    override fun getAllRecentDocuments():Flow<List<RecentDocumentEntity>> = entries
    override suspend fun insertOrUpdate(doc:RecentDocumentEntity):Long { entries.value=entries.value.filterNot { it.uriString==doc.uriString }+doc; return doc.id }
    override suspend fun deleteByUri(uriString:String) { entries.value=entries.value.filterNot { it.uriString==uriString } }
    override suspend fun clearAll() { entries.value=emptyList() }
    override suspend fun findByUri(uriString:String)=entries.value.find { it.uriString==uriString }
    override suspend fun updatePosition(uriString:String,page:Int,zoom:Float) { entries.value=entries.value.map { if(it.uriString==uriString) it.copy(lastPage=page,lastZoom=zoom) else it } }
  }
}

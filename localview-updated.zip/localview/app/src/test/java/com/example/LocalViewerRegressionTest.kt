package com.example

import android.app.Application
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.ui.viewmodel.LocalViewerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class LocalViewerRegressionTest {
  private lateinit var vm: LocalViewerViewModel
  private lateinit var store: androidx.lifecycle.ViewModelStore
  @Before fun setup() {
    Dispatchers.setMain(StandardTestDispatcher())
    vm = LocalViewerViewModel(ApplicationProvider.getApplicationContext<Application>())
    store = androidx.lifecycle.ViewModelStore().also { it.put("viewer", vm) }
    for (name in listOf("a.txt", "b.txt", "c.txt")) {
      vm.openDocument(Uri.parse("file:///test/$name"), name)
    }
  }
  @After fun cleanup() { store.clear(); Dispatchers.resetMain() }

  @Test fun closingEarlierTabPreservesSelectedDocumentAndSplit() {
    vm.selectTab(1)
    vm.toggleSplitView()
    vm.selectSplitTab(2)
    vm.closeTab(0)
    assertEquals("b.txt", vm.openTabs.value[vm.activeTabIndex.value].displayName)
    assertEquals("c.txt", vm.openTabs.value[vm.splitTabIndex.value!!].displayName)
    assertTrue(vm.isSplitView.value)
  }

  @Test fun selectingSplitDocumentSwapsPanes() {
    vm.selectTab(0)
    vm.toggleSplitView()
    vm.selectTab(1)
    assertEquals(1, vm.activeTabIndex.value)
    assertEquals(0, vm.splitTabIndex.value)
  }

  @Test fun closingSplitDocumentDisablesSplitView() {
    vm.selectTab(0)
    vm.toggleSplitView()
    vm.closeTab(1)
    assertFalse(vm.isSplitView.value)
    assertNull(vm.splitTabIndex.value)
  }

  @Test fun bundledPolicyContainsOperatorAndContact() {
    val context = ApplicationProvider.getApplicationContext<Application>()
    val html = context.assets.open("privacy/index.html").bufferedReader().use { it.readText() }
    assertTrue(html.contains("momo world"))
    assertTrue(html.contains("mailto:say101011@gmail.com"))
    assertEquals("https://say101011.github.io/docviewer/", context.getString(R.string.privacy_policy_url))
  }
}

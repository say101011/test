# Validation — 2026-09-23

## Verified

- Host: Windows, Android Studio JBR 25, installed Android SDK 37.
- `:app:testDebugUnitTest`: 58 tests, 0 failures, 0 errors.
- `:app:lintDebug`: 0 errors, 1 warning, 0 hints (previous baseline: 44 warnings).
- Final app/test Kotlin compilation emitted no Kotlin compiler warnings.
- Robolectric chart screenshot inspected: zero baseline, positive/negative columns, numbered categories, legend and scrollable exact values.
- Regression coverage includes DOC/DOCX/HWP/HWPX/XLS/XLSX parsing, PDF text/geometry, reading history and migration, cancellation, input bounds, settings, merged-cell size/click/scroll, and chart fallback behavior.
- Gradle distribution checksum pinned to the official 9.7.1 SHA-256.

## Remaining warning

`TrustAllX509TrustManager` originates in upstream `org.bouncycastle:bcpkix-jdk15to18:1.86`, a PDFBox dependency. It flags the EST helper's empty server-certificate check. App source does not reference that helper or custom TLS trust managers. No lint suppression or baseline was added. Removing/replacing upstream cryptographic code requires separate dependency work and compatibility validation.

## Scope and remaining limits

- No APK/AAB assembled; no emulator or physical-device run.
- UI tests use Robolectric API 34. SDK 37 is the compile/target SDK; Android 17 runtime validation was not performed.
- Global menus and policy remain English; policy URL/operator/email unchanged. No website deployment occurred.
- XLSX graphs support small cached column/bar/line charts; complex charts retain saved-value tables. Formula recalculation and original chart styling are unsupported.
- Office/HWP print pagination, floating elements and complex layouts remain simplified. Document memory/size bounds remain intentional. OCR processes one selected page and needs device quality validation.
- Source archive includes project source, resources, tests, fixtures/licenses, Gradle wrapper and policy. Generated build caches, local SDK paths, signing keys, private `.env`, APK/AAB and previous archives are excluded.
